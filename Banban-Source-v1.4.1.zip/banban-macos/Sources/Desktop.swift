import AppKit
import Carbon
import SwiftUI
import AVFoundation

// Register only this shortcut; no general key-event monitoring or accessibility access.
@MainActor final class GlobalPetHotKey {
    static let label = "⌃⌥H"
    private var hotKey: EventHotKeyRef?
    private var handler: EventHandlerRef?
    var action: (() -> Void)?
    func start() -> OSStatus {
        stop()
        var type = EventTypeSpec(eventClass: OSType(kEventClassKeyboard), eventKind: UInt32(kEventHotKeyPressed))
        let status = InstallEventHandler(GetApplicationEventTarget(), { _, event, context in
            guard let event, let context else { return OSStatus(eventNotHandledErr) }
            var id = EventHotKeyID()
            let result = GetEventParameter(event, EventParamName(kEventParamDirectObject), EventParamType(typeEventHotKeyID), nil, MemoryLayout<EventHotKeyID>.size, nil, &id)
            guard result == noErr, id.signature == 0x424E424E, id.id == 1 else { return OSStatus(eventNotHandledErr) }
            MainActor.assumeIsolated { Unmanaged<GlobalPetHotKey>.fromOpaque(context).takeUnretainedValue().action?() }
            return noErr
        }, 1, &type, Unmanaged.passUnretained(self).toOpaque(), &handler)
        guard status == noErr else { return status }
        let registered = RegisterEventHotKey(UInt32(kVK_ANSI_H), UInt32(controlKey | optionKey), EventHotKeyID(signature:0x424E424E,id:1), GetApplicationEventTarget(), 0, &hotKey)
        if registered != noErr { stop() }
        return registered
    }
    func stop() {
        if let hotKey { UnregisterEventHotKey(hotKey); self.hotKey=nil }
        if let handler { RemoveEventHandler(handler); self.handler=nil }
    }
}

@MainActor enum PetPresentation {
    static func apply(_ preferences: Preferences, to panel: NSPanel) {
        if preferences.wallpaperEffect {
            // Above the wallpaper, below Finder's desktop icons and ordinary app windows.
            panel.level=NSWindow.Level(rawValue:Int(CGWindowLevelForKey(.desktopWindow))+1)
            panel.collectionBehavior=preferences.joinAllSpaces ? [.canJoinAllSpaces,.stationary,.ignoresCycle]:[.moveToActiveSpace,.stationary,.ignoresCycle]
            panel.ignoresMouseEvents=true
        } else {
            panel.level=(preferences.floatingClickThrough || preferences.alwaysOnTop) ? .floating:.normal
            panel.collectionBehavior=preferences.joinAllSpaces ? [.canJoinAllSpaces,.fullScreenAuxiliary]:[.moveToActiveSpace,.fullScreenAuxiliary]
            panel.ignoresMouseEvents=preferences.floatingClickThrough
        }
    }
}

@MainActor final class CompanionPanel:NSPanel {
    override var canBecomeKey:Bool { false }
    override var canBecomeMain:Bool { false }
}
@MainActor final class LoopingPetVideo {
    let player=AVQueuePlayer()
    let layer=AVPlayerLayer()
    private(set) var looper:AVPlayerLooper?
    private(set) var url:URL?
    private(set) var wantsPlayback=false
    private var failureObserver:NSKeyValueObservation?
    private var looperObserver:NSKeyValueObservation?
    var onFailure:(()->Void)?
    init() { player.isMuted=true;player.preventsDisplaySleepDuringVideoPlayback=false;layer.player=player;layer.videoGravity = .resizeAspect;layer.backgroundColor=NSColor.clear.cgColor }
    func load(_ url:URL) {
        guard self.url != url else { return }
        stop();self.url=url;layer.player=player
        let item=AVPlayerItem(url:url)
        looper=AVPlayerLooper(player:player,templateItem:item)
        looperObserver=looper?.observe(\.status,options:[.new]) { [weak self] looper,_ in
            if looper.status == .failed { Task { @MainActor in self?.onFailure?() } }
        }
        failureObserver=player.observe(\.status,options:[.new]) { [weak self] player,_ in
            if player.status == .failed { Task { @MainActor in self?.onFailure?() } }
        }
    }
    func setPlaying(_ enabled:Bool) {
        wantsPlayback=enabled && url != nil
        if wantsPlayback { if player.rate==0 { player.play() } } else { player.pause() }
    }
    func stop() { player.pause();failureObserver=nil;looperObserver=nil;looper?.disableLooping();looper=nil;player.removeAllItems();layer.player=nil;url=nil;wantsPlayback=false }
}
@MainActor final class PetView:NSView {
    weak var model:CompanionModel?
    weak var owner:CompanionAppDelegate?
    var desktopPhotoID:UUID?
    let video=LoopingPetVideo()
    private var mediaFile:String?
    func setMedia(_ file:String?) {
        guard let model else { return }
        photo=model.image(file:file)
        if file != mediaFile {
            mediaFile=file
            if DiskStore.isVideo(file),let url=model.disk.photoURL(file) {
                video.onFailure={ [weak model] in model?.error="视频播放失败，请重新导入可正常播放的 MP4／MOV 视频。" }
                video.load(url)
            } else { video.stop() }
        }
        updateVideoLayout();needsDisplay=true
    }
    func updateVideoLayout() { CATransaction.begin();CATransaction.setDisableActions(true);video.layer.frame=photoRect;video.layer.opacity=Float(displayPreferences.opacity);CATransaction.commit() }
    var photo:NSImage? { didSet { bitmap=photo?.tiffRepresentation.flatMap { NSBitmapImageRep(data:$0) };needsDisplay=true;needsLayout=true } }
    var bitmap:NSBitmapImageRep?
    var bounce:CGFloat=0 { didSet { needsDisplay=true;needsLayout=true } }
    var hovered=false { didSet { bar.isHidden = !hovered;needsDisplay=true } }
    let bar=NSVisualEffectView()
    override init(frame:NSRect) { super.init(frame:frame);wantsLayer=true;layer?.backgroundColor=NSColor.clear.cgColor;bar.material = .popover;bar.blendingMode = .behindWindow;bar.state = .active;bar.wantsLayer=true;bar.layer?.cornerRadius=16;bar.isHidden=true;layer?.addSublayer(video.layer);addSubview(bar) }
    required init?(coder:NSCoder) { fatalError() }
    func configureButtons() {
        let done=NSButton(image:NSImage(systemSymbolName:"checkmark.circle.fill",accessibilityDescription:"完成摆放") ?? NSImage(),target:self,action:#selector(finishPositioning));done.isBordered=false;done.frame=NSRect(x:4,y:4,width:28,height:25);done.toolTip="完成摆放并恢复此桌宠的显示模式";done.tag=90;bar.addSubview(done)
        let actions:[(String,String,Selector)]=[("bubble.left","打开聊天",#selector(CompanionAppDelegate.showChat)),("face.smiling","表情动作",#selector(CompanionAppDelegate.showPoses)),("gearshape","打开设置",#selector(CompanionAppDelegate.showSettings))]
        for (i,item) in actions.enumerated() { let button=NSButton(image:NSImage(systemSymbolName:item.0,accessibilityDescription:item.1) ?? NSImage(),target:owner,action:item.2);button.bezelStyle = .inline;button.isBordered=false;button.toolTip=item.1;button.contentTintColor=NSColor(red:0.59,green:0.44,blue:0.70,alpha:1);button.frame=NSRect(x:36+i*34,y:4,width:32,height:25);bar.addSubview(button) }
    }
    override func layout() { super.layout();updateVideoLayout();bar.frame=NSRect(x:(bounds.width-146)/2,y:4,width:146,height:33) }
    var photoRect:NSRect {
        guard let image=photo,image.size.height>0 else { return .zero }
        let available=NSRect(x:0,y:44,width:bounds.width,height:bounds.height-46)
        let scale=min(available.width/image.size.width,available.height/image.size.height)
        let size=NSSize(width:image.size.width*scale,height:image.size.height*scale)
        return NSRect(x:(bounds.width-size.width)/2,y:available.minY+bounce,width:size.width,height:size.height)
    }
    var displayPreferences:Preferences {
        guard let model else { return Preferences() }
        if let id=desktopPhotoID,let item=(model.settings.desktopPhotos ?? []).first(where:{$0.id==id}) { return model.desktopPreferences(item,forPositioning:true) }
        return model.mainPresentationPreferences
    }
    @objc func finishPositioning() {
        guard let model else { return }
        if let id=desktopPhotoID { model.positioningPhotos.remove(id) } else { model.positioningMain=false }
    }
    override func draw(_ dirtyRect:NSRect) { guard video.url == nil else { return };photo?.draw(in:photoRect,from:.zero,operation:.sourceOver,fraction:displayPreferences.opacity,respectFlipped:true,hints:[.interpolation:NSImageInterpolation.high.rawValue]) }
    func containsVisiblePoint(_ point:NSPoint)->Bool {
        guard displayPreferences.opacity>0 else { return false }
        if !bar.isHidden && bar.frame.contains(point) { return true }
        let rect=photoRect
        if video.url != nil { return rect.contains(point) }
        guard rect.contains(point),let bitmap,rect.width>0,rect.height>0 else { return false }
        let x=max(0,min(bitmap.pixelsWide-1,Int((point.x-rect.minX)/rect.width*CGFloat(bitmap.pixelsWide))))
        let y=max(0,min(bitmap.pixelsHigh-1,Int((1-(point.y-rect.minY)/rect.height)*CGFloat(bitmap.pixelsHigh))))
        return (bitmap.colorAt(x:x,y:y)?.alphaComponent ?? 1)>0.08
    }
    override func mouseDown(with event:NSEvent) {
        guard let window else { return }
        if event.clickCount==2 { owner?.showChat();return }
        let start=window.frame.origin
        window.performDrag(with:event)
        owner?.clampPetToScreen(panel:window)
        if let id=desktopPhotoID { owner?.saveDesktopPosition(id) }
        if desktopPhotoID == nil && model?.positioningMain != true && abs(window.frame.minX-start.x)+abs(window.frame.minY-start.y)<4 { model?.selectPose("hello") }
    }
    override func scrollWheel(with event:NSEvent) {
        guard let model else { return }
        if let id=desktopPhotoID,let item=(model.settings.desktopPhotos ?? []).first(where:{$0.id==id}) { model.setDesktopHeight(id,item.height-Double(event.scrollingDeltaY)*2) }
        else { model.settings.preferences.personHeight=min(700,max(100,model.settings.preferences.personHeight-Double(event.scrollingDeltaY)*2)) }
    }
    @objc func shrinkThisPhoto() { if let id=desktopPhotoID,let model,let item=(model.settings.desktopPhotos ?? []).first(where:{$0.id==id}) { model.setDesktopHeight(id,item.height-40) } }
    @objc func growThisPhoto() { if let id=desktopPhotoID,let model,let item=(model.settings.desktopPhotos ?? []).first(where:{$0.id==id}) { model.setDesktopHeight(id,item.height+40) } }
    @objc func removeThisPhoto() { if let id=desktopPhotoID { model?.removeDesktopPhoto(id) } }
    override func rightMouseDown(with event:NSEvent) {
        guard let owner else { return }
        let menu=NSMenu()
        func add(_ title:String,_ selector:Selector) { let item=NSMenuItem(title:title,action:selector,keyEquivalent:"");item.target=owner;menu.addItem(item) }
        if desktopPhotoID != nil {
            let done=NSMenuItem(title:"完成摆放",action:#selector(finishPositioning),keyEquivalent:"");done.target=self;menu.addItem(done)
            for (title,action) in [("打开聊天",#selector(CompanionAppDelegate.showChat))] { let item=NSMenuItem(title:title,action:action,keyEquivalent:"");item.target=owner;menu.addItem(item) }
            for (title,action) in [("缩小这张图片",#selector(shrinkThisPhoto)),("放大这张图片",#selector(growThisPhoto)),("移出桌面",#selector(removeThisPhoto))] { let item=NSMenuItem(title:title,action:action,keyEquivalent:"");item.target=self;menu.addItem(item) }
            NSMenu.popUpContextMenu(menu,with:event,for:self);return
        }
        add("和\(model?.displayName ?? "伙伴")聊天",#selector(CompanionAppDelegate.showChat));add("表情与动作",#selector(CompanionAppDelegate.showPoses));add("角色设定",#selector(CompanionAppDelegate.showRole));menu.addItem(.separator());add("缩小人物",#selector(CompanionAppDelegate.shrinkPet));add("放大人物",#selector(CompanionAppDelegate.growPet));add("更换人物照片",#selector(CompanionAppDelegate.importPhoto));add("回到屏幕右下角",#selector(CompanionAppDelegate.resetPosition));add("隐藏桌面伙伴",#selector(CompanionAppDelegate.togglePet));menu.addItem(.separator());add("退出伴伴",#selector(CompanionAppDelegate.quit));NSMenu.popUpContextMenu(menu,with:event,for:self)
    }
}
struct SpeechView:View {
    let name:String;let text:String;let open:()->Void
    var body:some View { Button(action:open) { VStack(alignment:.leading,spacing:7) { Text(name).font(.system(size:10)).foregroundStyle(Color.companionPurple);Text(text).font(.system(size:12)).lineSpacing(4).lineLimit(4).multilineTextAlignment(.leading).foregroundStyle(Color.companionInk);Text("点击继续聊天").font(.system(size:9)).foregroundStyle(Color.companionMuted) }.padding(15).frame(width:242,alignment:.leading).background(Color.companionPaper.opacity(0.96),in:RoundedRectangle(cornerRadius:16)) }.buttonStyle(.plain) }
}
@MainActor final class CompanionAppDelegate:NSObject,NSApplicationDelegate,NSWindowDelegate,NSMenuDelegate {
    var model:CompanionModel!
    var settingsWindow:NSWindow?
    var chatWindow:NSWindow?
    var petPanel:CompanionPanel?
    var petView:PetView?
    var desktopPanels:[UUID:CompanionPanel]=[:]
    var desktopViews:[UUID:PetView]=[:]
    var speechPanel:CompanionPanel?
    var galleryExitPanel:CompanionPanel?
    var galleryPanel:CompanionPanel?
    var galleryCanvas:GalleryCanvasView?
    var galleryScreenNumber:NSNumber?
    var statusItem:NSStatusItem?
    var wallpaperMenuItem:NSMenuItem?
    var floatingClickThroughMenuItem:NSMenuItem?
    var animationTimer:Timer?
    var positionTimer:Timer?
    var speechTimer:Timer?
    var lastSpeechID:UUID?
    var phase:Double=0
    var applying=false
    let globalPetHotKey=GlobalPetHotKey()
    func applicationDidFinishLaunching(_ notification:Notification) {
        do { model=CompanionModel(disk:try DiskStore()) }
        catch { let alert=NSAlert();alert.messageText="伴伴无法创建本地资料目录";alert.informativeText=error.localizedDescription;alert.runModal();NSApp.terminate(nil);return }
        NSApp.setActivationPolicy(.regular)
        makeMenu();makeStatusItem()
        globalPetHotKey.action={ [weak self] in self?.quickTogglePet() }
        let hotKeyStatus=globalPetHotKey.start()
        if hotKeyStatus != noErr { model.error="全局快捷键 ⌃⌥H 注册失败，可能被其他软件占用。仍可使用菜单栏显示／隐藏伙伴。（\(hotKeyStatus)）" }
        model.onShowChat={ [weak self] in self?.showChat() };model.onShowSettings={ [weak self] in self?.showSettings() }
        model.onArrangeDesktop={ [weak self] in self?.arrangeDesktopPhotos() }
        model.onGalleryChanged={ [weak self] in self?.syncGalleryDisplay() }
        model.onWillSwitchProfile={ [weak self] in
            guard let self else { return };self.positionTimer?.invalidate();self.speechTimer?.invalidate();self.speechPanel?.orderOut(nil);self.closeGalleryDisplay();self.lastSpeechID=nil
            self.petView?.video.stop();self.petPanel?.delegate=nil;self.petPanel?.close();self.petPanel=nil;self.petView=nil
            for view in self.desktopViews.values { view.video.stop() };for panel in self.desktopPanels.values { panel.close() };self.desktopPanels=[:];self.desktopViews=[:]
        }
        model.onPetChanged={ [weak self] in self?.refreshPet() };model.onSettingsChanged={ [weak self] in self?.applyPreferences() }
        NotificationCenter.default.addObserver(self,selector:#selector(resetPosition),name:.resetCompanionPosition,object:nil)
        NotificationCenter.default.addObserver(self,selector:#selector(galleryScreensChanged),name:NSApplication.didChangeScreenParametersNotification,object:nil)
        applyPreferences()
        if !model.hasPhoto { showSettings() }
        animationTimer=Timer.scheduledTimer(withTimeInterval:0.10,repeats:true) { [weak self] _ in MainActor.assumeIsolated { self?.tick() } }
    }
    func makeMenu() {
        let main=NSMenu(),appItem=NSMenuItem(),menu=NSMenu(title:"伴伴")
        func add(_ title:String,_ action:Selector,_ key:String="") { let item=NSMenuItem(title:title,action:action,keyEquivalent:key);item.target=self;menu.addItem(item) }
        add("关于伴伴",#selector(about));menu.addItem(.separator());add("伴伴设置…",#selector(showSettings),",");add("打开聊天",#selector(showChat),"k");add("显示／隐藏桌面伙伴",#selector(togglePet),"p");menu.addItem(.separator());add("退出伴伴",#selector(quit),"q");appItem.submenu=menu;main.addItem(appItem)
        let quickItem=NSMenuItem(title:"快速隐藏／恢复桌宠",action:#selector(quickTogglePet),keyEquivalent:"h");quickItem.keyEquivalentModifierMask=[.control,.option];quickItem.target=self;menu.insertItem(quickItem,at:6)
        let editItem=NSMenuItem(title:"编辑",action:nil,keyEquivalent:""),edit=NSMenu(title:"编辑")
        for (title,action,key) in [("撤销",Selector(("undo:")),"z"),("剪切",#selector(NSText.cut(_:)),"x"),("复制",#selector(NSText.copy(_:)),"c"),("粘贴",#selector(NSText.paste(_:)),"v"),("全选",#selector(NSText.selectAll(_:)),"a")] { edit.addItem(NSMenuItem(title:title,action:action,keyEquivalent:key)) };editItem.submenu=edit;main.addItem(editItem)
        let windowItem=NSMenuItem(title:"窗口",action:nil,keyEquivalent:""),windowMenu=NSMenu(title:"窗口");windowMenu.addItem(withTitle:"最小化",action:#selector(NSWindow.performMiniaturize(_:)),keyEquivalent:"m");windowItem.submenu=windowMenu;main.addItem(windowItem);NSApp.windowsMenu=windowMenu;NSApp.mainMenu=main
    }
    func makeStatusItem() {
        let item=NSStatusBar.system.statusItem(withLength:NSStatusItem.squareLength);item.button?.image=NSImage(systemSymbolName:"heart.fill",accessibilityDescription:"伴伴");item.button?.image?.isTemplate=true;item.button?.toolTip="伴伴 · 你的桌面伙伴"
        let menu=NSMenu()
        for (title,selector) in [("打开聊天",#selector(showChat)),("人物与设置",#selector(showSettings)),("角色设定",#selector(showRole)),("AI 接口",#selector(showAPI)),("快速隐藏／恢复桌宠（⌃⌥H）",#selector(quickTogglePet)),("找回桌面伙伴",#selector(resetPosition))] { let entry=NSMenuItem(title:title,action:selector,keyEquivalent:"");entry.target=self;menu.addItem(entry) }
        let profiles=NSMenuItem(title:"切换角色",action:nil,keyEquivalent:"");let profileMenu=NSMenu(title:"角色切换");profileMenu.delegate=self;profiles.submenu=profileMenu;menu.addItem(profiles)
        let wallpaper=NSMenuItem(title:"主桌宠：壁纸效果（鼠标穿透）",action:#selector(toggleWallpaperEffect),keyEquivalent:"");wallpaper.target=self;wallpaper.state=model.settings.preferences.wallpaperEffect ? .on:.off;menu.addItem(wallpaper);wallpaperMenuItem=wallpaper
        let floating=NSMenuItem(title:"主桌宠：悬浮穿透（置顶但不挡鼠标）",action:#selector(toggleFloatingClickThrough),keyEquivalent:"");floating.target=self;floating.state=model.settings.preferences.floatingClickThrough ? .on:.off;menu.addItem(floating);floatingClickThroughMenuItem=floating
        menu.addItem(.separator());let exit=NSMenuItem(title:"退出伴伴",action:#selector(quit),keyEquivalent:"");exit.target=self;menu.addItem(exit);item.menu=menu;statusItem=item
    }
    func menuNeedsUpdate(_ menu:NSMenu) {
        guard menu.title=="角色切换" else { return };menu.removeAllItems()
        for profile in model.settings.profiles ?? [] {
            let item=NSMenuItem(title:profile.id==model.settings.activeProfileID ? model.displayName:profile.role.name,action:#selector(switchRole(_:)),keyEquivalent:"")
            item.target=self;item.representedObject=profile.id.uuidString;item.state=profile.id==model.settings.activeProfileID ? .on:.off;item.isEnabled = !model.processingPhotos;menu.addItem(item)
        }
    }
    @objc func switchRole(_ item:NSMenuItem) { if let value=item.representedObject as? String,let id=UUID(uuidString:value) { model.switchProfile(id) } }
    @objc func showSettings() {
        if settingsWindow==nil { let window=NSWindow(contentRect:NSRect(x:0,y:0,width:870,height:720),styleMask:[.titled,.closable,.miniaturizable,.resizable],backing:.buffered,defer:false);window.title="伴伴 · 你的真人桌面伙伴";window.titlebarAppearsTransparent=true;window.backgroundColor=NSColor(red:0.985,green:0.972,blue:0.963,alpha:1);window.isReleasedWhenClosed=false;window.contentView=NSHostingView(rootView:CompanionSettingsView(model:model));window.minSize=NSSize(width:800,height:690);window.center();settingsWindow=window }
        settingsWindow?.makeKeyAndOrderFront(nil);NSApp.activate(ignoringOtherApps:true)
    }
    @objc func showChat() {
        if chatWindow==nil { let window=NSWindow(contentRect:NSRect(x:0,y:0,width:420,height:630),styleMask:[.titled,.closable,.miniaturizable,.resizable,.fullSizeContentView],backing:.buffered,defer:false);window.title="和\(model.displayName)聊天";window.titlebarAppearsTransparent=true;window.titleVisibility = .hidden;window.isOpaque=false;window.backgroundColor = .clear;window.isReleasedWhenClosed=false;window.contentView=NSHostingView(rootView:CompanionChatView(model:model));window.minSize=NSSize(width:380,height:540);window.center();chatWindow=window }
        chatWindow?.title="和\(model.displayName)聊天";chatWindow?.makeKeyAndOrderFront(nil);NSApp.activate(ignoringOtherApps:true);speechPanel?.orderOut(nil)
    }
    @objc func showPoses() { model.section="表情动作";showSettings() }
    @objc func showRole() { model.section="角色设定";showSettings() }
    @objc func showAPI() { model.section="AI 接口";showSettings() }
    @objc func shrinkPet() { model.settings.preferences.personHeight=max(100,model.settings.preferences.personHeight-40) }
    @objc func growPet() { model.settings.preferences.personHeight=min(700,model.settings.preferences.personHeight+40) }
    @objc func importPhoto() { model.importPhotos() }
    @objc func toggleWallpaperEffect() { model.settings.preferences.setWallpaperEffect(!model.settings.preferences.wallpaperEffect) }
    @objc func toggleFloatingClickThrough() { model.settings.preferences.setFloatingClickThrough(!model.settings.preferences.floatingClickThrough) }
    @objc func quickTogglePet() { guard model.hasPhoto || !model.galleryDisplayFiles.isEmpty else { return };model.settings.preferences.petVisible.toggle() }
    @objc func togglePet() { if !model.hasPhoto { model.section="人物照片";showSettings();return };model.settings.preferences.petVisible.toggle() }
    @objc func resetPosition() { model.settings.preferences.mainPetVisible=true;model.settings.preferences.petX=nil;model.settings.preferences.petY=nil;if !model.settings.preferences.petVisible { model.settings.preferences.petVisible=true };positionPetDefault();if !model.hasPhoto { model.section="人物照片";showSettings() } }
    func applyPreferences() {
        guard model != nil,!applying else { return };applying=true;defer { applying=false }
        wallpaperMenuItem?.state=model.settings.preferences.wallpaperEffect ? .on:.off
        floatingClickThroughMenuItem?.state=model.settings.preferences.floatingClickThrough ? .on:.off
        syncDesktopPhotos()
        guard model.hasPhoto,model.settings.preferences.petVisible,model.settings.preferences.mainPetVisible else { petView?.video.setPlaying(false);if !model.hasPhoto { petView?.setMedia(nil) };petPanel?.orderOut(nil);speechPanel?.orderOut(nil);return }
        if petPanel==nil {
            let panel=CompanionPanel(contentRect:NSRect(x:0,y:0,width:260,height:470),styleMask:[.borderless,.nonactivatingPanel],backing:.buffered,defer:false)
            panel.isOpaque=false;panel.backgroundColor = .clear;panel.hasShadow=false;panel.hidesOnDeactivate=false;panel.isReleasedWhenClosed=false;panel.delegate=self;panel.isFloatingPanel=true;panel.isMovableByWindowBackground=false
            let view=PetView(frame:NSRect(x:0,y:0,width:260,height:470));view.model=model;view.owner=self;view.configureButtons();panel.contentView=view;petPanel=panel;petView=view
            resizePet();positionPetDefault()
            if let x=model.settings.preferences.petX,let y=model.settings.preferences.petY { panel.setFrameOrigin(NSPoint(x:x,y:y));clampPetToScreen() }
        }
        if let panel=petPanel { PetPresentation.apply(model.mainPresentationPreferences,to:panel) }
        if model.settings.preferences.opacity==0 || model.settings.preferences.wallpaperEffect || model.settings.preferences.floatingClickThrough { petView?.hovered=false;if model.settings.preferences.wallpaperEffect { petView?.bounce=0 };speechTimer?.invalidate();speechPanel?.orderOut(nil) }
        resizePet();petView?.setMedia(model.currentMediaFile)
        if model.currentImage != nil { petPanel?.orderFrontRegardless() } else { petPanel?.orderOut(nil) }
        petView?.video.setPlaying(petPanel?.isVisible == true)
        clampPetToScreen()
    }
    func resizePet() {
        guard let panel=petPanel,let image=model.currentImage else { return }
        let screen=panel.screen ?? NSScreen.main
        let limit=max(100,(screen?.visibleFrame.height ?? 800)-90)
        let height=min(max(model.settings.preferences.personHeight,100),min(700,limit))
        let ratio=image.size.width/max(image.size.height,1)
        let width=min(max(height*ratio,145),min(620,(screen?.visibleFrame.width ?? 1000)-30))
        let size=NSSize(width:width,height:height+46)
        if abs(panel.frame.width-size.width)>1 || abs(panel.frame.height-size.height)>1 { panel.setContentSize(size) }
    }
    func positionPetDefault() { guard let panel=petPanel,let screen=NSScreen.main else { return };let frame=screen.visibleFrame;panel.setFrameOrigin(NSPoint(x:frame.maxX-panel.frame.width-35,y:frame.minY+25));clampPetToScreen() }
    func clampPetToScreen(panel selected:NSWindow?=nil) {
        guard let panel=selected ?? petPanel else { return }
        let center=NSPoint(x:panel.frame.midX,y:panel.frame.midY)
        let screen=NSScreen.screens.first { $0.frame.contains(center) } ?? panel.screen ?? NSScreen.main
        guard let visible=screen?.visibleFrame else { return }
        let x=max(visible.minX,min(panel.frame.minX,visible.maxX-panel.frame.width)),y=max(visible.minY,min(panel.frame.minY,visible.maxY-panel.frame.height))
        if abs(panel.frame.minX-x)>1 || abs(panel.frame.minY-y)>1 { panel.setFrameOrigin(NSPoint(x:x,y:y)) }
        positionSpeech()
    }
    func refreshPet() {
        applyPreferences()
        if !model.busy,let last=model.messages.last,last.role=="assistant",last.id != lastSpeechID { lastSpeechID=last.id;showSpeech(last.content) }
    }
    func closeGalleryDisplay() {
        galleryCanvas?.stop();galleryCanvas=nil;galleryPanel?.close();galleryPanel=nil
        galleryExitPanel?.close();galleryExitPanel=nil;galleryScreenNumber=nil
    }
    @objc func galleryScreensChanged() { syncGalleryDisplay() }
    func syncGalleryDisplay(in area:NSRect?=nil) {
        let files=model.orderedGalleryDisplayFiles
        guard !files.isEmpty else { closeGalleryDisplay();return }
        guard model.settings.preferences.petVisible else {
            galleryCanvas?.setPlaying(false);galleryPanel?.orderOut(nil);galleryExitPanel?.orderOut(nil);return
        }
        let screen=NSScreen.screens.first { ($0.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber)==galleryScreenNumber } ?? settingsWindow?.screen ?? NSScreen.main
        guard let visible=area ?? screen?.visibleFrame ?? galleryPanel?.frame else { return }
        galleryScreenNumber=screen?.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber
        if galleryPanel == nil {
            let panel=CompanionPanel(contentRect:visible,styleMask:[.borderless,.nonactivatingPanel],backing:.buffered,defer:false)
            panel.isOpaque=false;panel.backgroundColor = .clear;panel.hasShadow=false;panel.hidesOnDeactivate=false;panel.isReleasedWhenClosed=false
            panel.isFloatingPanel=true;panel.level=NSWindow.Level(rawValue:NSWindow.Level.floating.rawValue+1);panel.ignoresMouseEvents=true
            panel.collectionBehavior=[.canJoinAllSpaces,.fullScreenAuxiliary,.ignoresCycle]
            let canvas=GalleryCanvasView(frame:NSRect(origin:.zero,size:visible.size));panel.contentView=canvas;galleryPanel=panel;galleryCanvas=canvas
        }
        galleryPanel?.setFrame(visible,display:false)
        galleryCanvas?.setFiles(files,disk:model.disk)
        galleryCanvas?.arrange(scale:screen?.backingScaleFactor ?? 2)
        galleryCanvas?.setPlaying(model.settings.preferences.petVisible)
        if model.settings.preferences.petVisible { galleryPanel?.orderFrontRegardless() } else { galleryPanel?.orderOut(nil) }
        syncGalleryExitPanel(in:visible)
    }
    func syncGalleryExitPanel(in visible:NSRect) {
        guard !model.galleryDisplayFiles.isEmpty,model.settings.preferences.petVisible else { galleryExitPanel?.orderOut(nil);return }
        let size=NSSize(width:122,height:42)
        if galleryExitPanel == nil {
            let panel=CompanionPanel(contentRect:NSRect(origin:.zero,size:size),styleMask:[.borderless,.nonactivatingPanel],backing:.buffered,defer:false)
            panel.isOpaque=false;panel.backgroundColor = .clear;panel.hasShadow=false;panel.hidesOnDeactivate=false;panel.isReleasedWhenClosed=false;panel.isFloatingPanel=true;panel.level=NSWindow.Level(rawValue:NSWindow.Level.floating.rawValue+2);panel.collectionBehavior=[.canJoinAllSpaces,.fullScreenAuxiliary,.ignoresCycle]
            panel.contentView=NSHostingView(rootView:GalleryExitOverlay { [weak self] in self?.model.exitAllPhotoDisplay() });galleryExitPanel=panel
        }
        galleryExitPanel?.setFrameOrigin(NSPoint(x:visible.maxX-size.width-16,y:visible.maxY-size.height-16))
        galleryExitPanel?.orderFrontRegardless()
    }
    func showSpeech(_ text:String) {
        guard model.settings.preferences.opacity>0,!model.settings.preferences.wallpaperEffect,!model.settings.preferences.floatingClickThrough,let pet=petPanel,pet.isVisible else { return }
        if speechPanel==nil { let panel=CompanionPanel(contentRect:NSRect(x:0,y:0,width:244,height:170),styleMask:[.borderless,.nonactivatingPanel],backing:.buffered,defer:false);panel.isOpaque=false;panel.backgroundColor = .clear;panel.hasShadow=true;panel.hidesOnDeactivate=false;panel.isReleasedWhenClosed=false;speechPanel=panel }
        speechPanel?.level=pet.level;speechPanel?.collectionBehavior=pet.collectionBehavior
        let view=NSHostingView(rootView:SpeechView(name:model.displayName,text:text,open:{ [weak self] in self?.showChat() }));speechPanel?.contentView=view;speechPanel?.setContentSize(NSSize(width:244,height:170));positionSpeech();speechPanel?.orderFrontRegardless()
        speechTimer?.invalidate();speechTimer=Timer.scheduledTimer(withTimeInterval:12,repeats:false) { [weak self] _ in MainActor.assumeIsolated { self?.speechPanel?.orderOut(nil) } }
    }
    func positionSpeech() {
        guard let pet=petPanel,let speech=speechPanel,let visible=(pet.screen ?? NSScreen.main)?.visibleFrame else { return }
        let preferred=pet.frame.minX-speech.frame.width+10
        let x=preferred < visible.minX ? min(pet.frame.maxX-10,visible.maxX-speech.frame.width):preferred
        let y=max(visible.minY,min(pet.frame.maxY-speech.frame.height-15,visible.maxY-speech.frame.height))
        speech.setFrameOrigin(NSPoint(x:max(visible.minX,x),y:y))
    }
    func tick() {
        phase+=0.1
        var pairs=desktopPanels.compactMap { id,panel -> (CompanionPanel,PetView)? in guard let view=desktopViews[id] else { return nil };return (panel,view) }
        if let panel=petPanel,let view=petView { pairs.append((panel,view)) }
        for (panel,view) in pairs where panel.isVisible {
            let preferences=view.displayPreferences
            let positioning=view.desktopPhotoID.map { model.positioningPhotos.contains($0) } ?? model.positioningMain
            view.bar.viewWithTag(90)?.isHidden = !positioning
            if preferences.wallpaperEffect || preferences.floatingClickThrough {
                panel.ignoresMouseEvents=true
                if view.hovered { view.hovered=false }
                view.bounce = !preferences.wallpaperEffect && preferences.idleMotion && !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion ? CGFloat(sin(phase)*1.5):0
                continue
            }
            let local=NSPoint(x:NSEvent.mouseLocation.x-panel.frame.minX,y:NSEvent.mouseLocation.y-panel.frame.minY)
            let hit=view.containsVisiblePoint(local)
            panel.ignoresMouseEvents = !hit
            if view.hovered != (hit || positioning) { view.hovered=hit || positioning }
            view.bounce=preferences.idleMotion && !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion ? CGFloat(sin(phase)*1.5):0
        }
    }
    func syncDesktopPhotos() {
        let photos=model.settings.desktopPhotos ?? []
        let ids=Set(photos.map(\.id))
        for id in Array(desktopPanels.keys) where !ids.contains(id) { desktopViews[id]?.video.stop();desktopPanels.removeValue(forKey:id)?.close();desktopViews.removeValue(forKey:id) }
        for (index,item) in photos.enumerated() {
            guard let image=model.image(file:item.file) else { desktopViews[item.id]?.video.setPlaying(false);desktopPanels[item.id]?.orderOut(nil);continue }
            let isNew=desktopPanels[item.id] == nil
            if isNew {
                let panel=CompanionPanel(contentRect:NSRect(x:0,y:0,width:200,height:306),styleMask:[.borderless,.nonactivatingPanel],backing:.buffered,defer:false)
                panel.isOpaque=false;panel.backgroundColor = .clear;panel.hasShadow=false;panel.hidesOnDeactivate=false;panel.isReleasedWhenClosed=false;panel.isFloatingPanel=true
                let view=PetView(frame:NSRect(x:0,y:0,width:200,height:306));view.model=model;view.owner=self;view.desktopPhotoID=item.id;view.configureButtons();panel.contentView=view
                desktopPanels[item.id]=panel;desktopViews[item.id]=view
            }
            guard let panel=desktopPanels[item.id],let view=desktopViews[item.id] else { continue }
            view.setMedia(item.file)
            let visible=(panel.screen ?? NSScreen.main)?.visibleFrame ?? NSRect(x:0,y:0,width:1200,height:800)
            let height=min(max(100,item.height),max(100,min(700,visible.height-90)))
            panel.setContentSize(NSSize(width:min(max(height*image.size.width/max(image.size.height,1),145),min(620,visible.width-30)),height:height+46))
            if isNew { panel.setFrameOrigin(NSPoint(x:item.x ?? (visible.minX+25+Double(index%4)*180),y:item.y ?? (visible.minY+25+Double(index/4)*100))) }
            clampPetToScreen(panel:panel)
            let preferences=model.desktopPreferences(item,forPositioning:true)
            PetPresentation.apply(preferences,to:panel)
            if preferences.wallpaperEffect || preferences.floatingClickThrough { view.hovered=false }
            if preferences.petVisible { panel.orderFrontRegardless() } else { panel.orderOut(nil) }
            view.video.setPlaying(preferences.petVisible)
        }
        syncGalleryDisplay()
    }
    func saveDesktopPosition(_ id:UUID) {
        guard let panel=desktopPanels[id] else { return }
        var photos=model.settings.desktopPhotos ?? [];guard let i=photos.firstIndex(where:{$0.id==id}) else { return }
        photos[i].x=panel.frame.minX;photos[i].y=panel.frame.minY;model.settings.desktopPhotos=photos
    }
    func arrangeDesktopPhotos(in area:NSRect?=nil) {
        guard let visible=area ?? NSScreen.main?.visibleFrame else { return }
        let count=(model.settings.desktopPhotos ?? []).count+(model.currentImage == nil ? 0:1)
        guard count>0 else { return }
        // Keep a generous cell width so even landscape photos (whose panel has
        // a minimum width) cannot spill into the neighboring cell.
        let columns=max(1,min(count,Int(visible.width/240)))
        let rows=Int(ceil(Double(count)/Double(columns)))
        let cellWidth=visible.width/Double(columns),cellHeight=visible.height/Double(rows)
        let baseHeight=max(100,min(220,cellHeight-65))
        func fittedHeight(_ preferred:Double,_ image:NSImage?)->Double {
            guard let image,image.size.width > 0,image.size.height > 0 else { return preferred }
            let aspect=image.size.width/image.size.height
            // Desktop panels use at least 145 pt of image width and add a
            // small control strip; cap the height by the cell's safe width.
            let widthLimit=max(145,cellWidth-30)
            return max(100,min(preferred,widthLimit/max(0.45,aspect)))
        }
        var offset=0
        if model.currentImage != nil {
            let height=fittedHeight(baseHeight,model.currentImage)
            model.settings.preferences.personHeight=height
            model.settings.preferences.petX=visible.minX+15
            model.settings.preferences.petY=visible.minY+15
            petPanel?.setFrameOrigin(NSPoint(x:visible.minX+15,y:visible.minY+15));offset=1
        }
        var photos=model.settings.desktopPhotos ?? []
        for i in photos.indices {
            let slot=i+offset
            photos[i].height=fittedHeight(baseHeight,model.image(file:photos[i].file))
            photos[i].x=visible.minX+Double(slot%columns)*cellWidth+15
            photos[i].y=visible.minY+Double(slot/columns)*cellHeight+15
        }
        model.settings.desktopPhotos=photos
        for item in photos { if let x=item.x,let y=item.y { desktopPanels[item.id]?.setFrameOrigin(NSPoint(x:x,y:y)) } }
        model.notice="已自动排列桌面图片，可以继续单独拖动调整。"
    }
    func windowDidMove(_ notification:Notification) {
        guard let window=notification.object as? NSWindow,window === petPanel else { return }
        positionSpeech();positionTimer?.invalidate();positionTimer=Timer.scheduledTimer(withTimeInterval:0.35,repeats:false) { [weak self] _ in MainActor.assumeIsolated { guard let self,let panel=self.petPanel else { return };self.model.settings.preferences.petX=panel.frame.minX;self.model.settings.preferences.petY=panel.frame.minY } }
    }
    func applicationDidBecomeActive(_ notification:Notification) { model?.reloadPhotoPreviews() }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender:NSApplication)->Bool { false }
    func applicationShouldHandleReopen(_ sender:NSApplication,hasVisibleWindows flag:Bool)->Bool { showSettings();return true }
    func applicationWillTerminate(_ notification:Notification) { closeGalleryDisplay();petView?.video.stop();for view in desktopViews.values { view.video.stop() };globalPetHotKey.stop(); animationTimer?.invalidate();speechTimer?.invalidate();positionTimer?.invalidate();model?.saveSettings();model?.saveHistory() }
    @objc func quit() { NSApp.terminate(nil) }
    @objc func about() { NSApp.orderFrontStandardAboutPanel(options:[.applicationName:"伴伴",.applicationVersion:"1.0.0",.credits:NSAttributedString(string:"你的真人桌面伙伴\n人物照片由你导入 · DeepSeek API 对话\nAPI Key 保存在本机配置")]) }
}
