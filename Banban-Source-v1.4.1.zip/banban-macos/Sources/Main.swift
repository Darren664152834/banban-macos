import AppKit
@main struct BanbanMain {
    @MainActor static func main() {
        #if SELF_TEST
        runSelfTests()
        #else
        let application=NSApplication.shared
        let delegate=CompanionAppDelegate()
        application.delegate=delegate
        application.run()
        withExtendedLifetime(delegate) {}
        #endif
    }
}
