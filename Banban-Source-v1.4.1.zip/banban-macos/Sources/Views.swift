import SwiftUI
import AppKit

// Explicit wrapper alias avoids the SDK 27 @State macro on command-line Swift builds.
typealias StoredViewState<Value> = SwiftUI.State<Value>

extension Color {
    static let companionPurple=Color(red:0.62,green:0.47,blue:0.76)
    static let companionInk=Color(red:0.22,green:0.18,blue:0.26)
    static let companionMuted=Color(red:0.51,green:0.46,blue:0.55)
    static let companionPaper=Color(red:0.985,green:0.972,blue:0.963)
}
struct PrimaryButton:ButtonStyle {
    func makeBody(configuration:Configuration)->some View { configuration.label.font(.system(size:13,weight:.medium)).padding(.horizontal,17).padding(.vertical,11).foregroundStyle(.white).background(Color.companionPurple.opacity(configuration.isPressed ? 0.8:1),in:RoundedRectangle(cornerRadius:10)) }
}
// System Liquid Glass on supported macOS; preserve older systems and accessibility settings.
struct SidebarMaterial:NSViewRepresentable {
    func makeNSView(context:Context)->NSVisualEffectView {
        let view=NSVisualEffectView();view.material = .sidebar;view.blendingMode = .withinWindow;view.state = .active;return view
    }
    func updateNSView(_ nsView:NSVisualEffectView,context:Context) {}
}
struct SidebarNavigationButton:View {
    let title:String;let symbol:String;let selected:Bool;let action:()->Void
    @StoredViewState<Bool> private var hovered=false
    var body:some View {
        Button(action:action) {
            HStack(spacing:10) { Image(systemName:symbol).font(.system(size:14,weight:selected ? .semibold:.regular)).frame(width:21);Text(title);Spacer(minLength:0) }
                .font(.system(size:13,weight:selected ? .semibold:.medium)).padding(.horizontal,12).padding(.vertical,12).frame(maxWidth:.infinity)
        }
        .buttonStyle(SidebarGlassStyle(selected:selected,hovered:hovered)).onHover { hovered=$0 }
        .accessibilityLabel(title).accessibilityValue(selected ? "已选中":"")
    }
}
struct SidebarGlassStyle:ButtonStyle {
    let selected:Bool;let hovered:Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    func makeBody(configuration:Configuration)->some View {
        let content=configuration.label.foregroundStyle(selected ? Color.companionPurple:Color.companionInk.opacity(hovered ? 1:0.78))
        return Group {
            if #available(macOS 26.0,*),!reduceTransparency {
                content.glassEffect(.regular.tint(selected ? Color.companionPurple.opacity(0.23):Color.white.opacity(hovered ? 0.22:0.04)).interactive(),in:.rect(cornerRadius:12))
            } else {
                content.background(reduceTransparency ? Color.companionPaper:Color.white.opacity(hovered ? 0.45:0.15),in:RoundedRectangle(cornerRadius:12))
                    .background(.regularMaterial,in:RoundedRectangle(cornerRadius:12))
                    .overlay(RoundedRectangle(cornerRadius:12).fill(Color.companionPurple.opacity(selected ? 0.14:0)))
                    .overlay(RoundedRectangle(cornerRadius:12).strokeBorder(Color.white.opacity(0.7),lineWidth:0.6))
            }
        }
        .overlay(alignment:.leading) { Capsule().fill(Color.companionPurple).frame(width:3,height:17).opacity(selected ? 1:0).padding(.leading,3) }
        .brightness(configuration.isPressed ? -0.035:0)
        .scaleEffect(reduceMotion ? 1:(configuration.isPressed ? 0.975:(hovered ? 1.015:1)))
        .shadow(color:Color.companionPurple.opacity(selected ? 0.13:(hovered ? 0.08:0)),radius:hovered ? 7:4,y:2)
        .animation(reduceMotion ? nil:.spring(response:0.24,dampingFraction:0.82),value:configuration.isPressed)
        .animation(reduceMotion ? nil:.easeOut(duration:0.16),value:hovered)
        .animation(reduceMotion ? nil:.easeOut(duration:0.18),value:selected)
    }
}
struct CompanionSettingsView:View {
    @ObservedObject var model:CompanionModel
    let items:[(String,String)]=[("人物照片","photo.on.rectangle"),("表情动作","face.smiling"),("角色设定","person.text.rectangle"),("AI 接口","key.horizontal"),("桌面摆放","square.grid.3x2"),("桌面偏好","slider.horizontal.3")]
    var body:some View {
        HStack(spacing:0) {
            VStack(alignment:.leading,spacing:26) {
                HStack(spacing:10) { Image(systemName:"heart.fill").font(.system(size:28)).foregroundStyle(Color.companionPurple);VStack(alignment:.leading,spacing:2) { Text("伴伴").font(.system(size:22,weight:.semibold));Text("Quiet Companion").font(.system(size:10)).foregroundStyle(Color.companionMuted) } }.padding(.top,16)
                ProfilePicker(model:model)
                VStack(spacing:5) { ForEach(items,id:\.0) { item in
                    SidebarNavigationButton(title:item.0,symbol:item.1,selected:model.section==item.0) { model.section=item.0;model.notice="" }
                } }
                Spacer()
                VStack(alignment:.leading,spacing:8) { Label(model.hasPhoto ? "人物已就绪":"等待你的照片",systemImage:model.hasPhoto ? "checkmark.circle":"photo");Label(model.hasKey ? "API 已保存":"待配置 AI 接口",systemImage:model.hasKey ? "checkmark.shield":"key") }.font(.system(size:10)).foregroundStyle(Color.companionMuted)
                Text("照片保留在本机\n让陪伴，有你的样子").font(.system(size:10)).lineSpacing(4).foregroundStyle(Color.companionMuted.opacity(0.8))
            }.padding(22).frame(width:193).background(SidebarMaterial())
            VStack(spacing:0) {
                ScrollView {
                    VStack(alignment:.leading,spacing:23) {
                        if !model.error.isEmpty { Banner(text:model.error,isError:true) { model.error="" } }
                        if !model.notice.isEmpty { Banner(text:model.notice,isError:false) { model.notice="" } }
                        switch model.section {
                        case "表情动作":PoseLibraryView(model:model)
                        case "角色设定":RoleEditor(model:model).id(model.settings.activeProfileID)
                        case "AI 接口":APIEditor(model:model)
                        case "桌面摆放":DesktopPhotosEditor(model:model)
                        case "桌面偏好":PreferencesEditor(model:model)
                        default:PhotoSetup(model:model)
                        }
                    }.padding(30).frame(maxWidth:.infinity,alignment:.leading)
                }
                HStack { Text("伴伴 · Mac 桌面版");Spacer();Button("打开聊天") { model.onShowChat?() }.disabled(!model.roleReady) }.font(.system(size:10)).foregroundStyle(Color.companionMuted).padding(.horizontal,25).padding(.vertical,13).background(Color.white.opacity(0.5))
            }.frame(maxWidth:.infinity,maxHeight:.infinity).background(Color.companionPaper)
        }.foregroundStyle(Color.companionInk).frame(minWidth:780,minHeight:650).tint(.companionPurple)
    }
}
struct ProfilePicker:View {
    @ObservedObject var model:CompanionModel
    var body:some View {
        VStack(alignment:.leading,spacing:6) {
            Text("当前角色").font(.system(size:10)).foregroundStyle(Color.companionMuted)
            Picker("角色",selection:Binding(get:{model.settings.activeProfileID ?? UUID()},set:{model.switchProfile($0)})) {
                ForEach(model.settings.profiles ?? []) { item in Text(item.id==model.settings.activeProfileID ? model.displayName:item.role.name).tag(item.id) }
            }.labelsHidden().disabled(model.processingPhotos)
            Text(model.settings.scene?.name ?? "未设场景").font(.system(size:10)).foregroundStyle(Color.companionMuted)
        }
    }
}
struct SectionHeading:View {
    let eyebrow:String;let title:String;let subtitle:String
    var body:some View { VStack(alignment:.leading,spacing:10) { Text(eyebrow).font(.system(size:9,weight:.medium)).tracking(2.2).foregroundStyle(Color.companionPurple);Text(title).font(.system(size:29,weight:.medium,design:.serif));Text(subtitle).font(.system(size:12)).foregroundStyle(Color.companionMuted).lineSpacing(5) } }
}
struct Banner:View {
    let text:String;let isError:Bool;let close:()->Void
    var body:some View { HStack(alignment:.top,spacing:9) { Image(systemName:isError ? "exclamationmark.circle":"checkmark.circle");Text(text).font(.system(size:11)).lineSpacing(4).frame(maxWidth:.infinity,alignment:.leading);Button(action:close) { Image(systemName:"xmark").font(.system(size:10)) }.buttonStyle(.plain) }.padding(12).foregroundStyle(isError ? Color(red:0.65,green:0.24,blue:0.28):Color.companionPurple).background(isError ? Color.red.opacity(0.05):Color.companionPurple.opacity(0.07),in:RoundedRectangle(cornerRadius:10)) }
}
struct GalleryExitOverlay:View {
    let action:()->Void
    var body:some View {
        Button(action:action) { Label("退出展示",systemImage:"xmark.circle.fill").font(.system(size:12,weight:.semibold)).padding(.horizontal,13).padding(.vertical,9) }
            .buttonStyle(.plain).foregroundStyle(Color.companionInk).background(.regularMaterial,in:Capsule()).overlay(Capsule().stroke(Color.white.opacity(0.8),lineWidth:0.7)).shadow(color:.black.opacity(0.18),radius:8,y:3)
            .help("退出独立照片展示")
    }
}
struct PhotoSetup:View {
    @ObservedObject var model:CompanionModel
    var body:some View {
        SectionHeading(eyebrow:"YOUR OWN COMPANION",title:"让陪伴，有你的样子",subtitle:"导入全身照片或视频；视频会在桌面静音循环播放。")
        Button { model.importPhotos() } label: {
            HStack(spacing:22) {
                if let photo=model.baseImage { Image(nsImage:photo).resizable().scaledToFit().frame(width:150,height:235).padding(12) }
                else { VStack(spacing:15) { Image(systemName:"plus.circle.fill").font(.system(size:42,weight:.light)).foregroundStyle(Color.companionPurple);Text("导入人物照片或视频").font(.system(size:16,weight:.medium));Text("图片 · MP4 · MOV · M4V").font(.system(size:10)).foregroundStyle(Color.companionMuted) }.frame(maxWidth:.infinity,minHeight:235) }
                if model.baseImage != nil { VStack(alignment:.leading,spacing:12) { Text("你的默认形象").font(.system(size:17,weight:.medium));Text("用于待机，以及尚未配置的表情。\n点击这里即可更换照片。").font(.system(size:12)).lineSpacing(5).foregroundStyle(Color.companionMuted);Label("更换照片或视频",systemImage:"arrow.up.right").font(.system(size:12)).foregroundStyle(Color.companionPurple) }.frame(maxWidth:.infinity,alignment:.leading) }
            }.padding(18).frame(maxWidth:.infinity).background(.white.opacity(0.75),in:RoundedRectangle(cornerRadius:18)).overlay(RoundedRectangle(cornerRadius:18).strokeBorder(Color.companionPurple.opacity(0.35),style:StrokeStyle(lineWidth:1,dash:[4,4])))
        }.buttonStyle(.plain)
        PhotoImportOptions(model:model)
        if model.baseImage != nil {
            HStack {
                Button("去除背景") { model.cutoutPhoto() }.disabled(!BackgroundRemoval.available || model.processingPhotos || DiskStore.isVideo(model.settings.basePhoto))
                Button("用预览精修") { model.editPhotoInPreview() }.disabled(model.processingPhotos || DiskStore.isVideo(model.settings.basePhoto))
                Button("添加到桌面") { model.addDesktopPhoto(file:model.settings.basePhoto,name:"默认形象") }
                Button(DiskStore.isVideo(model.settings.basePhoto) ? "清空默认视频":"清空默认照片",role:.destructive) { model.removePhoto() }.disabled(model.processingPhotos)
            }.buttonStyle(.bordered)
        }
        if model.previousPhotos["base"] != nil { Button("撤销删除／恢复抠图前照片") { model.restorePhoto() }.disabled(model.processingPhotos) }
        Text("推荐清晰的单人全身照。自动抠图在本机处理，复杂背景或多人照片可能需要手动精修。请使用本人或已获授权的照片。").font(.system(size:11)).lineSpacing(5).foregroundStyle(Color.companionMuted)
        Divider().padding(.vertical,4)
        HStack { Text("独立照片／视频展示").font(.system(size:15,weight:.medium));Spacer();Text("已导入 \(model.displayableMediaCount) 个").font(.system(size:11)).foregroundStyle(Color.companionMuted) }
        Text("按导入顺序，根据每张照片或视频的原始比例自动排列全部内容。数量较多时自动缩小，完整保留画面，并为右上角退出按钮预留空间。").font(.system(size:11)).lineSpacing(4).foregroundStyle(Color.companionMuted)
        HStack(spacing:10) {
            Button { model.importPhotos(gallery:true) } label: { Label("批量导入照片",systemImage:"photo.badge.plus") }.buttonStyle(.bordered)
            Button("清空照片",role:.destructive) { model.clearGalleryPhotos() }.buttonStyle(.bordered).disabled(model.displayableMediaCount == 0 || model.processingPhotos)
            Button { model.displayAllImportedPhotos() } label: { Label("一键展示",systemImage:"rectangle.3.group") }.buttonStyle(PrimaryButton()).disabled(model.displayableMediaCount == 0 || model.processingPhotos)
            Button("退出展示",role:.destructive) { model.exitAllPhotoDisplay() }.buttonStyle(.bordered).disabled(model.galleryDisplayFiles.isEmpty || model.processingPhotos)
        }
        HStack(spacing:12) {
            Button { if model.hasPhoto { model.settings.preferences.petVisible=true;model.onSettingsChanged?() } else { model.importPhotos() } } label: { Label(model.hasPhoto ? "显示到桌面":"选择照片或视频",systemImage:model.hasPhoto ? "desktopcomputer":"square.and.arrow.up") }.buttonStyle(PrimaryButton())
            Button("配置表情动作") { model.section="表情动作" }.buttonStyle(.bordered)
        }
        Divider().padding(.vertical,4)
        VStack(alignment:.leading,spacing:12) { Text("一点互动，一点好心情").font(.system(size:13,weight:.medium));HStack(spacing:20) { Label("拖动移动",systemImage:"hand.draw");Label("双击聊天",systemImage:"bubble.left");Label("右键菜单",systemImage:"cursorarrow.click.2") }.font(.system(size:11)).foregroundStyle(Color.companionMuted);Text("滚轮缩放人物；从菜单栏的爱心图标随时找回伙伴、打开设置或退出。").font(.system(size:11)).foregroundStyle(Color.companionMuted) }
    }
}
struct PoseLibraryView:View {
    @ObservedObject var model:CompanionModel
    @StoredViewState<String> var category="全部"
    var filtered:[Pose] { category=="全部" ? Pose.all:Pose.all.filter{$0.category==category} }
    var body:some View {
        SectionHeading(eyebrow:"A MOOD FOR EVERY MOMENT",title:"每一种心情，都有回应",subtitle:"20 个动作位置，可以分别上传照片或循环视频。回复时自动选择对应动作。")
        PhotoImportOptions(model:model)
        HStack { Picker("分类",selection:$category) { ForEach(["全部","日常","情绪","互动"],id:\.self) { Text($0) } }.pickerStyle(.segmented).frame(maxWidth:300);Spacer();Text("已配置 \(model.configuredCount) / 20").font(.system(size:11)).foregroundStyle(Color.companionMuted) }
        LazyVGrid(columns:Array(repeating:GridItem(.flexible(),spacing:12),count:4),spacing:14) { ForEach(filtered) { pose in
            VStack(spacing:8) {
                Button { model.importPhotos(for:pose.id) } label: { Group { if let photo=model.image(file:model.settings.posePhotos[pose.id]) { Image(nsImage:photo).resizable().scaledToFit().frame(height:125) } else { VStack(spacing:10) { Image(systemName:"plus").font(.system(size:21,weight:.light));Text("照片／视频").font(.system(size:10)) }.foregroundStyle(Color.companionMuted).frame(maxWidth:.infinity).frame(height:125) } }.padding(8).frame(maxWidth:.infinity).background(Color(red:0.947,green:0.917,blue:0.909),in:RoundedRectangle(cornerRadius:10)) }.buttonStyle(.plain).help("导入「\(pose.name)」的照片或视频")
                HStack { Text(pose.name).font(.system(size:11));Spacer();Button { model.selectPose(pose.id) } label: { Image(systemName:"play.circle").font(.system(size:15)) }.buttonStyle(.plain).foregroundStyle(Color.companionPurple).help("在桌面预览") }.padding(.horizontal,3)
                if let file=model.settings.posePhotos[pose.id] {
                    HStack(spacing:8) {
                        Button("抠图") { model.cutoutPhoto(pose:pose.id) }.disabled(!BackgroundRemoval.available || model.processingPhotos || DiskStore.isVideo(file))
                        Button("删除",role:.destructive) { model.removePhoto(pose:pose.id) }.disabled(model.processingPhotos)
                    }.buttonStyle(.borderless).font(.system(size:11))
                    Button("预览精修") { model.editPhotoInPreview(pose:pose.id) }.buttonStyle(.borderless).font(.system(size:10)).disabled(model.processingPhotos || DiskStore.isVideo(file))
                    Button("添加到桌面") { model.addDesktopPhoto(file:file,name:pose.name) }.buttonStyle(.borderless).font(.system(size:10))
                }
                if model.previousPhotos[pose.id] != nil { Button("撤销／恢复原图") { model.restorePhoto(pose:pose.id) }.buttonStyle(.borderless).font(.system(size:10)).disabled(model.processingPhotos) }
            }.contextMenu { Button("导入照片或视频") { model.importPhotos(for:pose.id) };Button("预览") { model.selectPose(pose.id) };if model.settings.posePhotos[pose.id] != nil { Button("移除此动作的素材",role:.destructive) { model.removePhoto(pose:pose.id) } } }
        } }
        HStack { Button { model.importPhotos(batch:true) } label: { Label("批量导入动作素材",systemImage:"square.and.arrow.down") }.buttonStyle(.bordered);Text("动作批量导入会按文件名匹配 20 个表情位置；独立照片展示请到「人物照片」。").font(.system(size:10)).foregroundStyle(Color.companionMuted) }
        Text("未配置动作使用默认素材。视频静音循环播放；导入文件保留在本机，原文件不会修改。").font(.system(size:11)).lineSpacing(4).foregroundStyle(Color.companionMuted)
    }
}
struct PhotoImportOptions:View {
    @ObservedObject var model:CompanionModel
    var body:some View {
        VStack(alignment:.leading,spacing:8) {
            Toggle("导入时自动去除背景",isOn:$model.settings.preferences.autoRemoveBackground).disabled(!BackgroundRemoval.available || model.processingPhotos)
            Text(BackgroundRemoval.available ? "使用 macOS 本机抠图，输出透明 PNG，保留原文件；仅处理照片，视频保留原背景。":"自动抠图需要 macOS 14 或更新版本，可先用预览处理后导入透明 PNG。").font(.system(size:10)).foregroundStyle(Color.companionMuted)
            if model.processingPhotos { HStack { ProgressView().controlSize(.small);Text("正在处理照片，请稍候…").font(.system(size:11)) } }
        }.font(.system(size:12))
    }
}
struct DesktopAppearanceControls:View {
    @Binding var preferences:Preferences
    var onModeSelected:((String)->Void)? = nil
    var mode:Binding<String> { Binding(get:{ preferences.displayMode },set:{ value in
        if let onModeSelected { onModeSelected(value) }
        else { var next=preferences;next.setDisplayMode(value);preferences=next }
    }) }
    var body:some View {
        VStack(alignment:.leading,spacing:12) {
            HStack { Text("不透明度");Slider(value:$preferences.opacity,in:0...1,step:0.01);Text("\(Int(preferences.opacity*100))%").frame(width:38) }
            Text("0% 完全透明 · 100% 完全不透明；看不见时可在设置中恢复。").foregroundStyle(Color.companionMuted).font(.system(size:10))
            Text("仅设置这一个桌宠的显示模式").foregroundStyle(Color.companionMuted)
            HStack(spacing:6) {
                ForEach([("interactive","普通互动"),("wallpaper","壁纸穿透"),("floating","悬浮穿透")],id:\.0) { item in
                    Button { mode.wrappedValue=item.0 } label: {
                        HStack(spacing:4) { Image(systemName:mode.wrappedValue==item.0 ? "checkmark.circle.fill":"circle");Text(item.1) }.frame(maxWidth:.infinity).padding(.vertical,4)
                    }.buttonStyle(.bordered).tint(mode.wrappedValue==item.0 ? Color.companionPurple:Color.gray)
                        .accessibilityLabel(item.1).accessibilityValue(mode.wrappedValue==item.0 ? "已选中":"未选中")
                }
            }
            HStack {
                Toggle("始终置顶",isOn:$preferences.alwaysOnTop).disabled(preferences.wallpaperEffect || preferences.floatingClickThrough)
                Toggle("所有桌面",isOn:$preferences.joinAllSpaces)
                Toggle("呼吸动效",isOn:$preferences.idleMotion).disabled(preferences.wallpaperEffect)
            }.toggleStyle(.checkbox)
        }.font(.system(size:11))
    }
}
struct DesktopPhotoCard:View {
    @ObservedObject var model:CompanionModel
    let item:DesktopPhoto
    var latest:DesktopPhoto { (model.settings.desktopPhotos ?? []).first(where:{$0.id==item.id}) ?? item }
    var preferences:Binding<Preferences> { Binding(get:{ model.desktopPreferences(latest) },set:{ value in model.editDesktopPreferences(item.id) { $0=value } }) }
    var body:some View {
        VStack(alignment:.leading,spacing:14) {
            HStack(spacing:16) {
                if let image=model.image(file:latest.file) { Image(nsImage:image).resizable().scaledToFit().frame(width:65,height:90) }
                VStack(alignment:.leading,spacing:10) {
                    HStack { Text(latest.name).font(.system(size:13,weight:.medium));if DiskStore.isVideo(latest.file) { Label("视频 · 循环",systemImage:"repeat").font(.system(size:10)).foregroundStyle(Color.companionPurple) } }
                    Slider(value:Binding(get:{ latest.height },set:{ model.setDesktopHeight(item.id,$0) }),in:100...700)
                    Text("人物高度 \(Int(latest.height))").font(.system(size:10)).foregroundStyle(Color.companionMuted)
                }
                Toggle("显示",isOn:Binding(get:{ latest.visible ?? true },set:{ model.setDesktopVisible(item.id,$0) })).toggleStyle(.switch).font(.system(size:11))
            }
            DesktopAppearanceControls(preferences:preferences,onModeSelected:{ model.setPresentationMode($0,for:item.id) })
            HStack {
                Button(model.positioningPhotos.contains(item.id) ? "完成摆放":"调整位置") { model.toggleDesktopPositioning(item.id) }.buttonStyle(.borderedProminent)
                Button("复制主桌宠设置") { model.resetDesktopPreferences(item.id) }.buttonStyle(.bordered)
                Spacer()
                Button("移出桌面",role:.destructive) { model.removeDesktopPhoto(item.id) }.buttonStyle(.bordered)
            }.font(.system(size:11))
            if model.positioningPhotos.contains(item.id) { Text("已临时允许拖动并置顶。拖到任意位置后点击「完成摆放」，恢复这张图片原来的穿透模式。").font(.system(size:11)).foregroundStyle(Color.companionPurple) }
        }.padding(16).background(.white.opacity(0.75),in:RoundedRectangle(cornerRadius:12))
    }
}
struct DesktopPhotosEditor:View {
    @ObservedObject var model:CompanionModel
    var body:some View {
        SectionHeading(eyebrow:"YOUR DESKTOP COLLECTION",title:"每个身影，都由你摆放",subtitle:"每张桌宠独立设置大小、透明度、显示模式和位置，改动一张不会影响其他图片。")
        HStack {
            Button("去选照片") { model.section="表情动作" }.buttonStyle(PrimaryButton())
            Button("自动排列全部") { model.onArrangeDesktop?() }.buttonStyle(.bordered).disabled(!model.hasPhoto)
            Button("退出照片展示",role:.destructive) { model.exitAllPhotoDisplay() }.buttonStyle(.bordered).disabled(model.galleryDisplayFiles.isEmpty)
        }
        Text("普通模式直接拖动、滚轮缩放。壁纸或悬浮穿透模式下，点击对应图片的「调整位置」即可临时解除穿透，摆好后完成。⌃⌥H 仍可快速隐藏／恢复全部桌宠。").font(.system(size:11)).lineSpacing(4).foregroundStyle(Color.companionMuted)
        if model.currentImage != nil {
            VStack(alignment:.leading,spacing:14) {
                HStack { Text("主桌宠 · 随对话切换表情").font(.system(size:13,weight:.medium));Spacer();Toggle("显示",isOn:$model.settings.preferences.mainPetVisible).toggleStyle(.switch).font(.system(size:11)) }
                HStack { Text("人物高度");Slider(value:$model.settings.preferences.personHeight,in:100...700);Text("\(Int(model.settings.preferences.personHeight))") }.font(.system(size:11))
                DesktopAppearanceControls(preferences:$model.settings.preferences,onModeSelected:{ model.setPresentationMode($0) })
                Button(model.positioningMain ? "完成摆放":"调整位置") { model.toggleMainPositioning() }.buttonStyle(.borderedProminent).font(.system(size:11))
            }.padding(16).background(.white.opacity(0.75),in:RoundedRectangle(cornerRadius:12))
        }
        ForEach(model.settings.desktopPhotos ?? []) { item in DesktopPhotoCard(model:model,item:item) }
        if (model.settings.desktopPhotos ?? []).isEmpty { Text("在「人物照片」或「表情动作」点击「添加到桌面」，最多额外摆放 20 张，也可重复添加同一张。人物照片中的独立展示库会自动排列全部素材，不受此数量限制。").font(.system(size:12)).foregroundStyle(Color.companionMuted) }
        Text("每张图片的设置、位置和大小自动保存在本机。移出桌面不删除照片库原图；额外照片保持选定形象，多个视频各自静音循环播放。").font(.system(size:11)).foregroundStyle(Color.companionMuted)
    }
}
struct RoleEditor:View {
    @ObservedObject var model:CompanionModel
    @StoredViewState<RoleSettings> private var draft:RoleSettings
    @StoredViewState<SceneSettings> private var scene:SceneSettings
    @StoredViewState<Bool> private var confirmDelete=false
    init(model:CompanionModel) { self.model=model;_draft=StoredViewState<RoleSettings>(initialValue:model.settings.role);_scene=StoredViewState<SceneSettings>(initialValue:model.settings.scene ?? SceneSettings.presets[2]) }
    var body:some View {
        SectionHeading(eyebrow:"MAKE IT PERSONAL",title:"认识你的伙伴",subtitle:"人物＋场景＋照片／视频组成一个角色。每个角色分别保存素材、桌面摆放和聊天记录。")
        HStack { Button("新建角色") { model.addProfile() };Button("复制当前角色") { model.addProfile(copy:true) };Button("删除当前角色",role:.destructive) { confirmDelete=true }.disabled((model.settings.profiles?.count ?? 0)<2) }.disabled(model.processingPhotos)
            .alert("删除当前角色？",isPresented:$confirmDelete) { Button("取消",role:.cancel) {};Button("删除",role:.destructive) { model.deleteActiveProfile() } } message: { Text("角色将从切换列表移除，本机素材文件保留。") }
        VStack(alignment:.leading,spacing:18) {
            EditField(title:"角色姓名 *",hint:"你希望如何称呼她",text:$draft.name)
            EditField(title:"与你的关系",hint:"例如：主人的女人、知心朋友、冒险搭档",text:$draft.relationship)
            EditArea(title:"性格 *",hint:"她是什么性格？如何与你相处？",text:$draft.personality,height:78)
            EditArea(title:"角色背景",hint:"身份、经历、喜好，以及你们的故事",text:$draft.background,height:100)
            EditArea(title:"说话方式",hint:"对你的称呼、语气、语言与回复长短",text:$draft.speakingStyle,height:75)
        }
        HStack { Button { model.saveRole(draft);model.saveScene(scene) } label: { Label("保存人物与场景",systemImage:"checkmark") }.buttonStyle(PrimaryButton()).disabled(draft.name.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty || draft.personality.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty || scene.name.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty);Button("撤销未保存修改") { draft=model.settings.role;scene=model.settings.scene ?? scene }.buttonStyle(.bordered) }
        Divider()
        Text("场景设定").font(.headline)
        Menu("选择场景预设") { ForEach(model.settings.scenes ?? []) { item in Button(item.name) { scene=item } } }
        EditField(title:"场景名称",hint:"例如：阳台，或自定义场景",text:$scene.name)
        EditArea(title:"场景描述",hint:"环境、氛围、人物位置与故事背景",text:$scene.detail,height:95)
        HStack {
            Button("保存到当前角色") { model.saveScene(scene) }.buttonStyle(PrimaryButton())
            Button("保存为场景预设") { model.saveScene(scene,asPreset:true) }
            Button("新建场景") { scene=SceneSettings(name:"自定义场景",detail:"") }
            Button("删除此预设",role:.destructive) { model.deleteScenePreset(scene.id);scene.id=UUID() }.disabled(!(model.settings.scenes ?? []).contains(where:{$0.id==scene.id}))
        }
        Button("配置此角色的照片／视频") { model.section="人物照片" }
        Text("场景用于 AI 对话背景，不会自动生成或替换照片、视频背景。人物、场景与最近聊天文字会发送至 DeepSeek；照片和视频保留在本机。").font(.system(size:11)).lineSpacing(4).foregroundStyle(Color.companionMuted)
    }
}
struct EditField:View {
    let title:String;let hint:String;@Binding var text:String
    var body:some View { VStack(alignment:.leading,spacing:8) { Text(title).font(.system(size:12,weight:.medium));TextField(hint,text:$text).textFieldStyle(.roundedBorder) } }
}
struct EditArea:View {
    let title:String;let hint:String;@Binding var text:String;let height:CGFloat
    var body:some View { VStack(alignment:.leading,spacing:8) { Text(title).font(.system(size:12,weight:.medium));TextEditor(text:$text).font(.system(size:12)).scrollContentBackground(.hidden).padding(8).frame(height:height).background(.white,in:RoundedRectangle(cornerRadius:8)).overlay(RoundedRectangle(cornerRadius:8).stroke(Color.companionPurple.opacity(0.2),lineWidth:1)).help(hint) } }
}
struct APIEditor:View {
    @ObservedObject var model:CompanionModel
    @StoredViewState<String> private var key=""
    @StoredViewState<String> private var provider:String
    @StoredViewState<String> private var endpoint:String
    @StoredViewState<String> private var modelName:String
    @StoredViewState<Bool> private var confirmRemove=false
    init(model:CompanionModel) { self.model=model;_provider=StoredViewState<String>(initialValue:model.settings.apiProvider ?? "DeepSeek");_endpoint=StoredViewState<String>(initialValue:model.settings.apiEndpoint ?? DeepSeekClient.endpoint.absoluteString);_modelName=StoredViewState<String>(initialValue:model.settings.model) }
    var body:some View {
        SectionHeading(eyebrow:"REAL CONVERSATIONS",title:"连接 AI 平台",subtitle:"选择常用平台，或填写任意 OpenAI 兼容接口。配置只保存在这台 Mac。")
        VStack(alignment:.leading,spacing:20) {
            VStack(alignment:.leading,spacing:8) { Text("平台预设").font(.system(size:12,weight:.medium));Picker("平台",selection:$provider) { ForEach(AIProviderPreset.presets) { preset in Text(preset.name).tag(preset.name) } }.labelsHidden().frame(width:300);Button("应用所选平台的默认地址和模型") { let preset=AIProviderPreset.preset(named:provider);endpoint=preset.endpoint;modelName=preset.model }.font(.system(size:10)) }
            VStack(alignment:.leading,spacing:9) { HStack { Text("API Key").font(.system(size:12,weight:.medium));Spacer();if model.hasKey { Label("已保存到本机",systemImage:"lock.shield").font(.system(size:10)).foregroundStyle(Color.companionPurple) } };SecureField(model.hasKey ? "留空则保留已保存的 Key":"粘贴此平台的 API Key（Ollama 可留空）",text:$key).textFieldStyle(.roundedBorder);Text("不会显示已保存的 Key。填写新 Key 并保存即可替换；本机 Ollama 不要求 Key。").font(.system(size:10)).foregroundStyle(Color.companionMuted) }
            EditField(title:"接口地址",hint:"https://…/chat/completions；远程接口使用 HTTPS",text:$endpoint)
            EditField(title:"模型名称",hint:"deepseek-chat / gpt-4o-mini / qwen-plus",text:$modelName)
            HStack(spacing:12) { Button { model.saveAPI(key:key,model:modelName,provider:provider,endpoint:endpoint);if model.error.isEmpty { key="" } } label: { Label("保存接口设置",systemImage:"lock") }.buttonStyle(PrimaryButton());Button { model.testConnection() } label: { if model.testing { ProgressView().controlSize(.small) } else { Text("测试已保存的连接") } }.buttonStyle(.bordered).disabled(model.testing) }
        }.padding(22).background(.white.opacity(0.6),in:RoundedRectangle(cornerRadius:16))
        VStack(alignment:.leading,spacing:11) { Label("Key 明文保存在本机配置文件中，照片只保留在本机。",systemImage:"lock.shield");Text("伴伴使用 OpenAI Chat Completions 兼容格式；只要平台提供兼容接口，就可以直接填写地址、模型和 Key。具体计费以对应平台为准。");HStack { Link("OpenAI 接口格式",destination:URL(string:"https://platform.openai.com/docs/api-reference/chat")!);Text("·");Link("DeepSeek 文档",destination:URL(string:"https://api-docs.deepseek.com/api/create-chat-completion")!);Text("·");Link("Ollama 兼容说明",destination:URL(string:"https://docs.ollama.com/openai")!) } }.font(.system(size:11)).lineSpacing(4).foregroundStyle(Color.companionMuted)
        if model.hasKey { Button("移除已保存的 API Key",role:.destructive) { confirmRemove=true }.font(.system(size:11)).confirmationDialog("移除这台 Mac 中为伴伴保存的 API Key？",isPresented:$confirmRemove) { Button("移除 API Key",role:.destructive) { model.deleteAPIKey() } } }
    }
}
struct PreferencesEditor:View {
    @ObservedObject var model:CompanionModel
    @StoredViewState<Bool> private var confirmClear=false
    var body:some View {
        SectionHeading(eyebrow:"JUST THE RIGHT DISTANCE",title:"刚刚好的陪伴",subtitle:"调整人物大小、显示方式与对话记录。")
        VStack(alignment:.leading,spacing:23) {
            VStack(alignment:.leading,spacing:12) { HStack { Text("人物高度");Spacer();Text("\(Int(model.settings.preferences.personHeight)) pt").foregroundStyle(Color.companionMuted) };Slider(value:$model.settings.preferences.personHeight,in:100...700,step:10) }.font(.system(size:12))
            VStack(alignment:.leading,spacing:12) { HStack { Text("人物不透明度");Spacer();Text("\(Int(model.settings.preferences.opacity*100))%").foregroundStyle(Color.companionMuted) };Slider(value:$model.settings.preferences.opacity,in:0...1,step:0.01) }.font(.system(size:12))
            Text("人物不透明度：0% 完全透明，100% 完全显示。可随时从设置恢复。").font(.system(size:10)).foregroundStyle(Color.companionMuted)
            VStack(alignment:.leading,spacing:12) { HStack { Text("聊天窗口透明度");Spacer();Text("\(Int(((1-model.settings.preferences.chatOpacity)*100).rounded()))%").foregroundStyle(Color.companionMuted) };Slider(value:Binding(get:{1-model.settings.preferences.chatOpacity},set:{model.settings.preferences.chatOpacity=1-$0}),in:0...1,step:0.01);Text("0% 为不透明背景，100% 为完全透明背景；文字、气泡和输入框保持清晰。").font(.system(size:10)).foregroundStyle(Color.companionMuted) }.font(.system(size:12))
            Divider()
            VStack(alignment:.leading,spacing:8) { HStack { Text("快速隐藏／恢复桌宠");Spacer();Text(GlobalPetHotKey.label).font(.system(size:15,weight:.medium,design:.monospaced)).foregroundStyle(Color.companionPurple) };Text("Control + Option + H；在其他软件中也能使用，再按一次恢复。").font(.system(size:10)).foregroundStyle(Color.companionMuted) }
            Toggle("显示全部桌面伙伴",isOn:$model.settings.preferences.petVisible)
            VStack(alignment:.leading,spacing:8) { Toggle("壁纸效果（鼠标穿透）",isOn:Binding(get:{model.settings.preferences.wallpaperEffect},set:{model.settings.preferences.setWallpaperEffect($0)}));Text("开启后融入桌面壁纸层，点击与滚动穿透至下方图标或窗口，停止人物悬停互动与气泡。通过菜单栏或 ⌃⌥H 管理显示；关闭此模式后恢复拖动互动。透明背景 PNG 的融合效果更自然。").font(.system(size:10)).lineSpacing(3).foregroundStyle(Color.companionMuted) }
            VStack(alignment:.leading,spacing:8) { Toggle("悬浮穿透（置顶但不挡鼠标）",isOn:Binding(get:{model.settings.preferences.floatingClickThrough},set:{model.settings.preferences.setFloatingClickThrough($0)}));Text("人物保持悬浮在其他软件前方，鼠标点击、拖拽与滚动穿透到下方内容。此模式不弹出人物互动按钮或悬浮气泡，可从菜单栏打开聊天。与壁纸效果二选一，两者都关闭则恢复普通互动。").font(.system(size:10)).lineSpacing(3).foregroundStyle(Color.companionMuted) }
            Toggle("始终在其他窗口上方",isOn:$model.settings.preferences.alwaysOnTop).disabled(model.settings.preferences.wallpaperEffect || model.settings.preferences.floatingClickThrough)
            Toggle("在所有桌面空间显示",isOn:$model.settings.preferences.joinAllSpaces)
            Toggle("轻微待机呼吸动效",isOn:$model.settings.preferences.idleMotion).disabled(model.settings.preferences.wallpaperEffect)
            Toggle("将聊天记录保存在本机",isOn:Binding(get:{model.settings.preferences.rememberHistory},set:{model.settings.preferences.rememberHistory=$0;model.saveHistory()}))
        }.font(.system(size:12)).toggleStyle(.switch).padding(22).background(.white.opacity(0.65),in:RoundedRectangle(cornerRadius:15))
        HStack { Button("把人物移回屏幕右下角") { model.settings.preferences.petX=nil;model.settings.preferences.petY=nil;NotificationCenter.default.post(name:.resetCompanionPosition,object:nil) }.buttonStyle(.bordered);Button("清空聊天记录",role:.destructive) { confirmClear=true }.buttonStyle(.bordered).disabled(model.messages.isEmpty) }.confirmationDialog("清空本机保存的聊天记录？",isPresented:$confirmClear) { Button("清空记录",role:.destructive) { model.clearHistory() } }
        Text("此页的人物外观与显示模式用于主桌宠。额外图片请在「桌面摆放」分别设置；快速隐藏快捷键管理全部图片。").font(.system(size:11)).foregroundStyle(Color.companionMuted)
        Text("关闭设置窗口后，伙伴仍可留在桌面。使用菜单栏爱心图标管理显示或退出。没有照片时不会显示占位人物。").font(.system(size:11)).lineSpacing(4).foregroundStyle(Color.companionMuted)
    }
}
struct CompanionChatView:View {
    @ObservedObject var model:CompanionModel
    @StoredViewState<String> private var input=""
    @StoredViewState<Bool> private var confirmClear=false
    @FocusState private var focused:Bool
    var body:some View {
        VStack(spacing:0) {
            HStack(spacing:12) { Image(systemName:"heart.fill").font(.system(size:25)).foregroundStyle(Color.companionPurple);VStack(alignment:.leading,spacing:4) { Text(model.displayName).font(.system(size:17,weight:.medium));Text(model.settings.role.relationship.isEmpty ? "你的 AI 伙伴":model.settings.role.relationship).font(.system(size:10)).foregroundStyle(Color.companionMuted) };Spacer();Menu { ForEach(model.settings.profiles ?? []) { profile in Button("切换："+profile.role.name) { model.switchProfile(profile.id) }.disabled(model.processingPhotos) };Divider();Button("角色设定") { model.section="角色设定";model.onShowSettings?() };Button("AI 接口设置") { model.section="AI 接口";model.onShowSettings?() };Button("清空聊天记录",role:.destructive) { confirmClear=true } } label: { Image(systemName:"ellipsis.circle").font(.system(size:19)) }.menuStyle(.borderlessButton).frame(width:25) }.padding(22)
            Divider().padding(.horizontal,20)
            ScrollViewReader { proxy in
                ScrollView { VStack(alignment:.leading,spacing:17) {
                    if model.messages.isEmpty { VStack(spacing:15) { Image(systemName:"bubble.left.and.bubble.right").font(.system(size:31,weight:.light)).foregroundStyle(Color.companionPurple.opacity(0.7));Text("今天，想聊些什么？").font(.system(size:23,weight:.medium,design:.serif));Text(model.hasKey ? "聊聊日常，或者开始你们的故事。":"先保存你的 AI 接口设置，再开始对话。").font(.system(size:12)).foregroundStyle(Color.companionMuted);if !model.hasKey { Button("配置 AI 接口") { model.section="AI 接口";model.onShowSettings?() }.buttonStyle(PrimaryButton()) } }.frame(maxWidth:.infinity).padding(.vertical,60) }
                    ForEach(model.messages) { message in
                        HStack { if message.role=="user" { Spacer(minLength:36) };VStack(alignment:message.role=="user" ? .trailing:.leading,spacing:5) { Text(message.content).font(.system(size:13)).lineSpacing(5).textSelection(.enabled).padding(13).foregroundStyle(message.role=="user" ? Color.white:Color.companionInk).background(message.role=="user" ? Color.companionPurple:Color.companionPurple.opacity(0.08),in:RoundedRectangle(cornerRadius:13));if message.state=="failed" { if let reason=message.failureReason { Text(reason).font(.system(size:10)).foregroundStyle(Color.red.opacity(0.8)).textSelection(.enabled) };Button { model.send(message.content,retryID:message.id) } label: { Label("未取得回复 · 重试",systemImage:"arrow.clockwise").font(.system(size:10)) }.buttonStyle(.plain).foregroundStyle(.red.opacity(0.7)).disabled(model.busy) } };if message.role != "user" { Spacer(minLength:36) } }.id(message.id)
                    }
                    if model.busy { HStack(spacing:9) { ProgressView().controlSize(.small);Text(model.chatStatus.isEmpty ? "\(model.displayName)正在回复…":model.chatStatus).font(.system(size:11)).foregroundStyle(Color.companionMuted) }.padding(9) }
                    Color.clear.frame(height:1).id("bottom")
                }.padding(20) }.onAppear { proxy.scrollTo("bottom",anchor:.bottom) }.onChange(of:model.chatScrollTarget) { target in if let target { withAnimation { proxy.scrollTo(target,anchor:.bottom) } } }
            }
            if !model.chatError.isEmpty { HStack(alignment:.top,spacing:7) { Image(systemName:"exclamationmark.circle");Text(model.chatError).frame(maxWidth:.infinity,alignment:.leading);Button { model.chatError="" } label: { Image(systemName:"xmark") }.buttonStyle(.plain) }.font(.system(size:11)).foregroundStyle(Color(red:0.65,green:0.28,blue:0.32)).padding(12).background(Color.red.opacity(0.04)).padding(.horizontal,17) }
            HStack(alignment:.center,spacing:10) { TextField("和\(model.displayName)说点什么…",text:$input,axis:.vertical).textFieldStyle(.plain).lineLimit(1...5).font(.system(size:13)).focused($focused).onSubmit(send);if model.busy { Button { model.cancel() } label: { Image(systemName:"stop.fill").font(.system(size:14)).padding(10) }.buttonStyle(.plain).foregroundStyle(Color.companionPurple).help("停止生成") } else { Button(action:send) { Image(systemName:"paperplane.fill").font(.system(size:16)).padding(10).foregroundStyle(.white).background(Color.companionPurple,in:RoundedRectangle(cornerRadius:9)) }.buttonStyle(.plain).disabled(input.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty).help("发送消息") } }.padding(11).background(.white,in:RoundedRectangle(cornerRadius:13)).overlay(RoundedRectangle(cornerRadius:13).stroke(Color.companionPurple.opacity(0.2),lineWidth:1)).padding(.horizontal,17).padding(.top,12)
            Text("AI 角色对话 · 由 DeepSeek 提供回复").font(.system(size:9)).foregroundStyle(Color.companionMuted).padding(.vertical,11)
        }.padding(.top,20).frame(minWidth:360,minHeight:490).background(Color.companionPaper.opacity(model.settings.preferences.chatOpacity)).foregroundStyle(Color.companionInk).tint(Color.companionPurple).onAppear { focused=true }.onChange(of:model.settings.activeProfileID) { _ in input="";confirmClear=false }.confirmationDialog("清空本机聊天记录？",isPresented:$confirmClear) { Button("清空记录",role:.destructive) { model.clearHistory() } }
    }
    func send() { let value=input.trimmingCharacters(in:.whitespacesAndNewlines);guard !value.isEmpty,!model.busy else { return };model.send(value);if model.busy { input="" };focused=true }
}
extension Notification.Name { static let resetCompanionPosition=Notification.Name("BanbanResetPosition") }
