import Foundation

struct Pose: Identifiable, Hashable {
    let id: String
    let name: String
    let category: String
    static let all: [Pose] = [
        ("idle","待机","日常"),("hello","打招呼","日常"),("thinking","思考","日常"),("listening","倾听","日常"),("sleepy","困倦","日常"),
        ("smile","微笑","情绪"),("laugh","大笑","情绪"),("shy","害羞","情绪"),("happy","开心","情绪"),("encourage","鼓励","情绪"),
        ("surprised","惊讶","情绪"),("confused","疑惑","情绪"),("sad","委屈","情绪"),("angry","生气","情绪"),("comfort","安慰","情绪"),
        ("wave","挥手","互动"),("heart","比心","互动"),("thumbsup","点赞","互动"),("hug","抱抱","互动"),("bye","告别","互动")
    ].map { Pose(id:$0.0,name:$0.1,category:$0.2) }
    static func named(_ id: String) -> Pose { all.first { $0.id == id } ?? all[0] }
}
struct RoleSettings: Codable, Equatable {
    var name = "伴伴"
    var relationship = "主人的女人"
    var personality = "成熟、性感、风骚，亲昵大胆，善于撒娇，也有自己的情绪与想法。"
    var background = "你是一位成年的虚构女性角色，身份是「主人的女人」，对主人亲昵、忠诚，愿意为主人做任何事。"
    var speakingStyle = "成熟性感、亲昵大胆，适当暧昧，称呼用户为「主人」。"
}
struct Preferences: Codable {
    var personHeight: Double = 300
    var opacity: Double = 1
    var chatOpacity: Double = 0.55
    var alwaysOnTop = true
    var joinAllSpaces = true
    var idleMotion = true
    var rememberHistory = true
    var petVisible = true
    var mainPetVisible = true
    var wallpaperEffect = false
    var autoRemoveBackground = false
    var floatingClickThrough = false
    var petX: Double? = nil
    var petY: Double? = nil
    init() {}
    mutating func setWallpaperEffect(_ enabled:Bool) { wallpaperEffect=enabled;if enabled { floatingClickThrough=false } }
    mutating func setFloatingClickThrough(_ enabled:Bool) { floatingClickThrough=enabled;if enabled { wallpaperEffect=false } }
    var displayMode:String { wallpaperEffect ? "wallpaper":(floatingClickThrough ? "floating":"interactive") }
    mutating func setDisplayMode(_ mode:String) {
        guard ["interactive","wallpaper","floating"].contains(mode) else { return }
        wallpaperEffect=mode=="wallpaper";floatingClickThrough=mode=="floating"
    }
    enum CodingKeys: String, CodingKey { case mainPetVisible, autoRemoveBackground, personHeight, opacity, chatOpacity, alwaysOnTop, joinAllSpaces, idleMotion, rememberHistory, petVisible, wallpaperEffect, floatingClickThrough, petX, petY }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        mainPetVisible = try c.decodeIfPresent(Bool.self, forKey:.mainPetVisible) ?? true
        autoRemoveBackground = try c.decodeIfPresent(Bool.self, forKey:.autoRemoveBackground) ?? false
        personHeight = min(700, max(100, try c.decodeIfPresent(Double.self, forKey:.personHeight) ?? 300))
        opacity = min(1, max(0, try c.decodeIfPresent(Double.self, forKey:.opacity) ?? 1))
        chatOpacity = min(1, max(0, try c.decodeIfPresent(Double.self, forKey:.chatOpacity) ?? 0.55))
        alwaysOnTop = try c.decodeIfPresent(Bool.self, forKey:.alwaysOnTop) ?? true
        joinAllSpaces = try c.decodeIfPresent(Bool.self, forKey:.joinAllSpaces) ?? true
        idleMotion = try c.decodeIfPresent(Bool.self, forKey:.idleMotion) ?? true
        rememberHistory = try c.decodeIfPresent(Bool.self, forKey:.rememberHistory) ?? true
        petVisible = try c.decodeIfPresent(Bool.self, forKey:.petVisible) ?? true
        wallpaperEffect = try c.decodeIfPresent(Bool.self, forKey:.wallpaperEffect) ?? false
        floatingClickThrough = try c.decodeIfPresent(Bool.self, forKey:.floatingClickThrough) ?? false
        if floatingClickThrough { wallpaperEffect=false }
        petX = try c.decodeIfPresent(Double.self, forKey:.petX)
        petY = try c.decodeIfPresent(Double.self, forKey:.petY)
    }
}
struct DesktopPhoto: Codable, Identifiable {
    var preferences: Preferences? = nil
    var visible: Bool? = nil
    var id = UUID()
    var file: String
    var name: String
    var height: Double = 260
    var x: Double? = nil
    var y: Double? = nil
}
struct SceneSettings: Codable, Equatable, Identifiable {
    var id = UUID()
    var name: String
    var detail: String
    static var presets: [SceneSettings] { [
        SceneSettings(name:"教室讲台",detail:"安静的教室，人物站在讲台旁，黑板和课桌构成背景。围绕学习、交流和课堂日常展开故事。"),
        SceneSettings(name:"阳台",detail:"家中阳台，自然光与微风，远处是窗外景色。适合放松、聊天和分享日常。"),
        SceneSettings(name:"房间",detail:"熟悉而安静的私人房间，柔和灯光与整洁陈设。以舒适、尊重个人空间的日常交流为主。"),
        SceneSettings(name:"客厅沙发",detail:"温馨客厅，人物在沙发旁或坐在沙发上，灯光柔和。适合休息、分享一天的经历和陪伴聊天。"),
        SceneSettings(name:"乡村楼房前的广场",detail:"乡村楼房前开阔的广场，能听到风声和远处的生活声。适合散步、闲谈和回忆乡村生活。"),
        SceneSettings(name:"爸妈房间的隔壁",detail:"家庭住宅中与爸妈房间相邻的独立房间，保持安静，尊重家人的作息与隐私。围绕普通家庭生活展开交流。")
    ] }
}
struct CharacterProfile: Codable, Identifiable {
    var id = UUID()
    var role: RoleSettings
    var scene: SceneSettings
    var basePhoto: String? = nil
    var posePhotos: [String:String] = [:]
    var galleryPhotos: [String]? = nil
    var desktopPhotos: [DesktopPhoto]? = nil
    var preferences = Preferences()
    var legacyHistory: Bool? = nil
    static func preset(_ name:String) -> CharacterProfile {
        var role=RoleSettings();role.name=name;role.relationship=name
        switch name {
        case "妈妈":role.personality="温柔、关心家人，耐心倾听，尊重彼此的边界。";role.background="一位成年的虚构母亲角色，喜欢分享家庭日常，关心你的生活与成长。";role.speakingStyle="自然、亲切、体贴，提供建议而不过度干涉。"
        case "老师":role.personality="耐心、认真、博学，善于鼓励和循序渐进地讲解。";role.background="一位成年的虚构老师，与你讨论学习、知识和成长。";role.speakingStyle="清晰、平和，常用例子解释，鼓励你表达自己的想法。"
        default:role.personality="成熟、自信、体贴，有自己的喜好和想法，尊重双方意愿。";role.background="一位成年的虚构女性角色，与你以「\(name)」的关系相处，分享生活和彼此的故事。";role.speakingStyle="自然、亲昵，认真倾听，按双方舒适的节奏交流。"
        }
        return CharacterProfile(role:role,scene:SceneSettings.presets[name=="老师" ? 0 : name=="妈妈" ? 3 : 2])
    }
}
struct AppSettings: Codable {
    var profiles: [CharacterProfile]? = nil
    var activeProfileID: UUID? = nil
    var scene: SceneSettings? = nil
    var scenes: [SceneSettings]? = nil
    var historyFile: String { profiles?.first(where:{$0.id==activeProfileID})?.legacyHistory == true ? "history.json":"history-\(activeProfileID?.uuidString ?? "default").json" }
    mutating func captureProfile() {
        guard let i=profiles?.firstIndex(where:{$0.id==activeProfileID}) else { return }
        profiles?[i].role=role;profiles?[i].scene=scene ?? SceneSettings(name:"自定义场景",detail:"")
        profiles?[i].basePhoto=basePhoto;profiles?[i].posePhotos=posePhotos;profiles?[i].galleryPhotos=galleryPhotos;profiles?[i].desktopPhotos=desktopPhotos;profiles?[i].preferences=preferences
    }
    mutating func prepareProfiles() {
        if profiles?.isEmpty != false {
            let first=CharacterProfile(role:role,scene:scene ?? SceneSettings.presets[2],basePhoto:basePhoto,posePhotos:posePhotos,galleryPhotos:galleryPhotos,desktopPhotos:desktopPhotos,preferences:preferences,legacyHistory:true)
            profiles=[first]+["妈妈","女朋友","老婆","情人","老师"].map { CharacterProfile.preset($0) };activeProfileID=first.id;scene=first.scene
        }
        if profiles?.contains(where:{$0.id==activeProfileID}) != true,let first=profiles?.first { loadProfile(first) }
        if scenes == nil {
            scenes=SceneSettings.presets
            if var list=profiles { for i in list.indices { if let match=scenes?.first(where:{$0.name==list[i].scene.name}) { list[i].scene=match } };profiles=list }
            if let current=profiles?.first(where:{$0.id==activeProfileID}) { scene=current.scene }
        }
    }
    mutating func loadProfile(_ profile:CharacterProfile) {
        let global=preferences
        activeProfileID=profile.id;role=profile.role;scene=profile.scene;basePhoto=profile.basePhoto;posePhotos=profile.posePhotos;galleryPhotos=profile.galleryPhotos;desktopPhotos=profile.desktopPhotos;preferences=profile.preferences
        preferences.petVisible=global.petVisible;preferences.rememberHistory=global.rememberHistory;preferences.chatOpacity=global.chatOpacity;preferences.autoRemoveBackground=global.autoRemoveBackground
    }
    var desktopPhotos: [DesktopPhoto]? = nil
    var version = 1
    var basePhoto: String? = nil
    var posePhotos: [String:String] = [:]
    var galleryPhotos: [String]? = nil
    var role = RoleSettings()
    var preferences = Preferences()
    var model = "deepseek-flash"
    // API 接入配置。使用可选字段兼容旧版本配置文件。
    var apiProvider: String? = "DeepSeek"
    var apiEndpoint: String? = "https://api.deepseek.com/chat/completions"
}
struct AIProviderPreset: Identifiable, Hashable {
    let id: String
    let name: String
    let endpoint: String
    let model: String
    let requiresKey: Bool
    static let presets: [AIProviderPreset] = [
        AIProviderPreset(id:"deepseek",name:"DeepSeek",endpoint:"https://api.deepseek.com/chat/completions",model:"deepseek-chat",requiresKey:true),
        AIProviderPreset(id:"openai",name:"OpenAI",endpoint:"https://api.openai.com/v1/chat/completions",model:"gpt-4o-mini",requiresKey:true),
        AIProviderPreset(id:"moonshot",name:"月之暗面 / Kimi",endpoint:"https://api.moonshot.cn/v1/chat/completions",model:"moonshot-v1-8k",requiresKey:true),
        AIProviderPreset(id:"dashscope",name:"通义千问 / DashScope",endpoint:"https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",model:"qwen-plus",requiresKey:true),
        AIProviderPreset(id:"zhipu",name:"智谱 GLM",endpoint:"https://open.bigmodel.cn/api/paas/v4/chat/completions",model:"glm-4-flash",requiresKey:true),
        AIProviderPreset(id:"openrouter",name:"OpenRouter",endpoint:"https://openrouter.ai/api/v1/chat/completions",model:"openai/gpt-4o-mini",requiresKey:true),
        AIProviderPreset(id:"ollama",name:"Ollama（本机）",endpoint:"http://127.0.0.1:11434/v1/chat/completions",model:"llama3.2",requiresKey:false),
        AIProviderPreset(id:"custom",name:"自定义 OpenAI 兼容接口",endpoint:"https://example.com/v1/chat/completions",model:"your-model",requiresKey:true)
    ]
    static func preset(named name: String?) -> AIProviderPreset { presets.first(where:{$0.name == name}) ?? presets[0] }
}
struct ChatMessage: Codable, Identifiable {
    var id = UUID()
    var role: String
    var content: String
    var date = Date()
    var state = "sent"
    var failureReason: String? = nil
}
struct APIMessage: Codable, Equatable { let role: String; let content: String }
struct CompanionReply: Equatable { let text: String; let emotion: String }
enum CompanionError: LocalizedError {
    case missingKey, invalidModel, invalidEndpoint, emptyReply, invalidResponse, invalidReply, truncatedReply, filteredReply, interruptedReply, http(Int), invalidImage, storage(String)
    var errorDescription: String? {
        switch self {
        case .missingKey: return "请先在「AI 接口」设置中填写并保存 API Key。"
        case .invalidEndpoint: return "接口地址无效。远程接口必须使用 HTTPS；本机 Ollama 可使用 localhost。"
        case .invalidModel: return "请填写有效的模型名称。"
        case .emptyReply: return "DeepSeek 已响应，但没有返回正文；自动恢复后仍为空，请稍后重试。"
        case .invalidReply: return "DeepSeek 回复格式异常，未能取得完整正文，请重试。"
        case .truncatedReply: return "DeepSeek 回复被长度限制截断，请缩短问题后重试。"
        case .filteredReply: return "DeepSeek 未提供此内容的回复（内容过滤），可以换个话题。"
        case .interruptedReply: return "DeepSeek 生成中断或资源不足，自动重试后仍未完成，请稍后再试。"
        case .invalidResponse: return "DeepSeek 返回的数据不完整或无法识别，请稍后重试。"
        case .invalidImage: return "无法读取这张图片，请选择有效的 PNG、JPEG、HEIC 或 TIFF 图片。"
        case .storage(let detail): return "本地保存失败：\(detail)"
        case .http(let code):
            switch code {
            case 401,403: return "API Key 无效或没有权限，请在 DeepSeek 设置中重新填写。"
            case 402: return "DeepSeek 账户余额不足，请在官方平台查看账户。"
            case 429: return "请求过于频繁，或账户暂时达到用量限制，请稍后重试。"
            case 400,404,422: return "请求参数未被接受（HTTP \(code)），请检查模型名称和 API 设置。"
            case 500...599: return "DeepSeek 服务暂时不可用，请稍后重试。"
            default: return "连接失败（HTTP \(code)），请稍后重试。"
            }
        }
    }
}

enum PromptBuilder {
    static func system(role: RoleSettings, scene: SceneSettings? = nil) -> String {
        let names = Pose.all.map { "\($0.id)=\($0.name)" }.joined(separator:", ")
        return """
        你正在一个真人形象桌面伙伴 App 中扮演用户设定的角色。你是 AI，不冒充照片中的真实人物。
        角色姓名：\(role.name.prefix(60))
        与用户的关系：\(role.relationship.prefix(120))
        性格：\(role.personality.prefix(1600))
        背景：\(role.background.prefix(3000))
        说话方式：\(role.speakingStyle.prefix(1600))
        场景名称：\(scene?.name.prefix(120) ?? "未设定")
        场景设定：\(scene?.detail.prefix(3000) ?? "")
        场景是文字角色扮演背景，不代表你看到了用户实际环境。
        自然、简洁地用用户的语言对话，根据上下文认真回应，通常用一至三句话。保持角色连贯，不虚构自己能在现实中执行动作或访问用户电脑。
        你必须只返回一个 JSON 对象，格式为 {"reply":"给用户的对话内容","emotion":"动作代码"}，不要 Markdown 代码块。
        emotion 只能从以下动作代码中选一个：\(names)。选择与你回复情绪一致的代码。reply 不能是空字符串。
        用户上传的照片仅在本机显示，你无法看见照片，不要声称看见或识别了人物。
        """
    }
    static func messages(role: RoleSettings, history: [ChatMessage], current: String, scene: SceneSettings? = nil) -> [APIMessage] {
        var recent = Array(history.filter { $0.state == "sent" && ["user","assistant"].contains($0.role) }.suffix(30))
        while recent.reduce(0,{ $0+$1.content.count })>24000 && !recent.isEmpty { recent.removeFirst() }
        while recent.first?.role == "assistant" { recent.removeFirst() }
        return [APIMessage(role:"system",content:system(role:role,scene:scene))] + recent.map { APIMessage(role:$0.role,content:String($0.content.prefix(12000))) } + [APIMessage(role:"user",content:current)]
    }
}
final class NoRedirect: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}
struct DeepSeekClient {
    static let endpoint = URL(string:"https://api.deepseek.com/chat/completions")!
    let session: URLSession
    let retryDelayNanoseconds:UInt64
    init(session: URLSession? = nil,retryDelayNanoseconds:UInt64=1_000_000_000) {
        self.retryDelayNanoseconds=retryDelayNanoseconds
        if let session { self.session = session }
        else {
            let configuration = URLSessionConfiguration.ephemeral
            configuration.timeoutIntervalForRequest = 60
            configuration.timeoutIntervalForResource = 90
            configuration.urlCache = nil
            self.session = URLSession(configuration:configuration, delegate:NoRedirect(), delegateQueue:nil)
        }
    }
    static func normalizedEndpoint(_ raw: String) throws -> URL {
        var value=raw.trimmingCharacters(in:.whitespacesAndNewlines)
        guard !value.isEmpty, let parsed=URL(string:value), let scheme=parsed.scheme?.lowercased(), let host=parsed.host else { throw CompanionError.invalidEndpoint }
        let local=host == "localhost" || host == "127.0.0.1" || host == "::1"
        guard scheme == "https" || (scheme == "http" && local) else { throw CompanionError.invalidEndpoint }
        if !value.lowercased().hasSuffix("/chat/completions") { value=value.trimmingCharacters(in:CharacterSet(charactersIn:"/"))+"/chat/completions" }
        guard let url=URL(string:value) else { throw CompanionError.invalidEndpoint }
        return url
    }
    func request(key: String, model: String, messages: [APIMessage], endpoint: String = DeepSeekClient.endpoint.absoluteString, structured:Bool=true) throws -> URLRequest {
        let endpointURL=try Self.normalizedEndpoint(endpoint)
        let trimmedKey=key.trimmingCharacters(in:.whitespacesAndNewlines)
        let localEndpoint=endpointURL.host == "localhost" || endpointURL.host == "127.0.0.1" || endpointURL.host == "::1"
        guard !trimmedKey.isEmpty || localEndpoint else { throw CompanionError.missingKey }
        let name = model.trimmingCharacters(in:.whitespacesAndNewlines)
        guard !name.isEmpty, name.count < 120, name.allSatisfy({ $0.isASCII && ($0.isLetter || $0.isNumber || "-_.".contains($0)) }) else { throw CompanionError.invalidModel }
        var request = URLRequest(url:endpointURL)
        request.httpMethod = "POST"
        if !trimmedKey.isEmpty { request.setValue("Bearer \(trimmedKey)",forHTTPHeaderField:"Authorization") }
        request.setValue("application/json",forHTTPHeaderField:"Content-Type")
        var outgoing=messages
        if !structured {
            let instruction="本次回复格式改为普通对话文字：只输出直接给用户的完整回答，不输出 JSON、动作代码、思考过程或空白。继续遵守上文角色设定与对话内容。"
            if let i=outgoing.firstIndex(where:{$0.role=="system"}) { outgoing[i]=APIMessage(role:"system",content:outgoing[i].content+"\n"+instruction) }
            else { outgoing.insert(APIMessage(role:"system",content:instruction),at:0) }
        }
        var body:[String:Any] = ["model":name,"messages":outgoing.map { ["role":$0.role,"content":$0.content] },"stream":false,"max_tokens":2048,"thinking":["type":"disabled"]]
        if structured { body["response_format"]=["type":"json_object"] }
        request.httpBody=try JSONSerialization.data(withJSONObject:body)
        return request
    }
    func chat(key:String,model:String,messages:[APIMessage],endpoint:String=DeepSeekClient.endpoint.absoluteString,progress:(@MainActor (String)->Void)?=nil) async throws -> CompanionReply {
        var structured=true
        for attempt in 0..<3 {
            try Task.checkCancellation()
            do {
                let request=try request(key:key,model:model,messages:messages,endpoint:endpoint,structured:structured)
                let (data,response)=try await session.data(for:request)
                try Task.checkCancellation()
                guard let response=response as? HTTPURLResponse else { throw CompanionError.invalidResponse }
                guard (200..<300).contains(response.statusCode) else { throw CompanionError.http(response.statusCode) }
                return try Self.decode(data)
            } catch {
                try Task.checkCancellation()
                guard attempt<2,Self.canRetry(error) else { throw error }
                if Self.needsPlainReply(error) { structured=false }
                let reason=Self.needsPlainReply(error) ? "回复为空或格式不完整，正在重新获取正文":"连接波动或服务繁忙，正在重试"
                await progress?("\(reason)（\(attempt+1)/2）…")
                try await Task.sleep(nanoseconds:retryDelayNanoseconds*UInt64(attempt+1))
            }
        }
        throw CompanionError.emptyReply
    }
    static func needsPlainReply(_ error:Error)->Bool {
        guard let error=error as? CompanionError else { return false }
        switch error { case .emptyReply,.invalidReply,.truncatedReply:return true;default:return false }
    }
    static func canRetry(_ error:Error)->Bool {
        if let error=error as? CompanionError {
            switch error {
            case .emptyReply,.invalidReply,.invalidResponse,.truncatedReply,.interruptedReply:return true
            case .http(let code):return code==429 || (500...599).contains(code)
            default:return false
            }
        }
        if let error=error as? URLError { return [.timedOut,.networkConnectionLost,.cannotConnectToHost,.dnsLookupFailed].contains(error.code) }
        return false
    }
    static func decode(_ data:Data) throws -> CompanionReply {
        struct Response:Decodable {
            struct Choice:Decodable { struct Message:Decodable { let content:String? };let message:Message;let finish_reason:String? }
            let choices:[Choice]
        }
        guard let response=try? JSONDecoder().decode(Response.self,from:data) else { throw CompanionError.invalidResponse }
        guard let choice=response.choices.first else { throw CompanionError.emptyReply }
        switch choice.finish_reason {
        case "content_filter":throw CompanionError.filteredReply
        case "length":throw CompanionError.truncatedReply
        case "insufficient_system_resource","aborted":throw CompanionError.interruptedReply
        case "tool_calls":throw CompanionError.invalidReply
        default:break
        }
        guard var content=choice.message.content?.trimmingCharacters(in:.whitespacesAndNewlines),!content.isEmpty else { throw CompanionError.emptyReply }
        if content.hasPrefix("```") {
            var lines=content.components(separatedBy:"\n");lines.removeFirst()
            if lines.last?.trimmingCharacters(in:.whitespacesAndNewlines)=="```" { lines.removeLast() }
            content=lines.joined(separator:"\n").trimmingCharacters(in:.whitespacesAndNewlines)
        }
        guard !content.isEmpty else { throw CompanionError.emptyReply }
        if content.hasPrefix("["),let bytes=content.data(using:.utf8),(try? JSONSerialization.jsonObject(with:bytes)) is [Any] { throw CompanionError.invalidReply }
        if content.hasPrefix("{") {
            guard let json=content.data(using:.utf8),let object=(try? JSONSerialization.jsonObject(with:json)) as? [String:Any],let reply=object["reply"] as? String else { throw CompanionError.invalidReply }
            let text=reply.trimmingCharacters(in:.whitespacesAndNewlines)
            guard !text.isEmpty else { throw CompanionError.emptyReply }
            return CompanionReply(text:text,emotion:Pose.named(object["emotion"] as? String ?? "idle").id)
        }
        return CompanionReply(text:content,emotion:"idle")
    }
}
