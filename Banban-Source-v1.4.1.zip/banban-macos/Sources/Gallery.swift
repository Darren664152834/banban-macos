import AppKit
import ImageIO
import QuartzCore

// Ordered, justified rows. Evaluate row heights against the actual aspect ratios
// and select the arrangement with the most visible image area that fits the screen.
enum AdaptiveGalleryLayout {
    static let toolbarHeight:CGFloat=64
    static func photoArea(in bounds:CGRect)->CGRect {
        let inset=min(16,min(bounds.width,bounds.height)/20)
        return CGRect(x:bounds.minX+inset,y:bounds.minY+inset,
                      width:max(0,bounds.width-2*inset),
                      height:max(0,bounds.height-2*inset-toolbarHeight))
    }
    static func frames(sizes:[CGSize],in area:CGRect)->[CGRect] {
        guard !sizes.isEmpty,area.width>0,area.height>0 else { return [] }
        let ratios=sizes.map { size -> CGFloat in
            guard size.width.isFinite,size.height.isFinite,size.width>0,size.height>0 else { return 1 }
            let ratio=size.width/size.height
            return ratio.isFinite && ratio>0 ? ratio:1
        }
        let gap=min(12,sqrt(area.width*area.height/CGFloat(sizes.count))*0.06)
        let lowest=min(area.height,area.width/(ratios.reduce(0,+)+1))
        var best:[CGRect]=[],bestArea:CGFloat = -1
        // Include an all-in-one row so there is always a valid candidate, even
        // with thousands of files or unusually narrow/landscape media.
        for sample in 0...72 {
            let target=max(CGFloat.leastNonzeroMagnitude,lowest*pow(area.height/max(lowest,CGFloat.leastNonzeroMagnitude),CGFloat(sample)/72))
            var rows:[Range<Int>]=[],start=0
            while start<ratios.count {
                var end=start+1,sum=ratios[start]
                while end<ratios.count {
                    let before=(area.width-gap*CGFloat(end-start-1))/sum
                    let available=area.width-gap*CGFloat(end-start)
                    if available<=0 { break }
                    let after=available/(sum+ratios[end])
                    if before<=target || (after<target && abs(before-target)<=abs(after-target)) { break }
                    sum+=ratios[end];end+=1
                }
                rows.append(start..<end);start=end
            }
            let heightBudget=area.height-gap*CGFloat(rows.count-1)
            guard heightBudget>0 else { continue }
            let heights=rows.enumerated().map { index,row -> CGFloat in
                let height=(area.width-gap*CGFloat(row.count-1))/ratios[row].reduce(0,+)
                return index==rows.count-1 ? min(target,height):height
            }
            let scale=min(1,heightBudget/heights.reduce(0,+))
            var candidate:[CGRect]=[],top=area.maxY,usedArea:CGFloat=0
            for (index,row) in rows.enumerated() {
                let height=heights[index]*scale
                let width=ratios[row].reduce(0,+)*height+gap*CGFloat(row.count-1)
                var x=area.minX+max(0,(area.width-width)/2)
                for item in row {
                    let rect=CGRect(x:x,y:top-height,width:ratios[item]*height,height:height)
                    candidate.append(rect);usedArea+=rect.width*rect.height;x=rect.maxX+gap
                }
                top-=height+gap
            }
            if usedArea>bestArea { bestArea=usedArea;best=candidate }
        }
        return best
    }
}

// Read pixel dimensions without decoding the full photograph. Display thumbnails
// are oriented and sized for their final tiles; originals stay untouched on disk.
enum GalleryImage {
    static func size(at url:URL)->CGSize {
        guard let source=CGImageSourceCreateWithURL(url as CFURL,[kCGImageSourceShouldCache:false] as CFDictionary),
              let properties=CGImageSourceCopyPropertiesAtIndex(source,0,nil) as? [CFString:Any],
              let width=properties[kCGImagePropertyPixelWidth] as? NSNumber,
              let height=properties[kCGImagePropertyPixelHeight] as? NSNumber else { return CGSize(width:1,height:1) }
        let orientation=(properties[kCGImagePropertyOrientation] as? NSNumber)?.intValue ?? 1
        return (5...8).contains(orientation) ? CGSize(width:height.doubleValue,height:width.doubleValue):CGSize(width:width.doubleValue,height:height.doubleValue)
    }
    static func thumbnail(at url:URL,maxPixelSize:Int)->CGImage? {
        guard let source=CGImageSourceCreateWithURL(url as CFURL,[kCGImageSourceShouldCache:false] as CFDictionary) else { return nil }
        let options:[CFString:Any]=[kCGImageSourceCreateThumbnailFromImageAlways:true,
                                  kCGImageSourceCreateThumbnailWithTransform:true,
                                  kCGImageSourceThumbnailMaxPixelSize:max(1,maxPixelSize),
                                  kCGImageSourceShouldCacheImmediately:true]
        return CGImageSourceCreateThumbnailAtIndex(source,0,options as CFDictionary)
    }
}

@MainActor final class GalleryCanvasView:NSView {
    private(set) var files:[String]=[]
    private(set) var mediaSizes:[CGSize]=[]
    private(set) var tileFrames:[CGRect]=[]
    private(set) var renderedCount=0
    private(set) var videos:[Int:LoopingPetVideo]=[:]
    private var tiles:[CALayer]=[]
    private var previews:[URL?]=[]
    private var renderTask:Task<Void,Never>?
    private var renderGeneration=UUID()
    private var lastScale:CGFloat=0
    override init(frame:NSRect) { super.init(frame:frame);wantsLayer=true;layer?.backgroundColor=NSColor.clear.cgColor }
    required init?(coder:NSCoder) { fatalError("init(coder:) has not been implemented") }
    func setFiles(_ files:[String],disk:DiskStore) {
        guard self.files != files else { return }
        stop();self.files=files
        previews=files.map { disk.previewURL($0) }
        mediaSizes=previews.map { $0.map(GalleryImage.size(at:)) ?? CGSize(width:1,height:1) }
        for (index,file) in files.enumerated() {
            let tile=CALayer();tile.contentsGravity = .resizeAspect;tile.backgroundColor=NSColor.black.withAlphaComponent(0.08).cgColor
            layer?.addSublayer(tile);tiles.append(tile)
            if DiskStore.isVideo(file),let url=disk.photoURL(file) {
                let video=LoopingPetVideo();video.load(url);tile.addSublayer(video.layer);videos[index]=video
            }
        }
    }
    func arrange(scale:CGFloat) {
        let frames=AdaptiveGalleryLayout.frames(sizes:mediaSizes,in:AdaptiveGalleryLayout.photoArea(in:bounds))
        guard frames != tileFrames || scale != lastScale else { return }
        tileFrames=frames;lastScale=scale
        CATransaction.begin();CATransaction.setDisableActions(true)
        for (index,frame) in frames.enumerated() { tiles[index].frame=frame;videos[index]?.layer.frame=CGRect(origin:.zero,size:frame.size) }
        CATransaction.commit()
        renderTask?.cancel();let generation=UUID();renderGeneration=generation
        let requests=zip(previews,frames).map { (url:$0.0,pixels:Int(ceil(max($0.1.width,$0.1.height)*scale))) }
        renderTask=Task { [weak self] in
            let worker=Task.detached(priority:.userInitiated) { ()->[CGImage?] in
                var result:[CGImage?]=[];result.reserveCapacity(requests.count)
                for request in requests {
                    if Task.isCancelled { return [] }
                    result.append(autoreleasepool { request.url.flatMap { GalleryImage.thumbnail(at:$0,maxPixelSize:request.pixels) } })
                }
                return result
            }
            let images=await withTaskCancellationHandler(operation:{ await worker.value },onCancel:{ worker.cancel() })
            guard !Task.isCancelled,let self,self.renderGeneration==generation,images.count==self.tiles.count else { return }
            CATransaction.begin();CATransaction.setDisableActions(true)
            for (index,image) in images.enumerated() { self.tiles[index].contents=image }
            self.renderedCount=images.compactMap { $0 }.count
            CATransaction.commit()
        }
    }
    func setPlaying(_ playing:Bool) { for video in videos.values { video.setPlaying(playing) } }
    func stop() {
        renderTask?.cancel();renderTask=nil;renderGeneration=UUID()
        for video in videos.values { video.stop() };videos=[:]
        for tile in tiles { tile.removeFromSuperlayer() };tiles=[];files=[];mediaSizes=[];tileFrames=[];previews=[];renderedCount=0
    }
}
