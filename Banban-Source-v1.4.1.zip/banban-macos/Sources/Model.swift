import AppKit
import SwiftUI
import Security
import UniformTypeIdentifiers
import Vision
import CoreImage
import ImageIO
import AVFoundation

// Compatibility read only: never show a Keychain authentication dialog.
struct LegacyKeychain {
    static func readWithoutPrompt() -> String? {
        let query: [String:Any] = [kSecClass as String:kSecClassGenericPassword,
            kSecAttrService as String:"local.banban.companion.deepseek",
            kSecAttrAccount as String:"api-key", kSecReturnData as String:true,
            kSecMatchLimit as String:kSecMatchLimitOne,
            kSecUseAuthenticationUI as String:kSecUseAuthenticationUIFail]
        var result:CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary,&result) == errSecSuccess,
              let data=result as? Data else { return nil }
        return String(data:data,encoding:.utf8)
    }
}
final class DiskStore {
    let directory: URL
    let usesDefaultDirectory: Bool
    var images: URL { directory.appendingPathComponent("Photos",isDirectory:true) }
    init(directory: URL? = nil) throws {
        self.usesDefaultDirectory = directory == nil
        self.directory = directory ?? FileManager.default.urls(for:.applicationSupportDirectory,in:.userDomainMask)[0].appendingPathComponent("Banban",isDirectory:true)
        try FileManager.default.createDirectory(at:self.images,withIntermediateDirectories:true,attributes:[.posixPermissions:0o700])
        try FileManager.default.setAttributes([.posixPermissions:0o700],ofItemAtPath:self.directory.path)
    }
    func load<T:Decodable>(_ type:T.Type,file:String) throws -> T? {
        let url=directory.appendingPathComponent(file)
        guard FileManager.default.fileExists(atPath:url.path) else { return nil }
        return try JSONDecoder().decode(type,from:Data(contentsOf:url))
    }
    func save<T:Encodable>(_ object:T,file:String) throws {
        let data=try JSONEncoder().encode(object),url=directory.appendingPathComponent(file)
        try data.write(to:url,options:.atomic)
        try FileManager.default.setAttributes([.posixPermissions:0o600],ofItemAtPath:url.path)
    }
    func readAPIKey() throws -> String? { try load(String.self,file:"deepseek-key.json") }
    func saveAPIKey(_ key:String) throws { try save(key,file:"deepseek-key.json") }
    func removeAPIKey() throws {
        let url=directory.appendingPathComponent("deepseek-key.json")
        if FileManager.default.fileExists(atPath:url.path) { try FileManager.default.removeItem(at:url) }
    }
    func photoURL(_ name:String?) -> URL? {
        guard let name,!name.isEmpty,name == (name as NSString).lastPathComponent,name != ".",name != ".." else { return nil }
        let url=images.appendingPathComponent(name)
        return FileManager.default.fileExists(atPath:url.path) ? url:nil
    }
    static func isVideo(_ file:String?)->Bool { guard let file else { return false };return ["mp4","mov","m4v"].contains((file as NSString).pathExtension.lowercased()) }
    func previewURL(_ name:String?)->URL? { guard let name,photoURL(name) != nil else { return nil };return Self.isVideo(name) ? images.appendingPathComponent(name+".preview.png"):photoURL(name) }
    func importGalleryMedia(_ source:URL) async throws -> String {
        if Self.isVideo(source.lastPathComponent) { return try await importMedia(source,removeBackground:false) }
        guard let image=CGImageSourceCreateWithURL(source as CFURL,nil),CGImageSourceGetCount(image)>0 else { throw CompanionError.invalidImage }
        let name=UUID().uuidString+"."+source.pathExtension.lowercased(),destination=images.appendingPathComponent(name)
        try FileManager.default.copyItem(at:source,to:destination)
        try FileManager.default.setAttributes([.posixPermissions:0o600],ofItemAtPath:destination.path)
        return name
    }
    func importMedia(_ source:URL,removeBackground:Bool=false) async throws -> String {
        guard Self.isVideo(source.lastPathComponent) else { return try importPhoto(source,removeBackground:removeBackground) }
        let asset=AVURLAsset(url:source)
        let playable=try await asset.load(.isPlayable),duration=try await asset.load(.duration)
        let tracks=try await asset.loadTracks(withMediaType:.video)
        guard playable,!tracks.isEmpty,duration.seconds.isFinite,duration.seconds>0 else { throw BackgroundRemoval.failure("无法读取这个视频，请选择可正常播放的 MP4、MOV 或 M4V 文件。") }
        let generator=AVAssetImageGenerator(asset:asset);generator.appliesPreferredTrackTransform=true;generator.maximumSize=NSSize(width:1000,height:1000)
        let png:Data
        do {
            let (frame,_)=try await generator.image(at:.zero)
            guard let data=NSBitmapImageRep(cgImage:frame).representation(using:.png,properties:[:]) else { throw CompanionError.invalidImage }
            png=data
        } catch {
            // A missing preview frame must not reject an otherwise playable movie.
            let natural=try await tracks[0].load(.naturalSize),transform=try await tracks[0].load(.preferredTransform)
            let bounds=NSRect(origin:.zero,size:natural).applying(transform)
            png=try Self.videoPlaceholder(size:bounds.size)
        }
        return try storeVideo(source,preview:png)
    }
    static func videoPlaceholder(size:NSSize) throws -> Data {
        let valid=size.width.isFinite && size.height.isFinite && abs(size.width)>0 && abs(size.height)>0
        let ratio=valid ? max(0.05,min(20,abs(size.width)/abs(size.height))):0.75
        let width=Int(min(512,512*ratio)),height=Int(min(512,512/ratio))
        guard let bitmap=NSBitmapImageRep(bitmapDataPlanes:nil,pixelsWide:max(1,width),pixelsHigh:max(1,height),bitsPerSample:8,samplesPerPixel:4,hasAlpha:true,isPlanar:false,colorSpaceName:.deviceRGB,bytesPerRow:0,bitsPerPixel:0),let bytes=bitmap.bitmapData else { throw CompanionError.invalidImage }
        memset(bytes,0,bitmap.bytesPerRow*bitmap.pixelsHigh)
        if let context=CGContext(data:bytes,width:bitmap.pixelsWide,height:bitmap.pixelsHigh,bitsPerComponent:8,bytesPerRow:bitmap.bytesPerRow,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue) {
            let w=Double(bitmap.pixelsWide),h=Double(bitmap.pixelsHigh)
            context.setFillColor(NSColor.systemPurple.cgColor);context.move(to:CGPoint(x:w*0.35,y:h*0.35));context.addLine(to:CGPoint(x:w*0.7,y:h*0.5));context.addLine(to:CGPoint(x:w*0.35,y:h*0.65));context.closePath();context.fillPath()
        }
        guard let png=bitmap.representation(using:.png,properties:[:]) else { throw CompanionError.invalidImage };return png
    }
    func storeVideo(_ source:URL,preview png:Data) throws -> String {
        let name=UUID().uuidString+"."+source.pathExtension.lowercased(),destination=images.appendingPathComponent(name)
        do {
            try FileManager.default.copyItem(at:source,to:destination)
            try FileManager.default.setAttributes([.posixPermissions:0o600],ofItemAtPath:destination.path)
            let preview=images.appendingPathComponent(name+".preview.png")
            try png.write(to:preview,options:.atomic)
            try FileManager.default.setAttributes([.posixPermissions:0o600],ofItemAtPath:preview.path)
        } catch { try? FileManager.default.removeItem(at:destination);try? FileManager.default.removeItem(at:images.appendingPathComponent(name+".preview.png"));throw error }
        return name
    }
    func importPhoto(_ source:URL,removeBackground:Bool=false) throws -> String {
        let png:Data
        if removeBackground { png=try BackgroundRemoval.png(from:source) }
        else {
            guard let image=NSImage(contentsOf:source),image.size.width>0,image.size.height>0,
                  let tiff=image.tiffRepresentation,let bitmap=NSBitmapImageRep(data:tiff),
                  let data=bitmap.representation(using:.png,properties:[:]) else { throw CompanionError.invalidImage }
            png=data
        }
        let name=UUID().uuidString+".png",destination=images.appendingPathComponent(name)
        try png.write(to:destination,options:.atomic)
        try FileManager.default.setAttributes([.posixPermissions:0o600],ofItemAtPath:destination.path)
        return name
    }
}
enum BackgroundRemoval {
    static var available:Bool { if #available(macOS 14.0,*) { return true };return false }
    static func png(from url:URL) throws -> Data {
        guard #available(macOS 14.0,*) else { throw failure("自动抠图需要 macOS 14 或更新版本；也可先用预览处理后导入透明 PNG。") }
        let handler=VNImageRequestHandler(url:url,options:[:])
        let request=VNGenerateForegroundInstanceMaskRequest()
        let image:CIImage
        do {
            try performLocally(request,handler:handler)
            guard let result=request.results?.first,!result.allInstances.isEmpty else { throw failure("未识别到可提取的主体。") }
            let buffer=try result.generateMaskedImage(ofInstances:result.allInstances,from:handler,croppedToInstancesExtent:false)
            image=CIImage(cvPixelBuffer:buffer)
        } catch {
            // Person-only fallback if the general foreground model is unavailable.
            let person=VNGeneratePersonSegmentationRequest();person.qualityLevel = .accurate
            person.outputPixelFormat=kCVPixelFormatType_OneComponent8
            try performLocally(person,handler:handler)
            guard let buffer=person.results?.first?.pixelBuffer,
                  let original=CIImage(contentsOf:url,options:[.applyOrientationProperty:true]) else { throw failure("未识别到人物，原图未更改。请使用预览精修。") }
            let rawMask=CIImage(cvPixelBuffer:buffer)
            let mask=rawMask.transformed(by:CGAffineTransform(scaleX:original.extent.width/rawMask.extent.width,y:original.extent.height/rawMask.extent.height))
            let maximum=mask.applyingFilter("CIAreaMaximum",parameters:[kCIInputExtentKey:CIVector(cgRect:mask.extent)])
            var pixel=[UInt8](repeating:0,count:4)
            CIContext().render(maximum,toBitmap:&pixel,rowBytes:4,bounds:NSRect(x:0,y:0,width:1,height:1),format:.RGBA8,colorSpace:CGColorSpaceCreateDeviceRGB())
            guard pixel[0]>5 else { throw failure("未识别到清晰的人物，原图未更改。请换一张照片或使用预览精修。") }
            image=original.applyingFilter("CIBlendWithMask",parameters:[kCIInputBackgroundImageKey:CIImage(color:.clear).cropped(to:original.extent),kCIInputMaskImageKey:mask])
        }
        guard let data=CIContext().pngRepresentation(of:image,format:.RGBA8,colorSpace:CGColorSpaceCreateDeviceRGB()) else { throw failure("无法保存透明图片，原图未更改。") }
        return data
    }
    @available(macOS 14.0,*)
    static func performLocally(_ request:VNRequest,handler:VNImageRequestHandler) throws {
        do { try handler.perform([request]) }
        catch {
            // Use a supported GPU or CPU device when Neural Engine initialization fails.
            let stages=try request.supportedComputeStageDevices
            for (stage,devices) in stages {
                let gpu=devices.first { if case .gpu = $0 { return true };return false }
                let cpu=devices.first { if case .cpu = $0 { return true };return false }
                if let device=gpu ?? cpu { request.setComputeDevice(device,for:stage) }
            }
            try handler.perform([request])
        }
    }
    static func failure(_ message:String)->NSError { NSError(domain:"BanbanPhoto",code:1,userInfo:[NSLocalizedDescriptionKey:message]) }

}
@MainActor final class CompanionModel:ObservableObject {
    @Published var settings:AppSettings { didSet { saveSettings();onSettingsChanged?() } }
    @Published var messages:[ChatMessage] = []
    @Published var currentPose="idle" { didSet { onPetChanged?() } }
    @Published var positioningPhotos:Set<UUID>=[] { didSet { onSettingsChanged?() } }
    @Published var positioningMain=false { didSet { onSettingsChanged?() } }
    @Published var galleryDisplayFiles=Set<String>() { didSet { onGalleryChanged?() } }
    @Published var processingPhotos=false
    @Published var previousPhotos:[String:String]=[:] 
    @Published var busy=false
    @Published var testing=false
    @Published var hasKey=false
    @Published var notice=""
    @Published var error=""
    @Published var chatError=""
    @Published var chatStatus=""
    @Published var chatScrollTarget:UUID?=nil
    @Published var section="人物照片"
    let disk:DiskStore
    let client:DeepSeekClient
    var onWillSwitchProfile:(()->Void)?
    var onPetChanged:(()->Void)?
    var onSettingsChanged:(()->Void)?
    var onArrangeDesktop:(()->Void)?
    var onGalleryChanged:(()->Void)?
    var onShowChat:(()->Void)?
    var onShowSettings:(()->Void)?
    var requestTask:Task<Void,Never>?
    var activeRequest:UUID?
    private let imageCache=NSCache<NSString,NSImage>()
    var displayName:String { settings.role.name.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty ? "你的伙伴":settings.role.name }
    var roleReady:Bool { !settings.role.name.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty && !settings.role.personality.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty }
    var baseImage:NSImage? { image(file:settings.basePhoto) }
    var hasPhoto:Bool { (settings.desktopPhotos ?? []).contains { disk.photoURL($0.file) != nil } || baseImage != nil || Pose.all.contains { disk.photoURL(settings.posePhotos[$0.id]) != nil } }
    var currentMediaFile:String? {
        ([settings.posePhotos[currentPose],settings.basePhoto]+Pose.all.map { settings.posePhotos[$0.id] }).compactMap { $0 }.first { disk.photoURL($0) != nil && image(file:$0) != nil }
    }
    var currentImage:NSImage? { image(file:currentMediaFile) }
    var configuredCount:Int { Pose.all.filter { disk.photoURL(settings.posePhotos[$0.id]) != nil }.count }
    var displayableMediaCount:Int {
        (settings.galleryPhotos ?? []).filter { disk.photoURL($0) != nil }.count
    }
    var orderedGalleryDisplayFiles:[String] {
        var seen=Set<String>()
        return (settings.galleryPhotos ?? []).filter { galleryDisplayFiles.contains($0) && disk.photoURL($0) != nil && seen.insert($0).inserted }
    }
    init(disk:DiskStore,client:DeepSeekClient=DeepSeekClient()) {
        self.disk=disk;self.client=client
        var loadError=""
        do { self.settings=try disk.load(AppSettings.self,file:"settings.json") ?? AppSettings() } catch { self.settings=AppSettings();loadError="已有设置文件无法读取，未覆盖原文件。请在设置中重新保存，或先备份本地资料。" }
        if var photos=settings.desktopPhotos {
            var changed=false
            for i in photos.indices where photos[i].preferences == nil { photos[i].preferences=settings.preferences;changed=true }
            if changed { settings.desktopPhotos=photos;try? disk.save(settings,file:"settings.json") }
        }
        settings.prepareProfiles()
        if loadError.isEmpty { try? disk.save(settings,file:"settings.json") }
        if settings.preferences.rememberHistory { do { messages=try disk.load([ChatMessage].self,file:settings.historyFile) ?? [] } catch { loadError="聊天记录无法读取，已保留原文件；新的聊天可正常使用。" } }
        for i in messages.indices where messages[i].state == "sending" { messages[i].state="failed";messages[i].failureReason="上次退出时尚未取得回复，可重新获取。" }
        error=loadError
        do {
            hasKey = !(try disk.readAPIKey() ?? "").isEmpty
            // One silent migration attempt for existing installs, never for test libraries.
            if !hasKey && disk.usesDefaultDirectory && !UserDefaults.standard.bool(forKey:"BanbanLegacyMigrationAttempted") {
                if let legacy=LegacyKeychain.readWithoutPrompt(), !legacy.isEmpty {
                    try disk.saveAPIKey(legacy);hasKey=true
                    notice="API Key 已迁移到本机配置，后续聊天无需钥匙串验证。"
                } else {
                    notice="请在 DeepSeek 设置中重新填写并保存一次 API Key，之后聊天无需钥匙串验证。"
                }
                UserDefaults.standard.set(true,forKey:"BanbanLegacyMigrationAttempted")
            }
        } catch { self.error=error.localizedDescription }
    }
    func image(file:String?) -> NSImage? {
        guard let url=disk.photoURL(file) else { return nil }
        if let existing=imageCache.object(forKey:url.path as NSString) { return existing }
        guard let preview=disk.previewURL(file),let image=NSImage(contentsOf:preview) else { return nil };imageCache.setObject(image,forKey:url.path as NSString);return image
    }
    func saveSettings() { do { var snapshot=settings;snapshot.captureProfile();try disk.save(snapshot,file:"settings.json") } catch { self.error=error.localizedDescription } }
    func saveHistory() { do { try disk.save(settings.preferences.rememberHistory ? Array(messages.suffix(120)):[],file:settings.historyFile) } catch { self.error=error.localizedDescription } }
    func importPhotos(for pose:String?=nil,batch:Bool=false,gallery:Bool=false) {
        guard !processingPhotos else { return }
        let removeBackground = !gallery && settings.preferences.autoRemoveBackground
        let profileID=settings.activeProfileID
        let panel=NSOpenPanel();panel.title=gallery ? "批量导入展示照片或视频":(batch ? "导入表情动作照片或视频":"选择人物照片或视频");panel.prompt="导入";panel.canChooseDirectories=false;panel.allowsMultipleSelection=batch || gallery
        panel.allowedContentTypes=[.png,.jpeg,.heic,.tiff,.webP,.mpeg4Movie,.quickTimeMovie,UTType(filenameExtension:"m4v")! ]
        panel.begin { [weak self] response in
            guard response == .OK,let self,self.settings.activeProfileID==profileID else { return }
            Task { @MainActor in
                self.processingPhotos=true
                defer { self.processingPhotos=false }
                var count=0,unmatched:[String]=[]
                for url in panel.urls {
                    do {
                        var target=pose
                        if gallery {
                            let disk=self.disk
                            let imported=try await Task.detached(priority:.userInitiated) { try await disk.importGalleryMedia(url) }.value
                            guard self.settings.activeProfileID==profileID else { return }
                            self.settings.galleryPhotos=(self.settings.galleryPhotos ?? []) + [imported]
                            count+=1
                            continue
                        }
                        if batch {
                            let stem=url.deletingPathExtension().lastPathComponent.lowercased().trimmingCharacters(in:CharacterSet(charactersIn:"0123456789-_. "))
                            target=Pose.all.first(where:{ $0.id==stem || $0.name==stem })?.id
                            if target==nil { unmatched.append(url.lastPathComponent);continue }
                        }
                        let disk=self.disk
                        let file=try await Task.detached(priority:.userInitiated) { try await disk.importMedia(url,removeBackground:removeBackground) }.value
                        if let target { self.settings.posePhotos[target]=file;if self.settings.basePhoto==nil { self.settings.basePhoto=file } }
                        else { self.settings.basePhoto=file }
                        count+=1
                    } catch { self.error=error.localizedDescription }
                }
                if count>0 {
                    if !gallery { self.settings.preferences.petVisible=true }
                    self.notice=gallery ? "已导入 \(count) 个独立展示照片／视频，不匹配动作、不抠图。":"已导入 \(count) 个照片／视频，视频会静音循环播放，原文件保持不变。"
                    self.onPetChanged?()
                }
                if !unmatched.isEmpty { self.error="以下文件没有匹配到动作：\(unmatched.joined(separator:"、"))。请用「待机.png」「微笑.png」等动作名命名，或逐个导入。" }
            }
        }
    }
    func removePhoto(pose:String?=nil) {
        guard !processingPhotos else { return }
        let key=pose ?? "base"
        if let file=pose.flatMap({ settings.posePhotos[$0] }) ?? (pose == nil ? settings.basePhoto:nil) { previousPhotos[key]=file }
        if let pose { settings.posePhotos.removeValue(forKey:pose);if currentPose==pose { currentPose="idle" } }
        else { settings.basePhoto=nil }
        notice="已移除此照片，可点击撤销。原始照片保持不变。";onPetChanged?()
    }
    func clearPosePhotos() {
        let poseFiles=Set(settings.posePhotos.values)
        guard !poseFiles.isEmpty else { notice="当前没有可清空的批量动作照片。";return }
        settings.posePhotos=[:]
        settings.desktopPhotos=(settings.desktopPhotos ?? []).filter { !poseFiles.contains($0.file) }
        if poseFiles.contains(currentMediaFile ?? "") { currentPose="idle" }
        notice="已清空批量动作照片；默认照片和素材原文件仍保留。"
        onPetChanged?()
    }
    func clearGalleryPhotos() {
        guard !(settings.galleryPhotos ?? []).isEmpty else { notice="当前没有可清空的独立展示照片。";return }
        galleryDisplayFiles=[]
        settings.galleryPhotos=[]
        notice="已清空独立展示照片；默认照片、动作照片和素材原文件仍保留。"
        onPetChanged?()
    }
    func restorePhoto(pose:String?=nil) {
        guard !processingPhotos,let file=previousPhotos.removeValue(forKey:pose ?? "base") else { return }
        if let pose { settings.posePhotos[pose]=file } else { settings.basePhoto=file }
        notice="已恢复之前的照片。";onPetChanged?()
    }
    func reloadPhotoPreviews() { imageCache.removeAllObjects();objectWillChange.send();onPetChanged?() }
    func editPhotoInPreview(pose:String?=nil) {
        guard !processingPhotos,let file=pose.flatMap({ settings.posePhotos[$0] }) ?? (pose == nil ? settings.basePhoto:nil),let source=disk.photoURL(file) else { return }
        guard !DiskStore.isVideo(file) else { error="视频保留原背景，当前抠图和预览精修仅适用于照片。";return }
        guard let preview=NSWorkspace.shared.urlForApplication(withBundleIdentifier:"com.apple.Preview") else { error="未找到 Mac 预览 App。";return }
        do {
            let copy=try disk.importPhoto(source)
            guard let url=disk.photoURL(copy) else { return }
            previousPhotos[pose ?? "base"]=file
            if let pose { settings.posePhotos[pose]=copy } else { settings.basePhoto=copy }
            notice="已在预览中打开可编辑副本。保存后回到伴伴即可刷新，也可恢复编辑前照片。"
            NSWorkspace.shared.open([url],withApplicationAt:preview,configuration:NSWorkspace.OpenConfiguration()) { [weak self] _,error in
                if let error { Task { @MainActor in self?.error=error.localizedDescription } }
            }
        } catch { self.error=error.localizedDescription }
    }
    func cutoutPhoto(pose:String?=nil) {
        guard !processingPhotos,let file=pose.flatMap({ settings.posePhotos[$0] }) ?? (pose == nil ? settings.basePhoto:nil),let url=disk.photoURL(file) else { return }
        guard !DiskStore.isVideo(file) else { error="当前自动去背景仅适用于照片，视频请先处理背景后再导入。";return }
        processingPhotos=true;notice="正在本机去除背景…";error=""
        let disk=self.disk
        Task { @MainActor in
            defer { processingPhotos=false }
            do {
                let processed=try await Task.detached(priority:.userInitiated) { try disk.importPhoto(url,removeBackground:true) }.value
                previousPhotos[pose ?? "base"]=file
                if let pose { settings.posePhotos[pose]=processed } else { settings.basePhoto=processed }
                notice="背景已去除。若效果不满意，可恢复抠图前照片。";onPetChanged?()
            } catch { self.error="自动抠图未完成，请使用「预览精修」去除背景，或换一张照片再试。";notice="原照片已保留。" }
        }
    }
    func addDesktopPhoto(file:String?,name:String) {
        guard let file,disk.photoURL(file) != nil else { return }
        var photos=settings.desktopPhotos ?? []
        guard photos.count<20 else { error="最多可添加 20 张额外桌宠图片，请先移除一张。";return }
        photos.append(DesktopPhoto(preferences:settings.preferences,file:file,name:name));settings.desktopPhotos=photos
        settings.preferences.petVisible=true;notice="已添加到桌面，可以单独拖动和缩放。"
    }
    func displayAllImportedPhotos() {
        let files=Set((settings.galleryPhotos ?? []).filter { disk.photoURL($0) != nil })
        guard !files.isEmpty else { notice="请先批量导入照片或视频，再使用一键展示。";return }
        settings.preferences.petVisible=true
        galleryDisplayFiles=files
        notice="已按原始比例自动排列全部 \(files.count) 个照片／视频；右上角可退出展示。"
    }
    func exitAllPhotoDisplay() {
        guard !galleryDisplayFiles.isEmpty else { notice="当前没有正在进行的独立照片展示。";return }
        galleryDisplayFiles=[]
        notice="已退出全部照片展示；独立展示素材仍保留在照片库中。"
    }
    var mainPresentationPreferences:Preferences {
        var p=settings.preferences
        if positioningMain { p.wallpaperEffect=false;p.floatingClickThrough=false;p.alwaysOnTop=true }
        return p
    }
    func desktopPreferences(_ item:DesktopPhoto,forPositioning:Bool=false)->Preferences {
        var p=item.preferences ?? settings.preferences
        p.petVisible=settings.preferences.petVisible && (item.visible ?? true)
        if forPositioning && positioningPhotos.contains(item.id) { p.wallpaperEffect=false;p.floatingClickThrough=false;p.alwaysOnTop=true }
        return p
    }
    func editDesktopPreferences(_ id:UUID,_ edit:(inout Preferences)->Void) {
        var photos=settings.desktopPhotos ?? [];guard let i=photos.firstIndex(where:{$0.id==id}) else { return }
        var p=photos[i].preferences ?? settings.preferences;edit(&p);photos[i].preferences=p;settings.desktopPhotos=photos
    }
    func setPresentationMode(_ mode:String,for id:UUID?=nil) {
        guard ["interactive","wallpaper","floating"].contains(mode) else { return }
        if let id {
            editDesktopPreferences(id) { $0.setDisplayMode(mode) }
            positioningPhotos.remove(id)
        } else {
            var p=settings.preferences;p.setDisplayMode(mode);settings.preferences=p;positioningMain=false
        }
    }
    func resetDesktopPreferences(_ id:UUID) {
        var photos=settings.desktopPhotos ?? [];guard let i=photos.firstIndex(where:{$0.id==id}) else { return }
        photos[i].preferences=settings.preferences;photos[i].height=settings.preferences.personHeight;settings.desktopPhotos=photos
    }
    func setDesktopVisible(_ id:UUID,_ visible:Bool) {
        var photos=settings.desktopPhotos ?? [];guard let i=photos.firstIndex(where:{$0.id==id}) else { return }
        photos[i].visible=visible;settings.desktopPhotos=photos
        if !visible { positioningPhotos.remove(id) }
    }
    func toggleDesktopPositioning(_ id:UUID) {
        if positioningPhotos.contains(id) { positioningPhotos.remove(id) }
        else { setDesktopVisible(id,true);settings.preferences.petVisible=true;positioningPhotos.insert(id) }
    }
    func toggleMainPositioning() {
        if !positioningMain { settings.preferences.mainPetVisible=true;settings.preferences.petVisible=true }
        positioningMain.toggle()
    }
    func removeDesktopPhoto(_ id:UUID) { positioningPhotos.remove(id);settings.desktopPhotos=(settings.desktopPhotos ?? []).filter { $0.id != id } }
    func setDesktopHeight(_ id:UUID,_ height:Double) {
        var photos=settings.desktopPhotos ?? [];guard let i=photos.firstIndex(where:{$0.id==id}) else { return }
        photos[i].height=min(700,max(100,height));settings.desktopPhotos=photos
    }
    func selectPose(_ pose:String) { currentPose=Pose.named(pose).id;if image(file:settings.posePhotos[pose])==nil { notice="「\(Pose.named(pose).name)」尚未配置，正在显示默认照片。" } }
    func switchProfile(_ id:UUID) {
        guard id != settings.activeProfileID,!processingPhotos,let target=settings.profiles?.first(where:{$0.id==id}) else { return }
        cancel()
        var next=settings;next.captureProfile();next.loadProfile(target)
        // Retire old media before callbacks load the next profile.
        previousPhotos=[:];positioningPhotos=[];positioningMain=false;galleryDisplayFiles=[];imageCache.removeAllObjects()
        messages=[];chatError="";chatStatus="";chatScrollTarget=nil
        onWillSwitchProfile?()
        settings=next;currentPose="idle"
        do { if settings.preferences.rememberHistory { messages=try disk.load([ChatMessage].self,file:settings.historyFile) ?? [] } }
        catch { self.error="此角色的聊天记录无法读取，原文件已保留。" }
        for i in messages.indices where messages[i].state=="sending" { messages[i].state="failed";messages[i].failureReason="上次尚未取得回复，可重试。" }
        notice="已切换到「\(displayName)」，素材、摆放与聊天记录已切换。";onPetChanged?()
    }
    func addProfile(copy:Bool=false) {
        guard !processingPhotos else { return }
        var next=settings;next.captureProfile()
        var profile=copy ? (next.profiles?.first(where:{$0.id==next.activeProfileID}) ?? CharacterProfile.preset("自定义角色")):CharacterProfile.preset("自定义角色")
        profile.id=UUID();profile.legacyHistory=false
        if copy { profile.role.name += " 副本";profile.desktopPhotos=profile.desktopPhotos?.map { var p=$0;p.id=UUID();return p } }
        next.profiles=(next.profiles ?? [])+[profile];settings=next;switchProfile(profile.id);section="角色设定"
    }
    func deleteActiveProfile() {
        guard !processingPhotos,(settings.profiles?.count ?? 0)>1,let id=settings.activeProfileID else { return }
        let target=settings.profiles!.first(where:{$0.id != id})!.id
        switchProfile(target)
        settings.profiles=settings.profiles?.filter {$0.id != id}
        notice="角色已移除；本机素材文件保留。"
    }
    func saveScene(_ scene:SceneSettings,asPreset:Bool=false) {
        var scene=scene;scene.name=scene.name.trimmingCharacters(in:.whitespacesAndNewlines)
        guard !scene.name.isEmpty else { error="请填写场景名称。";return }
        settings.scene=scene
        if asPreset {
            var list=settings.scenes ?? []
            if let i=list.firstIndex(where:{$0.id==scene.id}) { list[i]=scene } else { list.append(scene) }
            settings.scenes=list
        }
        notice=asPreset ? "场景预设已保存。":"当前角色的场景已保存。"
    }
    func deleteScenePreset(_ id:UUID) { settings.scenes=settings.scenes?.filter {$0.id != id};notice="场景预设已删除；角色已保存的场景不受影响。" }
    func saveRole(_ role:RoleSettings) {
        var role=role;role.name=role.name.trimmingCharacters(in:.whitespacesAndNewlines)
        guard !role.name.isEmpty,!role.personality.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty else { error="请至少填写角色姓名和性格。";return }
        settings.role=role;notice="角色设定已保存，下次启动仍会保留，并用于接下来的对话。"
    }
    func saveAPI(key:String,model:String,provider:String="DeepSeek",endpoint:String="") {
        error=""
        do {
            let name=model.trimmingCharacters(in:.whitespacesAndNewlines)
            let target=endpoint.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty ? AIProviderPreset.preset(named:provider).endpoint : endpoint
            _=try client.request(key:key.isEmpty ? "validation-only" : key,model:name,messages:[],endpoint:target)
            if !key.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty { try disk.saveAPIKey(key.trimmingCharacters(in:.whitespacesAndNewlines));hasKey=true }
            let normalized=try DeepSeekClient.normalizedEndpoint(target)
            settings.model=name;settings.apiProvider=provider;settings.apiEndpoint=normalized.absoluteString
            notice=hasKey ? "AI 接口已保存，Key 已保存在本机，聊天时直接读取。":(normalized.host == "localhost" || normalized.host == "127.0.0.1" ? "本机接口已保存，可以开始对话。":"模型已保存，请填写 API Key 后再对话。")
        } catch { self.error=error.localizedDescription }
    }
    func deleteAPIKey() { do { try disk.removeAPIKey();hasKey=false;notice="已移除本 App 保存的 API Key。" } catch { self.error=error.localizedDescription } }
    func testConnection() {
        guard !testing else { return }
        testing=true
        Task {
            defer { testing=false }
            do {
                let key=try disk.readAPIKey() ?? ""
                _=try await client.chat(key:key,model:settings.model,messages:[APIMessage(role:"system",content:"只返回 JSON：{\"reply\":\"连接成功\",\"emotion\":\"idle\"}"),APIMessage(role:"user",content:"测试连接")],endpoint:settings.apiEndpoint ?? DeepSeekClient.endpoint.absoluteString)
                hasKey = !key.isEmpty;notice="连接成功，可以开始和伙伴聊天了。"
            } catch { self.error=networkMessage(error) }
        }
    }
    func send(_ text:String,retryID:UUID?=nil) {
        let text=text.trimmingCharacters(in:.whitespacesAndNewlines)
        guard !text.isEmpty,!busy else { return }
        guard text.count<=8000 else { chatError="这条消息较长，请控制在 8000 字以内。";return }
        guard roleReady else { chatError="请先填写并保存角色姓名和性格。";section="角色设定";onShowSettings?();return }
        let key:String
        do { key=try disk.readAPIKey() ?? "";hasKey = !key.isEmpty }
        catch { chatError=error.localizedDescription;section="AI 接口";onShowSettings?();return }
        let history:[ChatMessage]
        if let retryID,let i=messages.firstIndex(where:{$0.id==retryID}) { history=Array(messages.prefix(i)) }
        else { history=messages }
        let apiMessages=PromptBuilder.messages(role:settings.role,history:history,current:text,scene:settings.scene)
        let userID:UUID
        if let retryID,let i=messages.firstIndex(where:{$0.id==retryID}) { userID=retryID;messages[i].state="sending";messages[i].failureReason=nil }
        else { let user=ChatMessage(role:"user",content:text,state:"sending");userID=user.id;messages.append(user) }
        chatScrollTarget=userID
        let requestID=UUID();activeRequest=requestID;busy=true;chatError="";chatStatus="正在等待 DeepSeek 回复…";currentPose="thinking";saveHistory()
        let selectedModel=settings.model
        requestTask=Task { [weak self] in
            guard let self else { return }
            do {
                let result=try await client.chat(key:key,model:selectedModel,messages:apiMessages,endpoint:self.settings.apiEndpoint ?? DeepSeekClient.endpoint.absoluteString,progress:{ [weak self] status in
                    guard let self,self.activeRequest==requestID else { return };self.chatStatus=status
                })
                guard activeRequest==requestID else { return }
                if let i=messages.firstIndex(where:{$0.id==userID}) {
                    messages[i].state="sent";messages[i].failureReason=nil
                    let reply=ChatMessage(role:"assistant",content:result.text)
                    messages.insert(reply,at:i+1);chatScrollTarget=reply.id
                }
                currentPose=result.emotion
            } catch {
                guard activeRequest==requestID else { return }
                chatError=networkMessage(error)
                if let i=messages.firstIndex(where:{$0.id==userID}) { messages[i].state="failed";messages[i].failureReason=chatError }
                currentPose="idle"
            }
            guard activeRequest==requestID else { return };busy=false;chatStatus="";activeRequest=nil;requestTask=nil;saveHistory();onPetChanged?()
        }
    }
    func networkMessage(_ error:Error) -> String {
        if error is CancellationError || (error as? URLError)?.code == .cancelled { return "已停止生成，可以重试这条消息。" }
        if let url=error as? URLError {
            if url.code == .notConnectedToInternet { return "Mac 当前未连接网络，请联网后重新获取回复。" }
            if url.code == .timedOut { return "等待 DeepSeek 回复超时；无法确认服务器是否已处理，请稍后重新获取回复。" }
            return "暂时无法连接 DeepSeek，请检查网络后重试。"
        }
        return error.localizedDescription
    }
    func cancel() { activeRequest=nil;requestTask?.cancel();requestTask=nil;busy=false;chatStatus="";for i in messages.indices where messages[i].state=="sending" { messages[i].state="failed";messages[i].failureReason="已停止等待回复，可重试。" };currentPose="idle";chatError="已停止生成，可以重试这条消息。";saveHistory() }
    func clearHistory() { cancel();messages=[];chatError="";saveHistory();notice="聊天记录已清空。" }
}
