import Foundation
import AppKit
import AVFoundation
import SwiftUI

final class StubProtocol:URLProtocol,@unchecked Sendable {
    static var status=200
    static var payload=Data()
    enum Event { case reply(Int,Data), failure(URLError.Code) }
    static var events:[Event]=[]
    static var captured:[[String:Any]]=[]
    static var hold=false
    static var sawRequest=false
    override class func canInit(with request:URLRequest)->Bool { true }
    override class func canonicalRequest(for request:URLRequest)->URLRequest { request }
    override func startLoading() {
        Self.sawRequest=true
        var body=request.httpBody ?? Data()
        if body.isEmpty,let stream=request.httpBodyStream {
            stream.open();defer { stream.close() }
            var buffer=[UInt8](repeating:0,count:4096)
            while stream.hasBytesAvailable { let count=stream.read(&buffer,maxLength:buffer.count);if count<=0 { break };body.append(contentsOf:buffer.prefix(count)) }
        }
        Self.captured.append((try? JSONSerialization.jsonObject(with:body)) as? [String:Any] ?? [:])
        if Self.hold { return }
        let status:Int,payload:Data
        if !Self.events.isEmpty {
            switch Self.events.removeFirst() {
            case .reply(let code,let bytes):status=code;payload=bytes
            case .failure(let code):client?.urlProtocol(self,didFailWithError:URLError(code));return
            }
        } else { status=Self.status;payload=Self.payload }
        let response=HTTPURLResponse(url:request.url!,statusCode:status,httpVersion:"HTTP/1.1",headerFields:["Content-Type":"application/json"])!
        client?.urlProtocol(self,didReceive:response,cacheStoragePolicy:.notAllowed)
        client?.urlProtocol(self,didLoad:payload)
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}
@MainActor func runSelfTests() {
    var passed=0
    func check(_ condition:Bool,_ label:String) { if !condition { fputs("FAIL: \(label)\n",stderr);exit(1) };passed+=1;print("PASS: \(label)") }
    func reject(_ label:String,_ body:() throws -> Void) { do { try body();check(false,label) } catch { check(true,label) } }
    do {
        check(Pose.all.count==20 && Set(Pose.all.map(\.id)).count==20,"20 unique configurable poses")
        check(Pose.named("unexpected").id=="idle","unknown emotion falls back to idle")
        let legacyPrefs=try JSONDecoder().decode(Preferences.self,from:Data("{\"personHeight\":420,\"alwaysOnTop\":false}".utf8))
        check(legacyPrefs.personHeight==420 && legacyPrefs.chatOpacity==0.55 && !legacyPrefs.alwaysOnTop,"existing preferences migrate without losing saved settings")
        let smallPrefs=try JSONDecoder().decode(Preferences.self,from:Data("{\"personHeight\":100,\"chatOpacity\":0.25}".utf8))
        check(smallPrefs.personHeight==100 && smallPrefs.chatOpacity==0.25,"small pet and transparent chat settings persist")
        var uiModePrefs=Preferences();uiModePrefs.setFloatingClickThrough(true)
        var modeWrites=0
        let modeControls=DesktopAppearanceControls(preferences:Binding(get:{uiModePrefs},set:{uiModePrefs=$0;modeWrites+=1}))
        modeControls.mode.wrappedValue="wallpaper"
        check(uiModePrefs.wallpaperEffect && !uiModePrefs.floatingClickThrough && modeWrites==1,"individual wallpaper picker commits both flags atomically in one write")
        modeControls.mode.wrappedValue="floating"
        check(!uiModePrefs.wallpaperEffect && uiModePrefs.floatingClickThrough && modeWrites==2,"individual floating picker does not retain wallpaper flag")
        let zeroPrefs=try JSONDecoder().decode(Preferences.self,from:Data("{\"opacity\":0,\"chatOpacity\":0}".utf8))
        check(zeroPrefs.opacity==0 && zeroPrefs.chatOpacity==0,"fully transparent pet and chat backgrounds decode without minimum clamp")
        let fullPrefs=try JSONDecoder().decode(Preferences.self,from:Data("{\"opacity\":1,\"chatOpacity\":1}".utf8))
        check(fullPrefs.opacity==1 && fullPrefs.chatOpacity==1,"fully opaque endpoints remain available")
        let boundedPrefs=try JSONDecoder().decode(Preferences.self,from:Data("{\"opacity\":-1,\"chatOpacity\":2}".utf8))
        check(boundedPrefs.opacity==0 && boundedPrefs.chatOpacity==1,"out-of-range transparency clamps to zero through one")
        check(!legacyPrefs.wallpaperEffect,"existing profiles keep wallpaper effect off by default")
        var wallpaperPrefs=Preferences();wallpaperPrefs.wallpaperEffect=true
        let restoredWallpaperPrefs=try JSONDecoder().decode(Preferences.self,from:JSONEncoder().encode(wallpaperPrefs))
        check(restoredWallpaperPrefs.wallpaperEffect,"wallpaper effect survives save/reload")
        let application=NSApplication.shared
        application.setActivationPolicy(.prohibited)
        let presentationPanel=CompanionPanel(contentRect:NSRect(x:0,y:0,width:100,height:100),styleMask:[.borderless,.nonactivatingPanel],backing:.buffered,defer:true)
        PetPresentation.apply(wallpaperPrefs,to:presentationPanel)
        check(presentationPanel.ignoresMouseEvents,"wallpaper mode sets native window-wide click-through")
        check(presentationPanel.level.rawValue>Int(CGWindowLevelForKey(.desktopWindow)) && presentationPanel.level.rawValue<Int(CGWindowLevelForKey(.desktopIconWindow)),"wallpaper layer is above wallpaper and below desktop icons")
        check(presentationPanel.collectionBehavior.contains(.stationary),"wallpaper figure stays stationary")
        wallpaperPrefs.wallpaperEffect=false
        PetPresentation.apply(wallpaperPrefs,to:presentationPanel)
        check(!presentationPanel.ignoresMouseEvents && presentationPanel.level == .floating,"normal mode restores native interaction and original level")
        var floatingPrefs=Preferences();floatingPrefs.alwaysOnTop=false;floatingPrefs.setFloatingClickThrough(true)
        PetPresentation.apply(floatingPrefs,to:presentationPanel)
        check(presentationPanel.ignoresMouseEvents && presentationPanel.level == .floating,"foreground pass-through remains above apps even when normal always-on-top was off")
        let restoredFloating=try JSONDecoder().decode(Preferences.self,from:JSONEncoder().encode(floatingPrefs))
        check(restoredFloating.floatingClickThrough && !restoredFloating.wallpaperEffect,"foreground pass-through persists independently")
        floatingPrefs.setWallpaperEffect(true)
        PetPresentation.apply(floatingPrefs,to:presentationPanel)
        check(floatingPrefs.wallpaperEffect && !floatingPrefs.floatingClickThrough && presentationPanel.level.rawValue<Int(CGWindowLevelForKey(.desktopIconWindow)),"wallpaper mode is retained and distinct from foreground pass-through")
        floatingPrefs.setFloatingClickThrough(true)
        check(!floatingPrefs.wallpaperEffect && floatingPrefs.floatingClickThrough,"enabling foreground pass-through switches off incompatible wallpaper level")
        floatingPrefs.setFloatingClickThrough(false)
        PetPresentation.apply(floatingPrefs,to:presentationPanel)
        check(!presentationPanel.ignoresMouseEvents && presentationPanel.level == .normal,"disabling both modes restores prior interactive non-floating level")
        check(!legacyPrefs.floatingClickThrough,"existing profiles do not silently enable new foreground pass-through")
        let role=RoleSettings()
        check(role.relationship=="主人的女人" && role.background.contains("成年"),"first-run adult role preset")
        var custom=role;custom.name="自定义角色";custom.personality="沉稳";custom.background="用户填写背景";custom.speakingStyle="简短中文";custom.relationship="朋友"
        let system=PromptBuilder.system(role:custom)
        check(system.contains("自定义角色") && system.contains("用户填写背景") && system.contains("简短中文"),"saved user role fields enter system prompt")
        let sent=ChatMessage(role:"user",content:"confirmed"),failed=ChatMessage(role:"user",content:"failed",state:"failed")
        let history=PromptBuilder.messages(role:custom,history:[ChatMessage(role:"assistant",content:"orphan"),sent,failed],current:"new message")
        check(history.map(\.role)==["system","user","user"] && !history.contains(where:{$0.content=="failed"}),"failed messages excluded and orphan assistant removed")
        let client=DeepSeekClient()
        let request=try client.request(key:"test-only-key",model:"deepseek-flash",messages:history)
        let body=try JSONSerialization.jsonObject(with:request.httpBody!) as! [String:Any]
        check(request.url?.absoluteString=="https://api.deepseek.com/chat/completions" && request.httpMethod=="POST","fixed official HTTPS endpoint")
        check(request.value(forHTTPHeaderField:"Authorization")=="Bearer test-only-key" && body["api_key"]==nil,"key only sent in authorization header")
        check((body["response_format"] as? [String:String])?["type"]=="json_object" && (body["thinking"] as? [String:String])?["type"]=="disabled","JSON reply and non-thinking request")
        let customRequest=try client.request(key:"custom-key",model:"gpt-4o-mini",messages:[],endpoint:"https://api.openai.com/v1")
        check(customRequest.url?.absoluteString=="https://api.openai.com/v1/chat/completions","custom OpenAI-compatible endpoint is normalized")
        let localRequest=try client.request(key:"",model:"llama3.2",messages:[],endpoint:"http://127.0.0.1:11434/v1")
        check(localRequest.value(forHTTPHeaderField:"Authorization")==nil,"local Ollama endpoint can omit API Key")
        reject("remote HTTP endpoint blocked") { _=try client.request(key:"test",model:"x",messages:[],endpoint:"http://example.com/v1") }
        reject("empty key blocked before network") { _=try client.request(key:" ",model:"deepseek-flash",messages:[]) }
        reject("invalid model blocked") { _=try client.request(key:"test",model:"bad\nheader",messages:[]) }
        func response(_ content:String)->Data { try! JSONSerialization.data(withJSONObject:["choices":[["message":["content":content]]]]) }
        let normal=try DeepSeekClient.decode(response("{\"reply\":\"你好\",\"emotion\":\"hug\"}"))
        check(normal==CompanionReply(text:"你好",emotion:"hug"),"structured reply decoded with emotion")
        check(try DeepSeekClient.decode(response("{\"reply\":\"你好\",\"emotion\":\"other\"}")).emotion=="idle","API unknown emotion is safe")
        check(try DeepSeekClient.decode(response("```json\n{\"reply\":\"你好\",\"emotion\":\"smile\"}\n```")).emotion=="smile","fenced JSON tolerated")
        check(try DeepSeekClient.decode(response("普通回复")).text=="普通回复","plain-text response fallback")
        reject("empty model response handled") { _=try DeepSeekClient.decode(response("")) }
        reject("malformed API response handled") { _=try DeepSeekClient.decode(Data("invalid".utf8)) }
        let dir=URL(fileURLWithPath:ProcessInfo.processInfo.environment["BANBAN_TEST_DIR"] ?? NSTemporaryDirectory()).appendingPathComponent("banban-test-"+UUID().uuidString,isDirectory:true)
        defer { try? FileManager.default.removeItem(at:dir) }
        let disk=try DiskStore(directory:dir)
        var config=AppSettings();config.role=custom
        try disk.save(config,file:"settings.json")
        check(try disk.load(AppSettings.self,file:"settings.json")?.role==custom,"all custom role fields survive restart")
        check(disk.photoURL("../../private-file")==nil,"photo references cannot traverse outside library")
        let bitmap=NSBitmapImageRep(bitmapDataPlanes:nil,pixelsWide:8,pixelsHigh:12,bitsPerSample:8,samplesPerPixel:4,hasAlpha:true,isPlanar:false,colorSpaceName:.deviceRGB,bytesPerRow:0,bitsPerPixel:0)!
        memset(bitmap.bitmapData!,0,bitmap.bytesPerRow*bitmap.pixelsHigh)
        let offset=6*bitmap.bytesPerRow+4*4
        bitmap.bitmapData![offset]=204;bitmap.bitmapData![offset+1]=128;bitmap.bitmapData![offset+2]=204;bitmap.bitmapData![offset+3]=255
        let fixture=dir.appendingPathComponent("import-fixture.png");try bitmap.representation(using:.png,properties:[:])!.write(to:fixture)
        let filename=try disk.importPhoto(fixture)
        let imported=NSBitmapImageRep(data:try Data(contentsOf:disk.photoURL(filename)!))!
        check(imported.colorAt(x:0,y:0)?.alphaComponent==0 && imported.colorAt(x:4,y:6)!.alphaComponent>0.9,"photo import preserves transparency")
        check(FileManager.default.fileExists(atPath:fixture.path),"original photo retained after import")
        let modeModel=CompanionModel(disk:try DiskStore(directory:dir.appendingPathComponent("ModeLibrary")))
        let modeA=DesktopPhoto(file:filename,name:"A"),modeB=DesktopPhoto(file:filename,name:"B")
        modeModel.settings.desktopPhotos=[modeA,modeB];modeModel.positioningPhotos=[modeA.id,modeB.id]
        modeModel.setPresentationMode("wallpaper",for:modeA.id)
        check(modeModel.settings.desktopPhotos![0].preferences?.wallpaperEffect==true && modeModel.settings.desktopPhotos![1].preferences==nil && !modeModel.settings.preferences.wallpaperEffect,"selecting one desktop pet wallpaper mode does not change another or main pet")
        check(!modeModel.positioningPhotos.contains(modeA.id) && modeModel.positioningPhotos.contains(modeB.id),"mode selection ends temporary placement only for the selected pet")
        check(modeModel.desktopPreferences(modeModel.settings.desktopPhotos![0],forPositioning:true).wallpaperEffect,"selected wallpaper mode applies immediately rather than remaining in placement override")
        let modeReload=CompanionModel(disk:modeModel.disk)
        check(modeReload.settings.desktopPhotos![0].preferences?.wallpaperEffect==true,"individual wallpaper selection persists through restart")
        let profileDisk=try DiskStore(directory:dir.appendingPathComponent("profiles"))
        var oldConfig=AppSettings();oldConfig.role.name="已有角色";oldConfig.basePhoto=filename;oldConfig.preferences.petX=88
        try profileDisk.save(oldConfig,file:"settings.json")
        try profileDisk.save([ChatMessage(role:"user",content:"仅A知道")],file:"history.json")
        let profilesModel=CompanionModel(disk:profileDisk)
        check(profilesModel.settings.profiles?.count==6,"legacy configuration gains five editable preset roles")
        check(profilesModel.settings.profiles?.dropFirst().map { $0.role.name } == ["妈妈","女朋友","老婆","情人","老师"],"all requested role presets have saved settings")
        check(profilesModel.settings.scenes?.count==6 && profilesModel.settings.scenes!.allSatisfy { !$0.detail.isEmpty },"all six scene presets have descriptions")
        check(profilesModel.settings.role.name=="已有角色" && profilesModel.settings.basePhoto==filename && profilesModel.settings.preferences.petX==88,"migration retains user's role, media and layout")
        let profileA=profilesModel.settings.activeProfileID!,profileB=profilesModel.settings.profiles![1].id
        profilesModel.settings.scene=SceneSettings(name:"阳台A",detail:"A的场景")
        profilesModel.switchProfile(profileB)
        check(profilesModel.messages.isEmpty && profilesModel.settings.basePhoto==nil && profilesModel.settings.role.name=="妈妈","switch loads independent media, role and history")
        profilesModel.messages=[ChatMessage(role:"user",content:"仅B知道")];profilesModel.settings.preferences.petX=420;profilesModel.saveHistory()
        profilesModel.switchProfile(profileA)
        check(profilesModel.messages.first?.content=="仅A知道" && profilesModel.settings.preferences.petX==88 && profilesModel.settings.scene?.name=="阳台A","return restores profile-specific history, scene and position")
        let profilePrompt=PromptBuilder.messages(role:profilesModel.settings.role,history:profilesModel.messages,current:"你好",scene:profilesModel.settings.scene)
        check(profilePrompt[0].content.contains("A的场景") && !profilePrompt.contains(where:{$0.content.contains("仅B知道")}),"API context includes current scene and excludes other character's history")
        profilesModel.addProfile(copy:true)
        check(profilesModel.messages.isEmpty && profilesModel.settings.role.name=="已有角色 副本" && profilesModel.settings.basePhoto==filename,"copy retains settings and media while starting separate history")
        profilesModel.deleteActiveProfile()
        check(profilesModel.settings.profiles?.count==6,"preset and custom characters can be removed")
        let customScene=SceneSettings(name:"自定义花园",detail:"安静的花园")
        profilesModel.saveScene(customScene,asPreset:true)
        check(profilesModel.settings.scenes?.contains(where:{$0.id==customScene.id})==true,"custom scene can be added")
        profilesModel.deleteScenePreset(customScene.id)
        check(profilesModel.settings.scene?.name=="自定义花园" && profilesModel.settings.scenes?.contains(where:{$0.id==customScene.id})==false,"deleting preset does not alter current character's saved scene")
        profilesModel.settings.scenes=[];profilesModel.saveSettings()
        let reloadedProfiles=CompanionModel(disk:profileDisk)
        check(reloadedProfiles.settings.scenes?.isEmpty==true && reloadedProfiles.settings.profiles?.count==6,"deleted presets stay deleted after restart")
        let model=CompanionModel(disk:disk)
        check(!model.hasPhoto,"fresh app has no sample person")
        model.settings.basePhoto=filename
        check(model.hasPhoto && model.currentImage != nil,"user-owned photo enables desktop figure")
        let transparentView=PetView(frame:NSRect(x:0,y:0,width:200,height:300));transparentView.model=model;transparentView.photo=model.currentImage
        model.settings.preferences.opacity=0;model.settings.preferences.chatOpacity=0
        check(!transparentView.containsVisiblePoint(NSPoint(x:100,y:150)),"fully transparent photo does not intercept mouse hits")
        let zeroReload=CompanionModel(disk:disk)
        check(zeroReload.settings.preferences.opacity==0 && zeroReload.settings.preferences.chatOpacity==0,"zero transparency survives profile save and restart")
        model.settings.preferences.opacity=1;model.settings.preferences.chatOpacity=0.55
        model.selectPose("hug")
        check(model.currentImage != nil && model.notice.contains("默认照片"),"missing pose falls back to user's default photo")
        model.settings.posePhotos["hug"]=filename
        check(model.configuredCount==1,"only imported pose is counted")
        model.settings.desktopPhotos=[DesktopPhoto(file:filename,name:"旧摆放")]
        let oldDesktopID=model.settings.desktopPhotos!.first!.id
        model.settings.galleryPhotos=[filename]
        model.displayAllImportedPhotos()
        check(model.orderedGalleryDisplayFiles==[filename] && model.settings.desktopPhotos?.first?.id==oldDesktopID,"one-click display uses an independent canvas without replacing existing desktop pets")
        model.exitAllPhotoDisplay()
        check(model.galleryDisplayFiles.isEmpty && model.settings.desktopPhotos?.first?.id==oldDesktopID && model.settings.basePhoto==filename,"exit display preserves existing desktop pets and source photo")
        model.clearPosePhotos()
        check(model.settings.posePhotos.isEmpty && model.settings.basePhoto==filename,"clearing batch photos keeps separate default photo")
        model.settings.posePhotos["hug"]=filename
        model.clearGalleryPhotos()
        check(model.settings.galleryPhotos?.isEmpty == true && model.settings.posePhotos["hug"]==filename,"clearing gallery keeps action photos separate")
        for count in [1,21,75,250,1000] {
            let sizes=(0..<count).map { i in CGSize(width:[0.04,0.5,0.75,1,1.5,2,25][i%7]*1200,height:1200) }
            for screen in [CGRect(x:0,y:0,width:1440,height:900),CGRect(x:-1920,y:150,width:1280,height:720),CGRect(x:0,y:0,width:390,height:600)] {
                let area=AdaptiveGalleryLayout.photoArea(in:screen)
                let frames=AdaptiveGalleryLayout.frames(sizes:sizes,in:area)
                check(frames.count==count && frames.allSatisfy { $0.width>0 && $0.height>0 && area.insetBy(dx:-0.001,dy:-0.001).contains($0) },"adaptive gallery fits every one of \(count) media on \(Int(screen.width)) pt screen")
                var separate=true,proportional=true
                for i in frames.indices {
                    proportional = proportional && abs(frames[i].width/frames[i].height-sizes[i].width/sizes[i].height)<0.00001
                    for j in frames.indices where j>i { if frames[i].intersects(frames[j]) { separate=false } }
                }
                check(separate && proportional,"\(count) gallery tiles never overlap or crop mixed original aspect ratios")
            }
        }
        let galleryDisk=try DiskStore(directory:dir.appendingPathComponent("AdaptiveGallery"))
        var galleryFiles:[String]=[]
        for i in 0..<87 {
            let size=[NSSize(width:90,height:160),NSSize(width:200,height:110),NSSize(width:130,height:130),NSSize(width:280,height:80),NSSize(width:70,height:210)][i%5]
            let synthetic=NSImage(size:size,flipped:false) { rect in
                NSColor(calibratedHue:CGFloat(i%12)/12,saturation:0.45,brightness:0.83,alpha:1).setFill();rect.fill()
                let text="\(i+1)" as NSString
                text.draw(at:NSPoint(x:8,y:8),withAttributes:[.font:NSFont.systemFont(ofSize:24,weight:.semibold),.foregroundColor:NSColor.white]);return true
            }
            let file="gallery-\(i).png",png=NSBitmapImageRep(data:synthetic.tiffRepresentation!)!.representation(using:.png,properties:[:])!
            try png.write(to:galleryDisk.images.appendingPathComponent(file));galleryFiles.append(file)
        }
        let galleryModel=CompanionModel(disk:galleryDisk),galleryDesktop=CompanionAppDelegate()
        galleryDesktop.model=galleryModel
        galleryModel.onGalleryChanged={ [weak galleryDesktop] in galleryDesktop?.syncGalleryDisplay(in:NSRect(x:0,y:0,width:1280,height:720)) }
        galleryModel.settings.galleryPhotos=galleryFiles
        galleryModel.displayAllImportedPhotos()
        check(galleryModel.orderedGalleryDisplayFiles==galleryFiles && galleryDesktop.galleryCanvas?.tileFrames.count==87,"all 87 imported files reach the real gallery canvas in import order without a 20-item cap")
        let exitFrame=galleryDesktop.galleryExitPanel!.frame
        check(galleryDesktop.galleryCanvas!.tileFrames.allSatisfy { !$0.intersects(exitFrame) } && galleryDesktop.galleryExitPanel!.level.rawValue>galleryDesktop.galleryPanel!.level.rawValue && !galleryDesktop.galleryExitPanel!.ignoresMouseEvents,"gallery reserves a clear clickable exit area above every photo")
        let canvasBefore=galleryDesktop.galleryCanvas
        galleryModel.displayAllImportedPhotos()
        check(galleryDesktop.galleryCanvas === canvasBefore && galleryDesktop.galleryCanvas?.files.count==87,"repeating display reuses the gallery without duplicate tiles or windows")
        galleryModel.exitAllPhotoDisplay()
        check(galleryDesktop.galleryPanel==nil && galleryDesktop.galleryExitPanel==nil && canvasBefore?.files.isEmpty==true && galleryModel.settings.galleryPhotos?.count==87,"exit closes gallery and toolbar and releases tiles while preserving all 87 originals")
        model.settings.preferences.rememberHistory=false;model.messages=[sent];model.saveHistory()
        check(try disk.load([ChatMessage].self,file:"history.json")?.isEmpty==true,"disabled local history writes empty history")
        check(try disk.readAPIKey()==nil,"new library has no local API key")
        model.saveAPI(key:"temporary-test-value",model:"deepseek-flash")
        check(try model.hasKey && disk.readAPIKey()=="temporary-test-value","API settings save key locally")
        let restarted=CompanionModel(disk:disk)
        check(restarted.hasKey,"saved local key detected after restart")
        restarted.saveAPI(key:"",model:"deepseek-flash")
        check(try disk.readAPIKey()=="temporary-test-value","empty input retains saved local key")
        try disk.saveAPIKey("temporary-test-update")
        check(try disk.readAPIKey()=="temporary-test-update","local API key replacement")
        let keyAttributes=try FileManager.default.attributesOfItem(atPath:dir.appendingPathComponent("deepseek-key.json").path)
        check((keyAttributes[.posixPermissions] as? NSNumber)?.intValue==0o600,"local key readable only by current user")
        restarted.deleteAPIKey()
        check(try !restarted.hasKey && disk.readAPIKey()==nil,"remove local key without Keychain access")
        model.removePhoto(pose:"hug")
        check(model.settings.posePhotos["hug"]==nil && model.configuredCount==0,"pose delete clears only selected slot")
        check(model.currentImage != nil && FileManager.default.fileExists(atPath:fixture.path),"pose delete retains default image and original file")
        model.restorePhoto(pose:"hug")
        check(model.settings.posePhotos["hug"]==filename,"pose deletion can be undone")
        model.removePhoto()
        check(model.settings.basePhoto==nil && model.settings.posePhotos["hug"]==filename,"default photo deletion does not delete pose photo")
        model.restorePhoto()
        check(model.settings.basePhoto==filename,"default photo removal can be undone")
        let oldSettings=try JSONDecoder().decode(AppSettings.self,from:Data("{\"version\":1,\"posePhotos\":{},\"role\":{\"name\":\"test\",\"relationship\":\"\",\"personality\":\"test\",\"background\":\"\",\"speakingStyle\":\"\"},\"preferences\":{},\"model\":\"deepseek-flash\"}".utf8))
        check(oldSettings.desktopPhotos==nil && !oldSettings.preferences.autoRemoveBackground,"old settings support new photo features without migration loss")
        model.settings.preferences.autoRemoveBackground=true
        model.settings.desktopPhotos=[]
        model.addDesktopPhoto(file:filename,name:"测试照片")
        model.addDesktopPhoto(file:filename,name:"第二张")
        let firstID=model.settings.desktopPhotos![0].id
        let secondID=model.settings.desktopPhotos![1].id
        check(firstID != secondID && model.settings.desktopPhotos?.count==2,"same image can be displayed as independent pets")
        model.setDesktopHeight(firstID,999)
        check(model.settings.desktopPhotos![0].height==700 && model.settings.desktopPhotos![1].height==260,"per-image size clamps without changing another image")
        model.settings.desktopPhotos![0].x=100;model.settings.desktopPhotos![0].y=200
        let loaded=try disk.load(AppSettings.self,file:"settings.json")!
        check(loaded.desktopPhotos?[0].x==100 && loaded.desktopPhotos?[0].y==200 && loaded.preferences.autoRemoveBackground,"multiple pet positions sizes and import option survive restart")
        model.settings.preferences.petVisible=false
        let desktop=CompanionAppDelegate();desktop.model=model;desktop.syncDesktopPhotos()
        check(desktop.desktopPanels.count==2 && desktop.desktopPanels.values.allSatisfy { !$0.isVisible },"multiple real pet panels obey global hidden state")
        model.settings.preferences.setFloatingClickThrough(true);desktop.syncDesktopPhotos()
        check(desktop.desktopPanels.values.allSatisfy { !$0.ignoresMouseEvents },"changing main pet mode does not change independent extra pets")
        for id in [firstID,secondID] { model.editDesktopPreferences(id) { $0.setFloatingClickThrough(true) } };desktop.syncDesktopPhotos()
        check(desktop.desktopPanels.values.allSatisfy { $0.level == .floating && $0.ignoresMouseEvents },"every extra pet applies foreground click-through")
        model.settings.preferences.setWallpaperEffect(true)
        for id in [firstID,secondID] { model.editDesktopPreferences(id) { $0.setWallpaperEffect(true) } };desktop.syncDesktopPhotos()
        check(desktop.desktopPanels.values.allSatisfy { $0.level.rawValue==Int(CGWindowLevelForKey(.desktopWindow))+1 && $0.ignoresMouseEvents },"every extra pet applies wallpaper click-through")
        model.editDesktopPreferences(firstID) { $0.opacity=0.4;$0.joinAllSpaces=false;$0.idleMotion=false }
        let independent=model.settings.desktopPhotos!
        check(model.desktopPreferences(independent[0]).opacity==0.4 && model.desktopPreferences(independent[1]).opacity==1,"extra pet opacity is independent")
        check(!model.desktopPreferences(independent[0]).joinAllSpaces && model.desktopPreferences(independent[1]).joinAllSpaces,"extra pet spaces and animation settings are independent")
        let persisted=try disk.load(AppSettings.self,file:"settings.json")!
        check(persisted.desktopPhotos?[0].preferences?.opacity==0.4,"independent settings survive restart")
        model.toggleDesktopPositioning(firstID)
        let moving=model.desktopPreferences(model.settings.desktopPhotos![0],forPositioning:true)
        let stationary=model.desktopPreferences(model.settings.desktopPhotos![1],forPositioning:true)
        check(!moving.wallpaperEffect && !moving.floatingClickThrough && moving.alwaysOnTop && stationary.wallpaperEffect,"position editing only unlocks selected pet")
        check(model.settings.desktopPhotos![0].preferences?.wallpaperEffect==true,"position editing does not overwrite saved click-through mode")
        model.settings.preferences.petVisible=false;desktop.syncDesktopPhotos()
        check(desktop.desktopPanels[firstID]?.level == .floating && desktop.desktopPanels[firstID]?.ignoresMouseEvents == false && desktop.desktopPanels[secondID]?.ignoresMouseEvents == true,"native panels unlock only the selected pet during placement")
        model.settings.preferences.petVisible=true
        model.toggleDesktopPositioning(firstID)
        check(model.desktopPreferences(model.settings.desktopPhotos![0],forPositioning:true).wallpaperEffect,"finishing placement restores selected pet mode")
        model.settings.preferences.petVisible=false;desktop.syncDesktopPhotos()
        check(desktop.desktopPanels[firstID]?.ignoresMouseEvents==true && desktop.desktopPanels[firstID]?.level.rawValue==Int(CGWindowLevelForKey(.desktopWindow))+1,"native selected pet restores wallpaper layer and click-through after placement")
        model.settings.preferences.petVisible=true
        model.setDesktopVisible(firstID,false)
        check(!model.desktopPreferences(model.settings.desktopPhotos![0]).petVisible && model.desktopPreferences(model.settings.desktopPhotos![1]).petVisible,"individual hide does not hide another pet")
        model.settings.preferences.petVisible=false
        check(model.settings.desktopPhotos!.allSatisfy { !model.desktopPreferences($0).petVisible },"global hide still overrides every individual visibility")
        model.settings.preferences.mainPetVisible=false;model.toggleMainPositioning()
        check(model.settings.preferences.mainPetVisible && !model.mainPresentationPreferences.wallpaperEffect && model.settings.preferences.wallpaperEffect,"main pet can be positioned independently without overwriting saved mode")
        model.toggleMainPositioning();model.settings.preferences.petVisible=false
        check(model.mainPresentationPreferences.wallpaperEffect,"main pet restores wallpaper mode after placement")
        desktop.arrangeDesktopPhotos(in:NSRect(x:0,y:0,width:1200,height:800))
        let arranged=model.settings.desktopPhotos!
        check(arranged[0].x != arranged[1].x || arranged[0].y != arranged[1].y,"auto arrangement gives extra photos distinct grid positions")
        check(arranged.allSatisfy { $0.height>=100 && $0.height<=260 && $0.x != nil && $0.y != nil },"auto arrangement persists visible photo sizes and coordinates")
        model.removeDesktopPhoto(firstID);desktop.syncDesktopPhotos()
        check(desktop.desktopPanels.count==1 && desktop.desktopPanels[secondID] != nil && model.settings.posePhotos["hug"]==filename,"removing one desktop pet preserves other pets and library")
        model.removePhoto();model.removePhoto(pose:"hug")
        check(model.hasPhoto,"extra desktop image remains available after source slot removal")
        for panel in desktop.desktopPanels.values { panel.close() }
        model.settings.desktopPhotos=[]
        for _ in 0..<21 { model.addDesktopPhoto(file:filename,name:"test") }
        check(model.settings.desktopPhotos?.count==20,"extra desktop photo count capped at twenty")
        reject("invalid cutout input fails without changing source") { _=try BackgroundRemoval.png(from:dir.appendingPathComponent("missing.png")) }
        if let path=ProcessInfo.processInfo.environment["BANBAN_TEST_CUTOUT_FILE"] {
            let cutout=try BackgroundRemoval.png(from:URL(fileURLWithPath:path))
            let output=NSBitmapImageRep(data:cutout)!
            var transparent=0,visible=0
            let strideX=max(1,output.pixelsWide/100),strideY=max(1,output.pixelsHigh/100)
            for y in stride(from:0,to:output.pixelsHigh,by:strideY) { for x in stride(from:0,to:output.pixelsWide,by:strideX) {
                let alpha=output.colorAt(x:x,y:y)?.alphaComponent ?? 1
                if alpha<0.05 { transparent+=1 };if alpha>0.9 { visible+=1 }
            } }
            check(output.hasAlpha && transparent>0 && visible>0,"native Vision cutout produces transparent background with retained foreground")
            let source=NSImage(contentsOfFile:path)!
            check(output.pixelsWide>0 && output.pixelsHigh>0 && source.size.width>0,"native cutout returns decodable PNG without modifying source")
        }
        let configuration=URLSessionConfiguration.ephemeral;configuration.protocolClasses=[StubProtocol.self]
        let stubbed=DeepSeekClient(session:URLSession(configuration:configuration),retryDelayNanoseconds:0)
        Task { @MainActor in
            StubProtocol.status=200;StubProtocol.payload=response("{\"reply\":\"网络模拟验证通过\",\"emotion\":\"comfort\"}")
            do {
                let galleryOriginal=galleryDisk.photoURL(galleryFiles[1])!
                let copiedOriginal=try await galleryDisk.importGalleryMedia(galleryOriginal)
                check(try Data(contentsOf:galleryDisk.photoURL(copiedOriginal)!)==Data(contentsOf:galleryOriginal),"gallery import copies original image bytes without conversion or background removal")
                check(CompanionModel(disk:galleryDisk).settings.galleryPhotos==galleryFiles,"all gallery file references survive restart without truncation")
                galleryModel.displayAllImportedPhotos()
                let actualCanvas=galleryDesktop.galleryCanvas!
                for _ in 0..<100 { if actualCanvas.renderedCount==87 { break };try await Task.sleep(nanoseconds:50_000_000) }
                check(actualCanvas.renderedCount==87 && actualCanvas.mediaSizes[0].width/actualCanvas.mediaSizes[0].height != actualCanvas.mediaSizes[1].width/actualCanvas.mediaSizes[1].height,"every real mixed-size tile loads an oriented display thumbnail")
                if let path=ProcessInfo.processInfo.environment["BANBAN_GALLERY_PREVIEW"],let context=CGContext(data:nil,width:1280,height:720,bitsPerComponent:8,bytesPerRow:0,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue) {
                    context.setFillColor(NSColor(calibratedWhite:0.96,alpha:1).cgColor);context.fill(CGRect(x:0,y:0,width:1280,height:720))
                    actualCanvas.layer?.render(in:context)
                    NSGraphicsContext.saveGraphicsState();NSGraphicsContext.current=NSGraphicsContext(cgContext:context,flipped:false)
                    ("87 张混合比例照片 · 全部自动排列" as NSString).draw(at:NSPoint(x:16,y:680),withAttributes:[.font:NSFont.systemFont(ofSize:16),.foregroundColor:NSColor.darkGray])
                    ("× 退出展示" as NSString).draw(at:NSPoint(x:1150,y:680),withAttributes:[.font:NSFont.systemFont(ofSize:14),.foregroundColor:NSColor.darkGray]);NSGraphicsContext.restoreGraphicsState()
                    if let image=context.makeImage(),let png=NSBitmapImageRep(cgImage:image).representation(using:.png,properties:[:]) { try png.write(to:URL(fileURLWithPath:path)) }
                }
                galleryModel.exitAllPhotoDisplay()
                let result=try await stubbed.chat(key:"test-only-key",model:"deepseek-flash",messages:history)
                check(result.emotion=="comfort" && StubProtocol.sawRequest,"request/response integration using local URLProtocol")
                for status in [401,402,429,503] {
                    StubProtocol.status=status;StubProtocol.captured=[]
                    do { _=try await stubbed.chat(key:"test-only-key",model:"deepseek-flash",messages:history);check(false,"HTTP \(status) handling") }
                    catch CompanionError.http(let code) { check(code==status,"HTTP \(status) handling");check(StubProtocol.captured.count==(status==429 || status>=500 ? 3:1),"HTTP \(status) retry bound") }
                    catch { check(false,"unexpected HTTP error type") }
                }
                func envelope(_ text:String,_ reason:String)->Data { try! JSONSerialization.data(withJSONObject:["choices":[["finish_reason":reason,"message":["content":text]]]]) }
                StubProtocol.status=200;StubProtocol.captured=[]
                StubProtocol.events=[.reply(200,response("")),.reply(200,response("普通文字恢复成功"))]
                var progress:[String]=[]
                let recovered=try await stubbed.chat(key:"test-only",model:"deepseek-flash",messages:history,progress:{ progress.append($0) })
                check(recovered.text=="普通文字恢复成功" && recovered.emotion=="idle" && StubProtocol.captured.count==2,"empty JSON reply recovers as plain text without duplicate UI messages")
                check(StubProtocol.captured[0]["response_format"] != nil && StubProtocol.captured[1]["response_format"]==nil && !progress.isEmpty,"empty reply retry switches format and reports progress")
                let recoveryMessages=StubProtocol.captured[1]["messages"] as! [[String:String]]
                check(recoveryMessages.first?["content"]?.contains("不输出 JSON")==true && recoveryMessages.last?["content"]=="new message","plain reply fallback preserves user text and role context")
                StubProtocol.captured=[];StubProtocol.events=[.reply(200,response("{\"reply\":\"unfinished")),.reply(200,response("完整正文"))]
                check(try await stubbed.chat(key:"test-only",model:"deepseek-flash",messages:history).text=="完整正文","malformed JSON recovers without showing raw JSON")
                StubProtocol.captured=[];StubProtocol.events=[.reply(200,envelope("{\"reply\":", "length")),.reply(200,response("长度截断恢复成功"))]
                check(try await stubbed.chat(key:"test-only",model:"deepseek-flash",messages:history).text=="长度截断恢复成功","length truncation retries for a complete visible reply")
                StubProtocol.captured=[];StubProtocol.events=[.reply(503,Data()),.reply(200,response("服务恢复"))]
                check(try await stubbed.chat(key:"test-only",model:"deepseek-flash",messages:history).text=="服务恢复","temporary server failure recovers automatically")
                StubProtocol.captured=[];StubProtocol.events=[.failure(.timedOut),.reply(200,response("超时恢复"))]
                check(try await stubbed.chat(key:"test-only",model:"deepseek-flash",messages:history).text=="超时恢复","temporary timeout recovers automatically")
                StubProtocol.captured=[];StubProtocol.events=[.reply(200,envelope("","insufficient_system_resource")),.reply(200,response("资源恢复"))]
                check(try await stubbed.chat(key:"test-only",model:"deepseek-flash",messages:history).text=="资源恢复","interrupted generation recovers automatically")
                StubProtocol.captured=[];StubProtocol.events=[];StubProtocol.payload=response("")
                do { _=try await stubbed.chat(key:"test-only",model:"deepseek-flash",messages:history);check(false,"empty response exhausts bounded retries") }
                catch CompanionError.emptyReply { check(StubProtocol.captured.count==3,"empty response exhausts bounded retries") }
                StubProtocol.captured=[];StubProtocol.payload=envelope("","content_filter")
                do { _=try await stubbed.chat(key:"test-only",model:"deepseek-flash",messages:history);check(false,"content filtering reported without retry") }
                catch CompanionError.filteredReply { check(StubProtocol.captured.count==1,"content filtering reported without retry") }
                check(try DeepSeekClient.decode(response("[微笑] 你好")).text=="[微笑] 你好","plain roleplay stage directions remain visible")
                reject("JSON missing reply never leaks as visible text") { _=try DeepSeekClient.decode(response("{\"emotion\":\"idle\"}")) }
                StubProtocol.captured=[];StubProtocol.hold=true
                let cancelled=Task { try await stubbed.chat(key:"test-only",model:"deepseek-flash",messages:history) }
                while StubProtocol.captured.isEmpty { await Task.yield() }
                cancelled.cancel()
                do { _=try await cancelled.value;check(false,"cancellation stops pending request and retries") }
                catch { check(StubProtocol.captured.count==1,"cancellation stops pending request and retries") }
                StubProtocol.hold=false
                try disk.saveAPIKey("test-only-key")
                let retryModel=CompanionModel(disk:disk,client:stubbed)
                retryModel.settings.role=custom
                let earlier=ChatMessage(role:"user",content:"earlier-message",state:"failed",failureReason:"test error")
                let later=ChatMessage(role:"user",content:"later-message")
                let laterReply=ChatMessage(role:"assistant",content:"later-reply")
                retryModel.messages=[earlier,later,laterReply]
                StubProtocol.payload=response("earlier-reply");StubProtocol.captured=[]
                retryModel.send(earlier.content,retryID:earlier.id)
                await retryModel.requestTask?.value
                check(retryModel.messages.map(\.content)==["earlier-message","earlier-reply","later-message","later-reply"],"retry inserts response next to original message without duplicates")
                let retriedMessages=StubProtocol.captured.first?["messages"] as! [[String:String]]
                check(!retriedMessages.contains { $0["content"]=="later-message" || $0["content"]=="later-reply" },"retry excludes future turns from context")
                check(retryModel.messages[0].failureReason==nil && retryModel.messages[0].state=="sent" && !retryModel.busy && retryModel.chatStatus.isEmpty,"successful retry clears stale failure and busy state")
                check(retryModel.chatScrollTarget==retryModel.messages[1].id,"retry scrolls to recovered reply rather than unrelated later messages")
                retryModel.messages=[];StubProtocol.captured=[]
                StubProtocol.events=[.reply(200,response("")),.reply(200,response("自动恢复后的正文"))]
                retryModel.send("automatic-recovery")
                await retryModel.requestTask?.value
                check(retryModel.messages.count==2 && retryModel.messages[0].state=="sent" && retryModel.messages[1].content=="自动恢复后的正文" && StubProtocol.captured.count==2,"automatic recovery produces one user message and one visible assistant reply")
                StubProtocol.status=401;StubProtocol.captured=[]
                retryModel.send("auth-failure")
                await retryModel.requestTask?.value
                check(retryModel.messages.last?.failureReason?.contains("API Key")==true && StubProtocol.captured.count==1,"failed message retains specific authentication reason")
                StubProtocol.status=200;StubProtocol.hold=true;StubProtocol.captured=[]
                retryModel.send("stop-message")
                let pending=retryModel.requestTask
                while StubProtocol.captured.isEmpty { await Task.yield() }
                retryModel.cancel();await pending?.value;StubProtocol.hold=false
                check(!retryModel.busy && retryModel.messages.last?.state=="failed" && retryModel.messages.last?.failureReason?.contains("停止")==true,"stop clears busy state and preserves recoverable message")
                let roundtrip=try JSONDecoder().decode(ChatMessage.self,from:JSONEncoder().encode(retryModel.messages.last!))
                check(roundtrip.failureReason != nil,"per-message failure reason survives saved history")
                StubProtocol.hold=true;StubProtocol.captured=[]
                retryModel.settings.preferences.rememberHistory=true
                retryModel.send("switch-cancel-message")
                let switchingTask=retryModel.requestTask
                while StubProtocol.captured.isEmpty { await Task.yield() }
                let originalProfile=retryModel.settings.activeProfileID!
                retryModel.switchProfile(retryModel.settings.profiles!.first(where:{$0.id != originalProfile})!.id)
                await switchingTask?.value;StubProtocol.hold=false
                check(retryModel.messages.isEmpty && !retryModel.busy,"switching character cancels pending reply and isolates next history")
                retryModel.switchProfile(originalProfile)
                check(retryModel.messages.last?.content=="switch-cancel-message" && retryModel.messages.last?.state=="failed","previous character retains a retryable interrupted message")
                guard let videoPath=ProcessInfo.processInfo.environment["BANBAN_TEST_VIDEO"] else { throw BackgroundRemoval.failure("Missing synthetic video fixture") }
                let fixtureURL=URL(fileURLWithPath:videoPath)
                let videoDisk=try DiskStore(directory:dir.appendingPathComponent("VideoLibrary"))
                let videoFile=try await videoDisk.importMedia(fixtureURL,removeBackground:true)
                check(DiskStore.isVideo(videoFile) && DiskStore.isVideo("CLIP.MOV") && !DiskStore.isVideo("person.png"),"video type detection handles supported formats and case")
                check(try Data(contentsOf:videoDisk.photoURL(videoFile)!)==Data(contentsOf:fixtureURL),"video import preserves source bytes and bypasses photo cutout")
                check(videoDisk.previewURL(videoFile).flatMap { NSImage(contentsOf:$0) } != nil,"video import generates a local orientation-correct preview")
                let videoModel=CompanionModel(disk:videoDisk)
                videoModel.settings.basePhoto=videoFile
                check(videoModel.hasPhoto && videoModel.currentMediaFile==videoFile && videoModel.currentImage != nil,"video can be the primary pet with poster-based layout")
                videoModel.settings.posePhotos["hug"]=filename
                videoModel.currentPose="smile"
                check(videoModel.currentMediaFile==videoFile,"unconfigured emotion uses default video")
                videoModel.settings.posePhotos["smile"]=videoFile
                check(videoModel.configuredCount==1,"video occupies configurable emotion slot")
                videoModel.addDesktopPhoto(file:videoFile,name:"video-one");videoModel.addDesktopPhoto(file:videoFile,name:"video-two")
                videoModel.settings.preferences.petVisible=false
                let videoDesktop=CompanionAppDelegate();videoDesktop.model=videoModel;videoDesktop.syncDesktopPhotos()
                let videoIDs=videoModel.settings.desktopPhotos!.map(\.id)
                let firstVideo=videoDesktop.desktopViews[videoIDs[0]]!,secondVideo=videoDesktop.desktopViews[videoIDs[1]]!
                check(firstVideo.video.player !== secondVideo.video.player && firstVideo.video.looper != nil && secondVideo.video.looper != nil,"each desktop video owns an independent player and native looper")
                check(firstVideo.video.player.isMuted && secondVideo.video.player.isMuted && !firstVideo.video.wantsPlayback && !secondVideo.video.wantsPlayback,"hidden video pets are paused and muted")
                let existingLooper=firstVideo.video.looper
                firstVideo.setMedia(videoFile)
                check(firstVideo.video.looper === existingLooper,"updating layout does not restart or recreate video loop")
                videoModel.editDesktopPreferences(videoIDs[0]) { $0.opacity=0.4;$0.setFloatingClickThrough(true) }
                videoDesktop.syncDesktopPhotos()
                videoModel.editDesktopPreferences(videoIDs[0]) { $0.opacity=0 };videoDesktop.syncDesktopPhotos()
                check(firstVideo.video.layer.opacity==0 && !firstVideo.containsVisiblePoint(NSPoint(x:100,y:150)),"video supports fully transparent layer and stops mouse hit interception")
                videoModel.editDesktopPreferences(videoIDs[0]) { $0.opacity=0.4 };videoDesktop.syncDesktopPhotos()
                check(abs(firstVideo.video.layer.opacity-0.4)<0.01 && videoDesktop.desktopPanels[videoIDs[0]]!.ignoresMouseEvents && !videoDesktop.desktopPanels[videoIDs[1]]!.ignoresMouseEvents,"video pets retain independent opacity and click-through settings")
                let videoRestart=CompanionModel(disk:videoDisk)
                check(videoRestart.settings.desktopPhotos?.count==2 && videoRestart.currentMediaFile==videoFile,"video pet references survive restart")
                firstVideo.video.setPlaying(true);secondVideo.video.setPlaying(true)
                for _ in 0..<60 {
                    if (firstVideo.video.looper?.loopCount ?? 0)>0 && (secondVideo.video.looper?.loopCount ?? 0)>0 { break }
                    try await Task.sleep(nanoseconds:100_000_000)
                }
                let looped=(firstVideo.video.looper?.loopCount ?? 0)>0 && (secondVideo.video.looper?.loopCount ?? 0)>0
                let decoderFailed=firstVideo.video.player.currentItem?.status == .failed || secondVideo.video.player.currentItem?.status == .failed || firstVideo.video.looper?.status == .failed || secondVideo.video.looper?.status == .failed
                if !looped && decoderFailed { print("SKIP: real concurrent playback: AVFoundation decoder unavailable in execution environment") }
                else { check(looped,"two native video players each complete a real playback loop concurrently") }
                firstVideo.video.setPlaying(false)
                check(firstVideo.video.player.rate==0 && secondVideo.video.wantsPlayback,"pausing one video does not pause another")
                firstVideo.video.setPlaying(true)
                check(firstVideo.video.wantsPlayback,"hidden video playback can resume")
                videoModel.removeDesktopPhoto(videoIDs[0]);videoDesktop.syncDesktopPhotos()
                check(firstVideo.video.looper==nil && firstVideo.video.player.items().isEmpty && videoDesktop.desktopViews.count==1,"removing a video pet releases its queue and looper only")
                secondVideo.video.stop();for panel in videoDesktop.desktopPanels.values { panel.close() }
                let galleryVideo=try await videoDisk.importGalleryMedia(fixtureURL)
                videoModel.settings.galleryPhotos=[videoFile,galleryVideo]
                let movieGallery=CompanionAppDelegate();movieGallery.model=videoModel
                videoModel.onGalleryChanged={ [weak movieGallery] in movieGallery?.syncGalleryDisplay(in:NSRect(x:0,y:0,width:1000,height:700)) }
                videoModel.displayAllImportedPhotos()
                let movieCanvas=movieGallery.galleryCanvas!,galleryPlayer=movieCanvas.videos[0]!,otherGalleryPlayer=movieCanvas.videos[1]!
                check(movieCanvas.videos.count==2 && galleryPlayer.player !== otherGalleryPlayer.player && galleryPlayer.player.isMuted && otherGalleryPlayer.player.isMuted,"adaptive video gallery starts independent muted looping players")
                let originalLooper=galleryPlayer.looper
                movieGallery.syncGalleryDisplay(in:NSRect(x:0,y:0,width:650,height:900))
                check(movieCanvas.videos[0] === galleryPlayer && galleryPlayer.looper === originalLooper && movieCanvas.tileFrames.count==2,"screen size changes reflow gallery without restarting video loops")
                videoModel.settings.preferences.petVisible=false;movieGallery.syncGalleryDisplay()
                check(!galleryPlayer.wantsPlayback && !otherGalleryPlayer.wantsPlayback,"quick hiding pauses every gallery video")
                check(movieGallery.galleryPanel?.isVisible==false,"quick hiding removes the gallery canvas from the desktop")
                check(movieGallery.galleryExitPanel?.isVisible==false,"quick hiding removes the gallery exit toolbar from the desktop")
                videoModel.settings.preferences.petVisible=true;movieGallery.syncGalleryDisplay()
                for _ in 0..<60 { if (galleryPlayer.looper?.loopCount ?? 0)>0 && (otherGalleryPlayer.looper?.loopCount ?? 0)>0 { break };try await Task.sleep(nanoseconds:100_000_000) }
                let galleryLooped=(galleryPlayer.looper?.loopCount ?? 0)>0 && (otherGalleryPlayer.looper?.loopCount ?? 0)>0
                let galleryDecoderFailed=galleryPlayer.player.currentItem?.status == .failed || otherGalleryPlayer.player.currentItem?.status == .failed
                if !galleryLooped && galleryDecoderFailed { print("SKIP: real gallery playback: AVFoundation decoder unavailable") }
                else { check(galleryLooped,"two actual gallery videos complete playback loops after reflow and resume") }
                videoModel.exitAllPhotoDisplay()
                check(galleryPlayer.looper==nil && otherGalleryPlayer.looper==nil && movieGallery.galleryPanel==nil,"exiting adaptive gallery releases every video queue and window")
                do { _=try await videoDisk.importMedia(dir.appendingPathComponent("missing.mp4"));check(false,"invalid video rejected before settings replacement") }
                catch { check(videoModel.settings.basePhoto==videoFile,"invalid video rejected before settings replacement") }
                print("ALL \(passed) CHECKS PASSED. No real DeepSeek key or remote request was used.")
                exit(0)
            } catch { fputs("NETWORK STUB FAIL: \(error)\n",stderr);exit(1) }
        }
        RunLoop.main.run()
    } catch { fputs("TEST ERROR: \(error.localizedDescription)\n",stderr);exit(1) }
}
