#!/bin/zsh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUTPUT="$(dirname "$ROOT")"
APP="$OUTPUT/伴伴.app"
BUILD="${BANBAN_BUILD_DIR:-$ROOT/.build}"
CACHE="$BUILD/module-cache"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources" "$CACHE"
xcrun swiftc -swift-version 5 -O -whole-module-optimization -target arm64-apple-macosx13.0 -module-cache-path "$CACHE" -file-prefix-map "$ROOT=." -debug-prefix-map "$ROOT=." -framework AppKit -framework SwiftUI -framework Security -framework Carbon "$ROOT"/Sources/*.swift -o "$APP/Contents/MacOS/Banban"
cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>Banban</string>
<key>CFBundleIdentifier</key><string>local.banban.companion</string>
<key>CFBundleName</key><string>伴伴</string>
<key>CFBundleDisplayName</key><string>伴伴</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>1.4.1</string>
<key>CFBundleVersion</key><string>5</string>
<key>LSMinimumSystemVersion</key><string>13.0</string>
<key>NSHighResolutionCapable</key><true/>
<key>NSPrincipalClass</key><string>NSApplication</string>
<key>CFBundleIconFile</key><string>AppIcon</string>
<key>LSApplicationCategoryType</key><string>public.app-category.lifestyle</string>
<key>NSHumanReadableCopyright</key><string>伴伴 · 私人桌面伙伴</string>
</dict></plist>
PLIST
if [[ -f "$ROOT/AppIcon.icns" ]]; then cp "$ROOT/AppIcon.icns" "$APP/Contents/Resources/AppIcon.icns"; fi
/usr/bin/codesign --force --sign - --identifier local.banban.companion "$APP"
/usr/bin/codesign --verify --deep --strict "$APP"
/usr/bin/plutil -lint "$APP/Contents/Info.plist"
printf 'Built: %s\n' "$APP"
