# 伴伴 · Mac 桌面伙伴

独立原生 macOS App，支持用户自行导入人物照片和视频、本机素材管理、多角色与场景设定、AI 对话、桌宠互动和独立照片展示。

当前版本：1.4.1。当前预编译 App 适用于 Apple Silicon Mac，最低 macOS 13；自动抠图需要 macOS 14 或更新版本。

## 功能

- 默认形象与 20 个动作照片／视频槽位，可分别导入和移除。
- 多角色及场景设定，各自保存媒体关联、聊天与桌面摆放。
- 多个桌宠独立移动、缩放、透明度和显示模式设置。
- 壁纸鼠标穿透、前台悬浮穿透与全局隐藏／恢复快捷键 `Control + Option + H`。
- 照片本机去背景；多个视频静音循环播放。
- 独立照片／视频库，批量导入原文件，根据实际比例自动排列全部内容，右上角悬浮退出按钮。
- 可配置 AI 接口地址、模型和 API Key，支持 OpenAI Chat Completions 兼容接口和本机 Ollama。

## 源码与构建

安装 Apple Xcode Command Line Tools 后，在项目目录运行：

```sh
./build.sh
```

App 会生成在项目目录的上一级，名称为 `伴伴.app`。这是本机临时签名构建，不包含 Apple Developer ID 签名或公证。

自动检查：

```sh
./test.sh
```

测试只使用临时目录、模拟网络请求和本地产生的抽象测试素材。`Tests/Fixtures/loop-test.mp4` 是 0.6 秒的合成色彩图案，无人物、无音轨，用于验证视频循环，不是用户导入视频。

## 本机资料与分发范围

本仓库及发布 App 不附带个人 API Key、导入照片／视频、聊天记录、已保存角色数据或本机偏好。`Sources/` 中的产品默认值与平台示例地址属于程序代码，不是用户配置副本。

运行后，App 由使用者自行填写 API Key、导入自己的素材。本机运行资料保存在系统 Application Support 下的 `Banban` 目录；它们不属于本仓库。API Key 按当前产品设置明文保存在使用者本机，文件权限为 0600，不随安装包分发。

云端 AI 对话会向使用者配置的接口发送角色、场景和聊天文字；照片／视频用于本机显示，不会由对话功能上传。选择本机接口时，由使用者自行运行对应服务。

## 接口参考

- [OpenAI Chat Completions 格式](https://platform.openai.com/docs/api-reference/chat)
- [DeepSeek API](https://api-docs.deepseek.com/api/create-chat-completion)
- [Ollama OpenAI 兼容接口](https://docs.ollama.com/openai)

## 分发检查

参见 [PRIVACY-CHECK.md](PRIVACY-CHECK.md) 了解本次上传清单、排除范围及检查结果。
