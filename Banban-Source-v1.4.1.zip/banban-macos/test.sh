#!/bin/zsh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD="${BANBAN_BUILD_DIR:-$ROOT/.build}"
mkdir -p "$BUILD/module-cache"
xcrun swiftc -swift-version 5 -D SELF_TEST -target arm64-apple-macosx13.0 -module-cache-path "$BUILD/module-cache" -framework AppKit -framework SwiftUI -framework Security -framework Carbon "$ROOT"/Sources/*.swift "$ROOT/Tests/SelfTests.swift" -o "$BUILD/BanbanTests"
BANBAN_TEST_VIDEO="$ROOT/Tests/Fixtures/loop-test.mp4" BANBAN_TEST_DIR="$BUILD" "$BUILD/BanbanTests"
